using System.Collections.Generic;
using XianXia.Core.Domain.Ids;
using XianXia.Core.Results;

namespace XianXia.Data.Content
{
    public sealed class DefinitionRegistry
    {
        readonly Dictionary<DefinitionId, CharacterDefinition> _characters =
            new Dictionary<DefinitionId, CharacterDefinition>();
        readonly Dictionary<DefinitionId, CultivationDefinition> _cultivations =
            new Dictionary<DefinitionId, CultivationDefinition>();
        readonly Dictionary<DefinitionId, CombatArtDefinition> _combatArts =
            new Dictionary<DefinitionId, CombatArtDefinition>();
        readonly Dictionary<DefinitionId, ItemDefinition> _items =
            new Dictionary<DefinitionId, ItemDefinition>();
        readonly Dictionary<DefinitionId, BuildingDefinition> _buildings =
            new Dictionary<DefinitionId, BuildingDefinition>();
        readonly Dictionary<DefinitionId, OpportunitySiteDefinition> _opportunitySites =
            new Dictionary<DefinitionId, OpportunitySiteDefinition>();
        readonly Dictionary<DefinitionId, OpeningScenarioDefinition> _openingScenarios =
            new Dictionary<DefinitionId, OpeningScenarioDefinition>();
        readonly Dictionary<DefinitionId, CharacterRosterDefinition> _characterRosters =
            new Dictionary<DefinitionId, CharacterRosterDefinition>();
        readonly Dictionary<DefinitionId, ResourceDefinition> _resources =
            new Dictionary<DefinitionId, ResourceDefinition>();
        readonly Dictionary<DefinitionId, FacilityDefinition> _facilities =
            new Dictionary<DefinitionId, FacilityDefinition>();
        readonly Dictionary<DefinitionId, SettlementDefinition> _settlements =
            new Dictionary<DefinitionId, SettlementDefinition>();
        readonly Dictionary<DefinitionId, WorldRegionDefinition> _worldRegions =
            new Dictionary<DefinitionId, WorldRegionDefinition>();
        readonly Dictionary<DefinitionId, QuestDefinition> _quests =
            new Dictionary<DefinitionId, QuestDefinition>();
        readonly Dictionary<DefinitionId, ContentEventDefinition> _contentEvents =
            new Dictionary<DefinitionId, ContentEventDefinition>();
        readonly Dictionary<DefinitionId, ChapterDefinition> _chapters =
            new Dictionary<DefinitionId, ChapterDefinition>();
        readonly Dictionary<DefinitionId, WorkAreaContentDefinition> _workAreas =
            new Dictionary<DefinitionId, WorkAreaContentDefinition>();
        readonly Dictionary<DefinitionId, JobContentDefinition> _jobs =
            new Dictionary<DefinitionId, JobContentDefinition>();
        readonly Dictionary<DefinitionId, ScheduleContentDefinition> _schedules =
            new Dictionary<DefinitionId, ScheduleContentDefinition>();
        readonly Dictionary<DefinitionId, MapLayoutDefinition> _mapLayouts =
            new Dictionary<DefinitionId, MapLayoutDefinition>();
        readonly Dictionary<DefinitionId, RealmLadderDefinition> _realmLadders =
            new Dictionary<DefinitionId, RealmLadderDefinition>();
        readonly Dictionary<DefinitionId, SpawnTableDefinition> _spawnTables =
            new Dictionary<DefinitionId, SpawnTableDefinition>();
        readonly Dictionary<DefinitionId, LocalPlaceSetDefinition> _localPlaceSets =
            new Dictionary<DefinitionId, LocalPlaceSetDefinition>();
        readonly Dictionary<DefinitionId, HexWorldContentDefinition> _hexWorldContents =
            new Dictionary<DefinitionId, HexWorldContentDefinition>();
        readonly Dictionary<DefinitionId, FormalArmyDefinition> _formalArmies =
            new Dictionary<DefinitionId, FormalArmyDefinition>();
        readonly Dictionary<DefinitionId, StrategicFactionDefinition> _strategicFactions =
            new Dictionary<DefinitionId, StrategicFactionDefinition>();
        readonly Dictionary<DefinitionId, OutdoorWorldSurfaceDefinition> _outdoorSurfaces =
            new Dictionary<DefinitionId, OutdoorWorldSurfaceDefinition>();

        public IReadOnlyDictionary<DefinitionId, CharacterDefinition> Characters => _characters;
        public IReadOnlyDictionary<DefinitionId, CultivationDefinition> Cultivations => _cultivations;
        public IReadOnlyDictionary<DefinitionId, CombatArtDefinition> CombatArts => _combatArts;
        public IReadOnlyDictionary<DefinitionId, ItemDefinition> Items => _items;
        public IReadOnlyDictionary<DefinitionId, BuildingDefinition> Buildings => _buildings;
        public IReadOnlyDictionary<DefinitionId, OpportunitySiteDefinition> OpportunitySites => _opportunitySites;
        public IReadOnlyDictionary<DefinitionId, OpeningScenarioDefinition> OpeningScenarios => _openingScenarios;
        public IReadOnlyDictionary<DefinitionId, CharacterRosterDefinition> CharacterRosters => _characterRosters;
        public IReadOnlyDictionary<DefinitionId, ResourceDefinition> Resources => _resources;
        public IReadOnlyDictionary<DefinitionId, FacilityDefinition> Facilities => _facilities;
        public IReadOnlyDictionary<DefinitionId, SettlementDefinition> Settlements => _settlements;
        public IReadOnlyDictionary<DefinitionId, WorldRegionDefinition> WorldRegions => _worldRegions;
        public IReadOnlyDictionary<DefinitionId, QuestDefinition> Quests => _quests;
        public IReadOnlyDictionary<DefinitionId, ContentEventDefinition> ContentEvents => _contentEvents;
        public IReadOnlyDictionary<DefinitionId, ChapterDefinition> Chapters => _chapters;
        public IReadOnlyDictionary<DefinitionId, WorkAreaContentDefinition> WorkAreas => _workAreas;
        public IReadOnlyDictionary<DefinitionId, JobContentDefinition> Jobs => _jobs;
        public IReadOnlyDictionary<DefinitionId, ScheduleContentDefinition> Schedules => _schedules;
        public IReadOnlyDictionary<DefinitionId, MapLayoutDefinition> MapLayouts => _mapLayouts;
        public IReadOnlyDictionary<DefinitionId, RealmLadderDefinition> RealmLadders => _realmLadders;
        public IReadOnlyDictionary<DefinitionId, SpawnTableDefinition> SpawnTables => _spawnTables;
        public IReadOnlyDictionary<DefinitionId, LocalPlaceSetDefinition> LocalPlaceSets => _localPlaceSets;
        public IReadOnlyDictionary<DefinitionId, HexWorldContentDefinition> HexWorldContents => _hexWorldContents;
        public IReadOnlyDictionary<DefinitionId, FormalArmyDefinition> FormalArmies => _formalArmies;
        public IReadOnlyDictionary<DefinitionId, StrategicFactionDefinition> StrategicFactions => _strategicFactions;
        public IReadOnlyDictionary<DefinitionId, OutdoorWorldSurfaceDefinition> OutdoorSurfaces => _outdoorSurfaces;

        public bool ContainsId(DefinitionId id) =>
            _characters.ContainsKey(id) ||
            _cultivations.ContainsKey(id) ||
            _combatArts.ContainsKey(id) ||
            _items.ContainsKey(id) ||
            _buildings.ContainsKey(id) ||
            _opportunitySites.ContainsKey(id) ||
            _openingScenarios.ContainsKey(id) ||
            _characterRosters.ContainsKey(id) ||
            _resources.ContainsKey(id) ||
            _facilities.ContainsKey(id) ||
            _settlements.ContainsKey(id) ||
            _worldRegions.ContainsKey(id) ||
            _quests.ContainsKey(id) ||
            _contentEvents.ContainsKey(id) ||
            _chapters.ContainsKey(id) ||
            _workAreas.ContainsKey(id) ||
            _jobs.ContainsKey(id) ||
            _schedules.ContainsKey(id) ||
            _mapLayouts.ContainsKey(id) ||
            _realmLadders.ContainsKey(id) ||
            _spawnTables.ContainsKey(id) ||
            _localPlaceSets.ContainsKey(id) ||
            _hexWorldContents.ContainsKey(id) ||
            _formalArmies.ContainsKey(id) ||
            _strategicFactions.ContainsKey(id) ||
            _outdoorSurfaces.ContainsKey(id);

        public Result RegisterCharacter(CharacterDefinition definition)
        {
            if (definition == null)
                return Result.Failure(ErrorCode.InvalidArgument, "CharacterDefinition is null.");
            return Register(_characters, definition, definition.Id);
        }

        public Result RegisterCultivation(CultivationDefinition definition)
        {
            if (definition == null)
                return Result.Failure(ErrorCode.InvalidArgument, "CultivationDefinition is null.");
            return Register(_cultivations, definition, definition.Id);
        }

        public Result RegisterCombatArt(CombatArtDefinition definition)
        {
            if (definition == null)
                return Result.Failure(ErrorCode.InvalidArgument, "CombatArtDefinition is null.");
            return Register(_combatArts, definition, definition.Id);
        }

        public Result RegisterItem(ItemDefinition definition)
        {
            if (definition == null)
                return Result.Failure(ErrorCode.InvalidArgument, "ItemDefinition is null.");
            return Register(_items, definition, definition.Id);
        }

        public Result RegisterBuilding(BuildingDefinition definition)
        {
            if (definition == null)
                return Result.Failure(ErrorCode.InvalidArgument, "BuildingDefinition is null.");
            return Register(_buildings, definition, definition.Id);
        }

        public Result RegisterOpportunitySite(OpportunitySiteDefinition definition)
        {
            if (definition == null)
                return Result.Failure(ErrorCode.InvalidArgument, "OpportunitySiteDefinition is null.");
            return Register(_opportunitySites, definition, definition.Id);
        }

        public Result RegisterOpeningScenario(OpeningScenarioDefinition definition)
        {
            if (definition == null)
                return Result.Failure(ErrorCode.InvalidArgument, "OpeningScenarioDefinition is null.");
            return Register(_openingScenarios, definition, definition.Id);
        }

        public Result RegisterCharacterRoster(CharacterRosterDefinition definition)
        {
            if (definition == null)
                return Result.Failure(ErrorCode.InvalidArgument, "CharacterRosterDefinition is null.");
            return Register(_characterRosters, definition, definition.Id);
        }

        public Result RegisterResource(ResourceDefinition definition)
        {
            if (definition == null)
                return Result.Failure(ErrorCode.InvalidArgument, "ResourceDefinition is null.");
            return Register(_resources, definition, definition.Id);
        }

        public Result RegisterFacility(FacilityDefinition definition)
        {
            if (definition == null)
                return Result.Failure(ErrorCode.InvalidArgument, "FacilityDefinition is null.");
            return Register(_facilities, definition, definition.Id);
        }

        public Result RegisterSettlement(SettlementDefinition definition)
        {
            if (definition == null)
                return Result.Failure(ErrorCode.InvalidArgument, "SettlementDefinition is null.");
            return Register(_settlements, definition, definition.Id);
        }

        public Result RegisterWorldRegion(WorldRegionDefinition definition)
        {
            if (definition == null)
                return Result.Failure(ErrorCode.InvalidArgument, "WorldRegionDefinition is null.");
            return Register(_worldRegions, definition, definition.Id);
        }

        public Result RegisterQuest(QuestDefinition definition)
        {
            if (definition == null)
                return Result.Failure(ErrorCode.InvalidArgument, "QuestDefinition is null.");
            return Register(_quests, definition, definition.Id);
        }

        public Result RegisterContentEvent(ContentEventDefinition definition)
        {
            if (definition == null)
                return Result.Failure(ErrorCode.InvalidArgument, "ContentEventDefinition is null.");
            return Register(_contentEvents, definition, definition.Id);
        }

        public Result RegisterChapter(ChapterDefinition definition)
        {
            if (definition == null)
                return Result.Failure(ErrorCode.InvalidArgument, "ChapterDefinition is null.");
            return Register(_chapters, definition, definition.Id);
        }

        public Result RegisterWorkArea(WorkAreaContentDefinition definition)
        {
            if (definition == null)
                return Result.Failure(ErrorCode.InvalidArgument, "WorkAreaContentDefinition is null.");
            return Register(_workAreas, definition, definition.Id);
        }

        public Result RegisterJob(JobContentDefinition definition)
        {
            if (definition == null)
                return Result.Failure(ErrorCode.InvalidArgument, "JobContentDefinition is null.");
            return Register(_jobs, definition, definition.Id);
        }

        public Result RegisterSchedule(ScheduleContentDefinition definition)
        {
            if (definition == null)
                return Result.Failure(ErrorCode.InvalidArgument, "ScheduleContentDefinition is null.");
            return Register(_schedules, definition, definition.Id);
        }

        public Result RegisterMapLayout(MapLayoutDefinition definition)
        {
            if (definition == null)
                return Result.Failure(ErrorCode.InvalidArgument, "MapLayoutDefinition is null.");
            return Register(_mapLayouts, definition, definition.Id);
        }

        public Result RegisterRealmLadder(RealmLadderDefinition definition)
        {
            if (definition == null)
                return Result.Failure(ErrorCode.InvalidArgument, "RealmLadderDefinition is null.");
            return Register(_realmLadders, definition, definition.Id);
        }

        public Result RegisterSpawnTable(SpawnTableDefinition definition)
        {
            if (definition == null)
                return Result.Failure(ErrorCode.InvalidArgument, "SpawnTableDefinition is null.");
            return Register(_spawnTables, definition, definition.Id);
        }

        public Result RegisterLocalPlaceSet(LocalPlaceSetDefinition definition)
        {
            if (definition == null)
                return Result.Failure(ErrorCode.InvalidArgument, "LocalPlaceSetDefinition is null.");
            return Register(_localPlaceSets, definition, definition.Id);
        }

        public Result RegisterHexWorldContent(HexWorldContentDefinition definition)
        {
            if (definition == null)
                return Result.Failure(ErrorCode.InvalidArgument, "HexWorldContentDefinition is null.");
            return Register(_hexWorldContents, definition, definition.Id);
        }

        public Result RegisterFormalArmy(FormalArmyDefinition definition)
        {
            if (definition == null)
                return Result.Failure(ErrorCode.InvalidArgument, "FormalArmyDefinition is null.");
            return Register(_formalArmies, definition, definition.Id);
        }

        public Result RegisterStrategicFaction(StrategicFactionDefinition definition)
        {
            if (definition == null)
                return Result.Failure(ErrorCode.InvalidArgument, "StrategicFactionDefinition is null.");
            return Register(_strategicFactions, definition, definition.Id);
        }

        public Result RegisterOutdoorSurface(OutdoorWorldSurfaceDefinition definition)
        {
            if (definition == null || DefinitionId.Parse(definition.SurfaceId).IsFailure)
                return Result.Failure(ErrorCode.InvalidArgument, "OutdoorWorldSurfaceDefinition has invalid id.");
            return Register(_outdoorSurfaces, definition, DefinitionId.Parse(definition.SurfaceId).Value);
        }

        /// <summary>覆盖已有 mapLayout（Level Tester 热换地图文件）。</summary>
        public Result UpsertMapLayout(MapLayoutDefinition definition)
        {
            if (definition == null)
                return Result.Failure(ErrorCode.InvalidArgument, "MapLayoutDefinition is null.");
            _mapLayouts[definition.Id] = definition;
            return Result.Success();
        }

        public bool TryGetCharacter(DefinitionId id, out CharacterDefinition definition) =>
            _characters.TryGetValue(id, out definition);

        public bool TryGetCultivation(DefinitionId id, out CultivationDefinition definition) =>
            _cultivations.TryGetValue(id, out definition);

        public bool TryGetItem(DefinitionId id, out ItemDefinition definition) =>
            _items.TryGetValue(id, out definition);

        public bool TryGetBuilding(DefinitionId id, out BuildingDefinition definition) =>
            _buildings.TryGetValue(id, out definition);

        public bool TryGetOpportunitySite(DefinitionId id, out OpportunitySiteDefinition definition) =>
            _opportunitySites.TryGetValue(id, out definition);

        public bool TryGetOpeningScenario(DefinitionId id, out OpeningScenarioDefinition definition) =>
            _openingScenarios.TryGetValue(id, out definition);

        public bool TryGetCharacterRoster(DefinitionId id, out CharacterRosterDefinition definition) =>
            _characterRosters.TryGetValue(id, out definition);

        public bool TryGetResource(DefinitionId id, out ResourceDefinition definition) =>
            _resources.TryGetValue(id, out definition);

        public bool TryGetFacility(DefinitionId id, out FacilityDefinition definition) =>
            _facilities.TryGetValue(id, out definition);

        public bool TryGetSettlement(DefinitionId id, out SettlementDefinition definition) =>
            _settlements.TryGetValue(id, out definition);

        public bool TryGetWorldRegion(DefinitionId id, out WorldRegionDefinition definition) =>
            _worldRegions.TryGetValue(id, out definition);

        public bool TryGetQuest(DefinitionId id, out QuestDefinition definition) =>
            _quests.TryGetValue(id, out definition);

        public bool TryGetContentEvent(DefinitionId id, out ContentEventDefinition definition) =>
            _contentEvents.TryGetValue(id, out definition);

        public bool TryGetChapter(DefinitionId id, out ChapterDefinition definition) =>
            _chapters.TryGetValue(id, out definition);

        public bool TryGetWorkArea(DefinitionId id, out WorkAreaContentDefinition definition) =>
            _workAreas.TryGetValue(id, out definition);

        public bool TryGetJob(DefinitionId id, out JobContentDefinition definition) =>
            _jobs.TryGetValue(id, out definition);

        public bool TryGetSchedule(DefinitionId id, out ScheduleContentDefinition definition) =>
            _schedules.TryGetValue(id, out definition);

        public bool TryGetMapLayout(DefinitionId id, out MapLayoutDefinition definition) =>
            _mapLayouts.TryGetValue(id, out definition);

        public bool TryGetRealmLadder(DefinitionId id, out RealmLadderDefinition definition) =>
            _realmLadders.TryGetValue(id, out definition);

        public bool TryGetSpawnTable(DefinitionId id, out SpawnTableDefinition definition) =>
            _spawnTables.TryGetValue(id, out definition);

        public bool TryGetLocalPlaceSet(DefinitionId id, out LocalPlaceSetDefinition definition) =>
            _localPlaceSets.TryGetValue(id, out definition);

        public bool TryGetHexWorldContent(DefinitionId id, out HexWorldContentDefinition definition) =>
            _hexWorldContents.TryGetValue(id, out definition);

        public bool TryGetFormalArmy(DefinitionId id, out FormalArmyDefinition definition) =>
            _formalArmies.TryGetValue(id, out definition);

        public bool TryGetStrategicFaction(DefinitionId id, out StrategicFactionDefinition definition) =>
            _strategicFactions.TryGetValue(id, out definition);

        public bool TryGetOutdoorSurface(DefinitionId id, out OutdoorWorldSurfaceDefinition definition) =>
            _outdoorSurfaces.TryGetValue(id, out definition);

        /// <summary>Prefer content ladder; otherwise null.</summary>
        public bool TryGetPrimaryRealmLadder(out RealmLadderDefinition definition)
        {
            foreach (var kv in _realmLadders)
            {
                definition = kv.Value;
                return true;
            }

            definition = null;
            return false;
        }

        Result Register<T>(Dictionary<DefinitionId, T> map, T definition, DefinitionId id)
        {
            if (ContainsId(id))
                return Result.Failure(ErrorCode.DuplicateDefinitionId, "Duplicate DefinitionId.", id.ToString());
            map.Add(id, definition);
            return Result.Success();
        }
    }
}
