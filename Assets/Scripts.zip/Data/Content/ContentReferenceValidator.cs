using System;
using System.Collections.Generic;
using XianXia.Core.Content;
using XianXia.Core.Domain.Ids;
using XianXia.Core.Results;
using XianXia.Core.Social;
using XianXia.Core.World;
using XianXia.Core.World.Strategic;
using XianXia.Data.Bootstrap;

namespace XianXia.Data.Content
{
    /// <summary>
    /// Cross-reference check for chapter production packages (quest／event／flag／npc／location…).
    /// </summary>
    public sealed class ContentReferenceValidator
    {
        public ValidationReport Validate(DefinitionRegistry registry)
        {
            var report = new ValidationReport();
            if (registry == null)
            {
                report.Add(ErrorCode.InvalidArgument, "DefinitionRegistry is null.");
                return report;
            }

            var locations = CollectLocationIds(registry);
            if (registry.OutdoorSurfaces.Count > 0 && registry.SpatialRules == null)
                report.Add(ErrorCode.MissingRequiredField, "Continuous world requires worldSpatialRules.");
            ValidateOutdoorSurfaceMetrics(registry, report);
            if (registry.SpatialRules != null)
                foreach (var pair in registry.Buildings)
                    if (pair.Value.CreatesWorldSite)
                        try { registry.SpatialRules.RequireLevel(pair.Value.InitialSiteLevel); }
                        catch (InvalidOperationException ex) { report.Add(ErrorCode.InvalidArgument, ex.Message, pair.Key.ToString()); }
            var producedFlags = new HashSet<string>(StringComparer.Ordinal);
            var consumedFlags = new HashSet<string>(StringComparer.Ordinal);

            ValidateScenarios(registry, locations, report);
            ValidateFormalArmies(registry, report);
            ValidateNpcSquads(registry, report);
            ValidateStrategicFactions(registry, report);
            ValidateWorldRegions(registry, locations, report);
            ValidateLocalPlaceSets(registry, locations, report);
            ValidateItems(registry, report);
            ValidateBuildings(registry, report);
            ValidateSpawnTables(registry, report);
            ValidateMapSpawnZones(registry, locations, report);
            ValidateOutdoorSurfaceSitePlaceIdentities(registry, report);
            ValidateOutdoorControlCores(registry, report);
            ValidateOutdoorStorageRooms(registry, report);
            ValidateFactionFlagSiteCores(registry, report);
            ValidateWorldSiteEconomies(registry, report);
            ValidateQuests(registry, locations, producedFlags, consumedFlags, report);
            ValidateContentEvents(registry, locations, producedFlags, consumedFlags, report);
            ValidateChapters(registry, locations, producedFlags, consumedFlags, report);
            ValidateFlagConsumers(producedFlags, consumedFlags, report);

            return report;
        }

        static void ValidateOutdoorSurfaceMetrics(DefinitionRegistry registry, ValidationReport report)
        {
            foreach (var pair in registry.OutdoorSurfaces)
            {
                var surface = pair.Value;
                if (surface == null || string.IsNullOrWhiteSpace(surface.SurfaceId) ||
                    !IsFinite(surface.OriginWorldX) || !IsFinite(surface.OriginWorldY) ||
                    !(surface.CellSize > 0f) || !IsFinite(surface.CellSize) ||
                    !(surface.ChunkWidth > 0f) || !IsFinite(surface.ChunkWidth) ||
                    !(surface.ChunkHeight > 0f) || !IsFinite(surface.ChunkHeight) ||
                    surface.Chunks == null || surface.Chunks.Count == 0)
                {
                    report.Add(ErrorCode.InvalidArgument,
                        "Outdoor Surface requires identity, finite metric, and authored chunk coverage.",
                        pair.Key.ToString());
                    continue;
                }
                if (registry.TryGetOutdoorSurfaceGeography(surface.SurfaceId, out var geography) &&
                    geography?.Navigation != null &&
                    Math.Abs(geography.Navigation.CellSize - surface.CellSize) > .000001f)
                    report.Add(ErrorCode.InvalidArgument,
                        "Outdoor Surface and geography cellSize must match.", surface.SurfaceId);
            }
        }

        static void ValidateOutdoorControlCores(DefinitionRegistry registry, ValidationReport report)
        {
            var knownSites = CollectAuthoredSiteIds(registry);
            var controlCoreLocationCounts = new Dictionary<string, int>(StringComparer.Ordinal);
            foreach (var pair in registry.WorkAreas)
                if (pair.Value != null && pair.Value.IsControlCore &&
                    !string.IsNullOrWhiteSpace(pair.Value.LocationId))
                {
                    controlCoreLocationCounts.TryGetValue(pair.Value.LocationId, out var count);
                    controlCoreLocationCounts[pair.Value.LocationId] = count + 1;
                }
            foreach (var pair in registry.OutdoorSurfaces)
            {
                var surface = pair.Value;
                if (surface?.SitePlacements == null || surface.AcceptanceOnly) continue;
                var coreSites = new HashSet<string>(StringComparer.Ordinal);
                var chunks = new HashSet<XianXia.Core.World.Surface.SurfaceChunkCoord>();
                if (surface.Chunks != null)
                    for (var c = 0; c < surface.Chunks.Count; c++)
                        if (surface.Chunks[c] != null) chunks.Add(surface.Chunks[c].Coord);
                for (var i = 0; i < surface.SitePlacements.Count; i++)
                {
                    var placement = surface.SitePlacements[i];
                    if (placement == null ||
                        !string.Equals(placement.Kind, "controlCore", StringComparison.OrdinalIgnoreCase)) continue;
                    var context = surface.SurfaceId + ".controlCore[" + i + "]";
                    if (string.IsNullOrWhiteSpace(placement.StableId))
                        report.Add(ErrorCode.MissingRequiredField,
                            "Outdoor controlCore.stableId required.", context);
                    if (string.IsNullOrWhiteSpace(placement.SiteId))
                        report.Add(ErrorCode.MissingRequiredField,
                            "Outdoor controlCore.siteId required.", context);
                    if (string.IsNullOrWhiteSpace(placement.BoundLocationId))
                        report.Add(ErrorCode.MissingRequiredField,
                            "Outdoor controlCore.boundLocationId required.", context);
                    else if (!controlCoreLocationCounts.TryGetValue(placement.BoundLocationId, out var coreCount) ||
                             coreCount != 1)
                        report.Add(ErrorCode.NotFound,
                            "Outdoor controlCore.boundLocationId must reference exactly one ControlCore WorkArea.",
                            context + ":" + placement.BoundLocationId);
                    if (!coreSites.Add(placement.SiteId ?? string.Empty))
                        report.Add(ErrorCode.DuplicateDefinitionId,
                            "Outdoor WorldSite has more than one authored controlCore.", context);
                    if (!knownSites.Contains(placement.SiteId ?? string.Empty))
                        report.Add(ErrorCode.NotFound,
                            "Outdoor controlCore references an unknown WorldSite.", context);
                    if (registry.SpatialRules == null)
                        report.Add(ErrorCode.MissingRequiredField,
                            "Outdoor controlCore requires worldSpatialRules.", context);
                    else
                        try { registry.SpatialRules.RequireLevel(1); }
                        catch (InvalidOperationException ex)
                        { report.Add(ErrorCode.InvalidArgument, ex.Message, context); }
                    var centerX = placement.WorldX + placement.WorldWidth * .5f;
                    var centerY = placement.WorldY + placement.WorldHeight * .5f;
                    var centerIsAuthored = false;
                    if (surface.ChunkWidth > 0f && surface.ChunkHeight > 0f)
                    {
                        var centerChunk = new XianXia.Core.World.Surface.SurfaceChunkCoord(
                            (int)Math.Floor((centerX - surface.OriginWorldX) / surface.ChunkWidth),
                            (int)Math.Floor((centerY - surface.OriginWorldY) / surface.ChunkHeight));
                        centerIsAuthored = chunks.Contains(centerChunk);
                    }
                    if (!centerIsAuthored)
                        report.Add(ErrorCode.InvalidArgument,
                            "Outdoor controlCore center is outside authored Surface chunks.", context);
                }
            }
        }

        static void ValidateOutdoorStorageRooms(DefinitionRegistry registry, ValidationReport report)
        {
            var knownSites = CollectAuthoredSiteIds(registry);
            var storageSites = new HashSet<string>(StringComparer.Ordinal);
            foreach (var pair in registry.OutdoorSurfaces)
            {
                var surface = pair.Value;
                if (surface?.SitePlacements == null || surface.AcceptanceOnly) continue;
                for (var i = 0; i < surface.SitePlacements.Count; i++)
                {
                    var placement = surface.SitePlacements[i];
                    if (placement == null || !string.Equals(placement.Kind, "storageRoom", StringComparison.Ordinal))
                        continue;
                    var context = surface.SurfaceId + ".storageRoom[" + i + "]";
                    if (string.IsNullOrWhiteSpace(placement.SiteId) || !knownSites.Contains(placement.SiteId))
                        report.Add(ErrorCode.NotFound, "Outdoor storageRoom references an unknown WorldSite.", context);
                    else if (!storageSites.Add(placement.SiteId))
                        report.Add(ErrorCode.DuplicateDefinitionId,
                            "Outdoor WorldSite has more than one authored storageRoom.", context);
                    if (placement.SourceCellsW != 3 || placement.SourceCellsH != 3 || !placement.BlocksMovement)
                        report.Add(ErrorCode.InvalidArgument,
                            "Outdoor storageRoom must be 3x3 and block movement.", context);
                    if (placement.WorldWidth <= 0f || placement.WorldHeight <= 0f ||
                        surface.CellSize <= 0f || surface.ChunkWidth <= 0f || surface.ChunkHeight <= 0f)
                    {
                        report.Add(ErrorCode.InvalidArgument,
                            "Outdoor storageRoom requires positive Surface metric and physical bounds.", context);
                        continue;
                    }
                    var centerX = placement.WorldX + placement.WorldWidth * .5f;
                    var centerY = placement.WorldY + placement.WorldHeight * .5f;
                    var materializationChunk = new XianXia.Core.World.Surface.SurfaceChunkCoord(
                        (int)Math.Floor((centerX - surface.OriginWorldX) / surface.ChunkWidth),
                        (int)Math.Floor((centerY - surface.OriginWorldY) / surface.ChunkHeight));
                    if (placement.ChunkX != materializationChunk.X || placement.ChunkY != materializationChunk.Y)
                        report.Add(ErrorCode.InvalidArgument,
                            "Outdoor storageRoom declared chunk must own its physical center for SingleCentered materialization.",
                            context);
                    if (!OutdoorSurfaceCoverageResolver.ContainsWorldPosition(surface, centerX, centerY) ||
                        !OutdoorSurfaceCoverageResolver.ContainsWorldPosition(surface,
                            placement.WorldX + placement.WorldWidth - surface.CellSize * .001f,
                            placement.WorldY + placement.WorldHeight - surface.CellSize * .001f) ||
                        !OutdoorSurfaceCoverageResolver.ContainsWorldPosition(surface,
                            placement.WorldX + surface.CellSize * .001f,
                            placement.WorldY + surface.CellSize * .001f))
                        report.Add(ErrorCode.InvalidArgument,
                            "Outdoor storageRoom physical footprint must remain within authored Surface coverage.", context);
                }
            }
        }

        static void ValidateFactionFlagSiteCores(DefinitionRegistry registry, ValidationReport report)
        {
            var ids = new HashSet<string>(StringComparer.Ordinal);
            foreach (var worldPair in registry.HexWorldContents)
            {
                var definition = worldPair.Value;
                if (definition?.FactionFlags == null) continue;
                for (var i = 0; i < definition.FactionFlags.Count; i++)
                {
                    var flag = definition.FactionFlags[i];
                    if (flag == null) continue;
                    var context = definition.Id + ".factionFlags[" + i + "]";
                    if (!ids.Add(flag.FlagId ?? string.Empty))
                        report.Add(ErrorCode.DuplicateDefinitionId,
                            "FactionFlag flagId must be globally unique.", context);

                    if (!flag.CreatesWorldSite)
                    {
                        if (flag.HasWorldPosition || !string.IsNullOrWhiteSpace(flag.SurfaceId))
                            report.Add(ErrorCode.InvalidArgument,
                                "Precise FactionFlag position requires createsWorldSite=true.", context);
                        if (!flag.LegacyDebugOnly)
                            report.Add(ErrorCode.MissingRequiredField,
                                "Product FactionFlag requires Site-Core metadata; legacy-only flags must explicitly declare legacyDebugOnly=true.",
                                context);
                        continue;
                    }

                    if (flag.LegacyDebugOnly)
                        report.Add(ErrorCode.InvalidArgument,
                            "Site-Core FactionFlag cannot also be legacyDebugOnly.", context);

                    if (!flag.HasWorldPosition || string.IsNullOrWhiteSpace(flag.SurfaceId))
                    {
                        report.Add(ErrorCode.MissingRequiredField,
                            "Site-Core FactionFlag requires an explicit precise Surface position.", context);
                        continue;
                    }
                    if (flag.HasLocalPosition)
                        report.Add(ErrorCode.InvalidArgument,
                            "Site-Core FactionFlag cannot declare legacy local position authority.", context);
                    if (!IsFinite(flag.WorldX) || !IsFinite(flag.WorldY))
                        report.Add(ErrorCode.InvalidArgument,
                            "Site-Core FactionFlag world position must be finite.", context);
                    if (flag.CoreLevel < 1)
                        report.Add(ErrorCode.InvalidArgument,
                            "Site-Core FactionFlag coreLevel must be positive.", context);
                    else if (registry.SpatialRules == null)
                        report.Add(ErrorCode.MissingRequiredField,
                            "Site-Core FactionFlag requires worldSpatialRules.", context);
                    else
                        try { registry.SpatialRules.RequireLevel(flag.CoreLevel); }
                        catch (InvalidOperationException ex)
                        { report.Add(ErrorCode.InvalidArgument, ex.Message, context); }

                    OutdoorWorldSurfaceDefinition authoredSurface = null;
                    foreach (var surfacePair in registry.OutdoorSurfaces)
                        if (string.Equals(surfacePair.Value?.SurfaceId, flag.SurfaceId, StringComparison.Ordinal))
                        {
                            authoredSurface = surfacePair.Value;
                            break;
                        }
                    if (authoredSurface == null)
                    {
                        report.Add(ErrorCode.NotFound,
                            "Site-Core FactionFlag references an unknown Surface.", context);
                        continue;
                    }
                    if (!OutdoorSurfaceCoverageResolver.TryResolveAtWorldPosition(
                            registry, flag.WorldX, flag.WorldY, out var resolved) ||
                        resolved == null ||
                        !string.Equals(resolved.SurfaceId, flag.SurfaceId, StringComparison.Ordinal))
                        report.Add(ErrorCode.InvalidArgument,
                            "Site-Core FactionFlag precise point is outside its unique authored Surface.", context);
                }
            }
        }

        static bool IsFinite(float value) => !float.IsNaN(value) && !float.IsInfinity(value);

        static HashSet<string> CollectLocationIds(DefinitionRegistry registry)
        {
            var set = new HashSet<string>(StringComparer.Ordinal);
            foreach (var kv in registry.WorldRegions)
                AddLocationIds(set, kv.Value?.Locations);
            foreach (var kv in registry.LocalPlaceSets)
                AddLocationIds(set, kv.Value?.Locations);
            foreach (var kv in registry.OutdoorSurfaces)
            {
                var placements = kv.Value?.SitePlacements;
                if (placements == null)
                    continue;
                foreach (var placement in placements)
                    if (!string.IsNullOrWhiteSpace(placement?.BoundLocationId))
                        set.Add(placement.BoundLocationId);
            }
            return set;
        }

        static void AddLocationIds(HashSet<string> set, System.Collections.Generic.List<WorldLocationEntry> locs)
        {
            if (locs == null)
                return;
            for (var i = 0; i < locs.Count; i++)
            {
                if (!string.IsNullOrEmpty(locs[i].Id))
                    set.Add(locs[i].Id);
            }
        }

        static void ValidateItems(DefinitionRegistry registry, ValidationReport report)
        {
            foreach (var kv in registry.Items)
            {
                var item = kv.Value;
                if (item == null)
                    continue;
                if (!string.IsNullOrWhiteSpace(item.TeachesManualId))
                {
                    RequireDef(
                        registry,
                        item.TeachesManualId,
                        "cultivation",
                        item.Id + ".teachesManualId",
                        report);
                }

                if (!string.IsNullOrWhiteSpace(item.TeachesArtId))
                {
                    RequireDef(
                        registry,
                        item.TeachesArtId,
                        "combatArt",
                        item.Id + ".teachesArtId",
                        report);
                }
            }
        }

        static void ValidateSpawnTables(DefinitionRegistry registry, ValidationReport report)
        {
            foreach (var kv in registry.SpawnTables)
            {
                var table = kv.Value;
                if (table?.Entries == null)
                    continue;
                for (var i = 0; i < table.Entries.Count; i++)
                {
                    var e = table.Entries[i];
                    if (e == null)
                        continue;
                    RequireDef(
                        registry,
                        e.DefinitionId,
                        "character",
                        table.Id + ".entries[" + i + "].definitionId",
                        report);
                }
            }
        }

        /// <summary>
        /// §8：opening population 的 LocationId → Site 解析必须**唯一可消解**。同名 locationId 被多个 Site
        /// 复用却缺少 source localMapId 时，解析无法确定归属 —— 必须报 Content validation error，
        /// 绝不允许运行期静默选第一个 Site。
        /// </summary>
        static void ValidateOutdoorSurfaceSitePlaceIdentities(
            DefinitionRegistry registry,
            ValidationReport report)
        {
            var index = ContinuousOutdoorSitePlaceIndex.Build(registry);
            var issues = index.ValidateAmbiguities();
            for (var i = 0; i < issues.Count; i++)
                report.Add(ErrorCode.DuplicateDefinitionId, issues[i], "outdoorSurface.sitePlaces");
        }

        static void ValidateMapSpawnZones(
            DefinitionRegistry registry,
            HashSet<string> locations,
            ValidationReport report)
        {
            foreach (var kv in registry.MapLayouts)
            {
                var layout = kv.Value;
                if (layout?.Placements == null)
                    continue;
                for (var i = 0; i < layout.Placements.Count; i++)
                {
                    var p = layout.Placements[i];
                    if (p == null ||
                        !string.Equals(p.Kind, "spawnZone", StringComparison.OrdinalIgnoreCase))
                        continue;
                    var ctx = layout.Id + ".placements[" + p.Id + "]";
                    if (string.IsNullOrWhiteSpace(p.SpawnTableId))
                    {
                        report.Add(
                            ErrorCode.MissingRequiredField,
                            "spawnZone.spawnTableId required.",
                            ctx);
                    }
                    else
                        RequireDef(registry, p.SpawnTableId, "spawnTable", ctx + ".spawnTableId", report);
                    if (string.IsNullOrWhiteSpace(p.BoundLocationId))
                    {
                        report.Add(
                            ErrorCode.MissingRequiredField,
                            "spawnZone.boundLocationId required.",
                            ctx);
                    }
                    else if (!locations.Contains(p.BoundLocationId))
                    {
                        report.Add(
                            ErrorCode.NotFound,
                            "spawnZone.boundLocationId missing in worldRegion.",
                            ctx + ":" + p.BoundLocationId);
                    }
                }
            }
        }

        /// <summary>
        /// characterRoster.entries 与 openingScenario.spawns 同形，支持 optional authored placement。
        /// definitionId → character；jobId → job；localLocationId → 已存在地点表。
        /// worldSiteId 依赖配对 scenario 的 HexWorld context，此处不猜测。
        /// </summary>
        void ValidateCharacterRosters(
            DefinitionRegistry registry,
            HashSet<string> locations,
            ValidationReport report)
        {
            foreach (var kv in registry.CharacterRosters)
            {
                var roster = kv.Value;
                var ctx = kv.Key.ToString();
                if (roster.Entries == null)
                    continue;
                for (var i = 0; i < roster.Entries.Count; i++)
                {
                    var entry = roster.Entries[i];
                    RequireDef(registry, entry.DefinitionId, "character", ctx + ".entry[" + i + "]", report);
                    if (!string.IsNullOrWhiteSpace(entry.JobId))
                        RequireDef(registry, entry.JobId, "job", ctx + ".entry[" + i + "].jobId", report);
                    if (!string.IsNullOrWhiteSpace(entry.LocalLocationId) &&
                        !locations.Contains(entry.LocalLocationId))
                    {
                        report.Add(
                            ErrorCode.NotFound,
                            "roster.entry.localLocationId missing in any localPlaceSet/worldRegion.",
                            ctx + ".entry[" + i + "].localLocationId:" + entry.LocalLocationId);
                    }
                }
            }
        }

        void ValidateScenarios(
            DefinitionRegistry registry,
            HashSet<string> locations,
            ValidationReport report)
        {
            foreach (var kv in registry.OpeningScenarios)
            {
                var s = kv.Value;
                var ctx = s.Id.ToString();
                foreach (var entry in s.StartingInventory)
                    if (entry == null || entry.Count <= 0 || !DefinitionId.TryParse(entry.ItemId, out var itemId) ||
                        (!registry.Resources.ContainsKey(itemId) && !registry.Items.ContainsKey(itemId)))
                        report.Add(ErrorCode.InvalidArgument, "Invalid startingInventory item/count.", ctx);

                RequireDef(registry, s.OpeningWorldRegionId, "worldRegion", ctx + ".openingWorldRegionId", report);
                RequireDef(registry, s.OpeningLocalPlaceSetId, "localPlaceSet", ctx + ".openingLocalPlaceSetId", report);
                RequireDef(registry, s.OpeningHexWorldId, "hexWorld", ctx + ".openingHexWorldId", report);
                RequireDef(registry, s.OpeningChapterId, "chapter", ctx + ".openingChapterId", report);

                OutdoorWorldSurfaceDefinition openingSurface = null;
                if (!string.IsNullOrWhiteSpace(s.OpeningSurfaceId))
                {
                    if (!DefinitionId.TryParse(s.OpeningSurfaceId, out var surfaceId) ||
                        !registry.TryGetOutdoorSurface(surfaceId, out openingSurface) ||
                        openingSurface == null || openingSurface.AcceptanceOnly ||
                        !registry.TryGetOutdoorSurfaceGeography(s.OpeningSurfaceId, out var surfaceGeography) ||
                        surfaceGeography?.Navigation == null)
                        report.Add(ErrorCode.NotFound, "openingSurfaceId requires a normal Surface and navigation geography.",
                            ctx + ".openingSurfaceId:" + s.OpeningSurfaceId);
                }

                var hexWorld = ResolveScenarioHexWorld(registry, s, ctx, report);
                var worldSites = new HashSet<string>(StringComparer.Ordinal);
                if (openingSurface == null && hexWorld?.Sites != null)
                {
                    for (var si = 0; si < hexWorld.Sites.Count; si++)
                    {
                        if (!string.IsNullOrEmpty(hexWorld.Sites[si].SiteId))
                            worldSites.Add(hexWorld.Sites[si].SiteId);
                    }
                }
                if (openingSurface?.SiteRegions != null)
                    foreach (var region in openingSurface.SiteRegions)
                        if (region != null && !string.IsNullOrEmpty(region.SiteId))
                            worldSites.Add(region.SiteId);
                if (openingSurface?.OpeningEntityAnchors != null)
                {
                    var anchorKeys = new HashSet<string>(StringComparer.Ordinal);
                    registry.TryGetOutdoorSurfaceGeography(s.OpeningSurfaceId, out var openingGeography);
                    foreach (var anchor in openingSurface.OpeningEntityAnchors)
                    {
                        if (anchor == null || !worldSites.Contains(anchor.SiteId) ||
                            string.IsNullOrWhiteSpace(anchor.SpawnKey) ||
                            string.IsNullOrWhiteSpace(anchor.DefinitionId) ||
                            !anchorKeys.Add(anchor.SpawnKey) ||
                            openingGeography?.Navigation == null ||
                            !openingGeography.Navigation.IsWalkable(anchor.WorldX, anchor.WorldY))
                            report.Add(ErrorCode.InvalidArgument, "Invalid or duplicate opening Surface entity anchor.",
                                ctx + ".openingSurfaceId:" + s.OpeningSurfaceId);
                    }
                }

                if (s.Spawns == null)
                    continue;
                var spawnOrdinals = new Dictionary<string, int>(StringComparer.Ordinal);
                for (var i = 0; i < s.Spawns.Count; i++)
                {
                    var spawn = s.Spawns[i];
                    if (spawn == null || string.IsNullOrWhiteSpace(spawn.DefinitionId))
                    {
                        report.Add(ErrorCode.InvalidArgument, "Opening spawn definitionId missing.", ctx + ".spawn[" + i + "]");
                        continue;
                    }
                    var spawnDefinitionId = spawn.DefinitionId.Trim();
                    spawnOrdinals.TryGetValue(spawnDefinitionId, out var ordinal);
                    spawnOrdinals[spawnDefinitionId] = ordinal + 1;
                    if (openingSurface != null)
                    {
                        var key = XianXia.Core.World.OpeningSpawnIdentityBoard.BuildStableKey(spawnDefinitionId, ordinal);
                        if (!ContinuousOutdoorOpeningAnchorResolver.TryFindOpeningEntityAnchor(
                                openingSurface, key, spawnDefinitionId, out var matchedAnchor,
                                out var anchorFailure))
                            report.Add(ErrorCode.InvalidArgument,
                                "Opening spawn requires exactly one matching Surface anchor: " + anchorFailure,
                                ctx + ".spawn[" + i + "]:" + key);
                        else if (!string.IsNullOrWhiteSpace(spawn.WorldSiteId) &&
                                 !string.Equals(spawn.WorldSiteId.Trim(), matchedAnchor.SiteId,
                                     StringComparison.Ordinal))
                            report.Add(ErrorCode.InvalidArgument,
                                "Opening spawn worldSiteId differs from Surface anchor SiteId.",
                                ctx + ".spawn[" + i + "]:" + key);
                    }
                    RequireDef(registry, spawn.DefinitionId, "character", ctx + ".spawn[" + i + "]", report);
                    if (!string.IsNullOrWhiteSpace(spawn.JobId))
                        RequireDef(registry, spawn.JobId, "job", ctx + ".spawn[" + i + "].jobId", report);

                    // Optional authored placement 校验：
                    // localLocationId 必须存在于某个 LocalPlaceSet／WorldRegion 地点表。
                    // worldSiteId 必须存在于该 scenario 的 OpeningHexWorldId 对应 HexWorld 站点。
                    if (!string.IsNullOrWhiteSpace(spawn.LocalLocationId))
                    {
                        if (!locations.Contains(spawn.LocalLocationId))
                        {
                            report.Add(
                                ErrorCode.NotFound,
                                "spawn.localLocationId missing in any localPlaceSet/worldRegion.",
                                ctx + ".spawn[" + i + "].localLocationId:" + spawn.LocalLocationId);
                        }
                    }

                    if (!string.IsNullOrWhiteSpace(spawn.WorldSiteId))
                    {
                        if (hexWorld == null && openingSurface == null)
                        {
                            report.Add(
                                ErrorCode.InvalidArgument,
                                "spawn.worldSiteId requires scenario.openingSurfaceId or legacy openingHexWorldId.",
                                ctx + ".spawn[" + i + "].worldSiteId:" + spawn.WorldSiteId);
                        }
                        else if (!worldSites.Contains(spawn.WorldSiteId))
                        {
                            report.Add(
                                ErrorCode.NotFound,
                                "spawn.worldSiteId missing in opening world sites.",
                                ctx + ".spawn[" + i + "].worldSiteId:" + spawn.WorldSiteId);
                        }
                    }
                }

                if (s.OpeningRelations != null)
                {
                    for (var i = 0; i < s.OpeningRelations.Count; i++)
                    {
                        var e = s.OpeningRelations[i];
                        RequireDef(registry, e.FromDefinitionId, "character", ctx + ".relation.from", report);
                        RequireDef(registry, e.ToDefinitionId, "character", ctx + ".relation.to", report);
                    }
                }

                if (s.OpeningBonds != null)
                {
                    var uniqueBonds = new HashSet<string>(StringComparer.Ordinal);
                    for (var i = 0; i < s.OpeningBonds.Count; i++)
                    {
                        var bond = s.OpeningBonds[i];
                        if (bond == null)
                            continue;
                        var bondCtx = ctx + ".openingBonds[" + i + "]";
                        RequireDef(registry, bond.FromDefinitionId, "character", bondCtx + ".from", report);
                        RequireDef(registry, bond.ToDefinitionId, "character", bondCtx + ".to", report);
                        if (string.IsNullOrWhiteSpace(bond.FromDefinitionId) ||
                            string.IsNullOrWhiteSpace(bond.ToDefinitionId) ||
                            string.Equals(bond.FromDefinitionId, bond.ToDefinitionId, StringComparison.Ordinal))
                        {
                            report.Add(ErrorCode.InvalidArgument, "openingBond endpoints must be distinct.", bondCtx);
                            continue;
                        }
                        var from = bond.FromDefinitionId;
                        var to = bond.ToDefinitionId;
                        if (SocialBond.IsSymmetric(bond.Kind) && string.CompareOrdinal(from, to) > 0)
                        {
                            var swap = from;
                            from = to;
                            to = swap;
                        }
                        var key = ((int)bond.Kind) + "|" + from + "|" + to;
                        if (!uniqueBonds.Add(key))
                            report.Add(ErrorCode.DuplicateDefinitionId, "openingBond duplicate.", bondCtx);
                    }
                }

                if (s.InitialFormalArmyIds != null)
                {
                    for (var i = 0; i < s.InitialFormalArmyIds.Count; i++)
                    {
                        var armyId = s.InitialFormalArmyIds[i];
                        RequireDef(registry, armyId, "formalArmy", ctx + ".initialFormalArmyIds[" + i + "]", report);
                        ValidateInitialFormalArmySurfacePosition(registry, armyId,
                            ctx + ".initialFormalArmyIds[" + i + "]", report);
                        ValidateInitialFormalArmyHex(registry, armyId, hexWorld, ctx + ".initialFormalArmyIds[" + i + "]", report);
                    }
                }
                if (s.InitialNpcSquadIds != null)
                {
                    for (var i = 0; i < s.InitialNpcSquadIds.Count; i++)
                        RequireDef(registry, s.InitialNpcSquadIds[i], "npcSquad",
                            ctx + ".initialNpcSquadIds[" + i + "]", report);
                }
            }
        }

        static void ValidateInitialFormalArmySurfacePosition(
            DefinitionRegistry registry, string armyIdText, string ctx, ValidationReport report)
        {
            if (!DefinitionId.TryParse(armyIdText, out var armyId) ||
                !registry.FormalArmies.TryGetValue(armyId, out var def) ||
                def == null)
                return;
            if (def.InitialSurfaceDeployment != null)
            {
                var deployment = def.InitialSurfaceDeployment;
                if (string.IsNullOrWhiteSpace(deployment.SurfaceId) ||
                    string.IsNullOrWhiteSpace(deployment.AnchorSiteId) ||
                    !registry.TryGetOutdoorSurfaceGeography(deployment.SurfaceId,
                        out var deploymentGeography) ||
                    deploymentGeography?.Navigation == null)
                {
                    report.Add(ErrorCode.InvalidArgument,
                        "formalArmy.initialSurfaceDeployment requires a valid Surface and anchorSiteId.",
                        ctx + ":" + def.Id);
                    return;
                }

                var coreCount = 0;
                var coreX = 0f;
                var coreY = 0f;
                foreach (var pair in registry.OutdoorSurfaces)
                {
                    var surface = pair.Value;
                    if (surface == null || surface.AcceptanceOnly ||
                        !string.Equals(surface.SurfaceId, deployment.SurfaceId, StringComparison.Ordinal))
                        continue;
                    foreach (var placement in surface.SitePlacements)
                    {
                        if (placement == null ||
                            !string.Equals(placement.SiteId, deployment.AnchorSiteId,
                                StringComparison.Ordinal) ||
                            !string.Equals(placement.Kind, "controlCore",
                                StringComparison.OrdinalIgnoreCase))
                            continue;
                        coreCount++;
                        coreX = placement.WorldX + placement.WorldWidth * .5f;
                        coreY = placement.WorldY + placement.WorldHeight * .5f;
                    }
                }
                if (coreCount != 1)
                {
                    report.Add(ErrorCode.InvalidArgument,
                        "formalArmy.initialSurfaceDeployment requires exactly one authored Site Core.",
                        ctx + ":" + def.Id);
                    return;
                }
                var nav = deploymentGeography.Navigation;
                var x = coreX + deployment.OffsetCellsX * nav.CellSize;
                var y = coreY + deployment.OffsetCellsY * nav.CellSize;
                if (!nav.Contains(x, y) || !nav.IsWalkable(x, y))
                    report.Add(ErrorCode.InvalidArgument,
                        "formalArmy.initialSurfaceDeployment is outside bounds or blocked.",
                        ctx + ":" + def.Id);
                return;
            }
            if (def.InitialSurfacePosition == null) return;
            var position = def.InitialSurfacePosition;
            if (string.IsNullOrWhiteSpace(position.SurfaceId) ||
                !registry.TryGetOutdoorSurfaceGeography(position.SurfaceId, out var geography) ||
                geography?.Navigation == null ||
                !geography.Navigation.IsWalkable(position.WorldX, position.WorldY))
                report.Add(ErrorCode.InvalidArgument,
                    "formalArmy.initialSurfacePosition must be walkable on its Surface.",
                    ctx + ":" + def.Id);
        }

        /// <summary>
        /// FormalArmy.initialHex 是 scenario-aware：坐标是否合法取决于该 scenario
        /// 选的 OpeningHexWorld。在 bounds 内且 passable、且不属于任何 WorldSite footprint
        /// 才合法（footprint 内应改用 assemblySiteId 的 AtWorldSite 部署）。
        /// </summary>
        static void ValidateInitialFormalArmyHex(
            DefinitionRegistry registry,
            string armyIdText,
            HexWorldContentDefinition hexWorld,
            string ctx,
            ValidationReport report)
        {
            if (string.IsNullOrWhiteSpace(armyIdText) ||
                !DefinitionId.TryParse(armyIdText, out var armyId))
                return;
            if (!registry.FormalArmies.TryGetValue(armyId, out var def) || def == null)
                return;
            if (def.InitialHex == null)
                return;

            if (hexWorld == null)
            {
                report.Add(
                    ErrorCode.InvalidArgument,
                    "formalArmy.initialHex requires scenario.openingHexWorldId.",
                    ctx + ":" + def.Id);
                return;
            }

            var q = def.InitialHex.Q;
            var r = def.InitialHex.R;
            if (q < 0 || r < 0 || q >= hexWorld.Width || r >= hexWorld.Height)
            {
                report.Add(
                    ErrorCode.InvalidArgument,
                    "formalArmy.initialHex out of hex world bounds.",
                    ctx + ":" + def.Id + " (q=" + q + ", r=" + r + ")");
                return;
            }

            if (!IsCellPassable(hexWorld, q, r))
            {
                report.Add(
                    ErrorCode.InvalidArgument,
                    "formalArmy.initialHex not passable in opening hex world.",
                    ctx + ":" + def.Id + " (q=" + q + ", r=" + r + ")");
            }

            if (hexWorld.Sites != null)
            {
                for (var i = 0; i < hexWorld.Sites.Count; i++)
                {
                    var site = hexWorld.Sites[i];
                    if (site?.Footprint == null)
                        continue;
                    for (var f = 0; f < site.Footprint.Count; f++)
                    {
                        if (site.Footprint[f] == null)
                            continue;
                        if (site.Footprint[f].Q == q && site.Footprint[f].R == r)
                        {
                            report.Add(
                                ErrorCode.InvalidArgument,
                                "formalArmy.initialHex inside WorldSite footprint; use assemblySiteId for AtWorldSite deployment.",
                                ctx + ":" + def.Id + " (q=" + q + ", r=" + r + " in " + site.SiteId + ")");
                            return;
                        }
                    }
                }
            }
        }

        static bool IsCellPassable(HexWorldContentDefinition hexWorld, int q, int r)
        {
            if (hexWorld?.Cells != null)
            {
                for (var i = 0; i < hexWorld.Cells.Count; i++)
                {
                    var cell = hexWorld.Cells[i];
                    if (cell == null || cell.Q != q || cell.R != r)
                        continue;
                    return cell.Passable ?? hexWorld.DefaultPassable;
                }
            }

            return hexWorld != null && hexWorld.DefaultPassable;
        }

        /// <summary>解析 scenario 的 OpeningHexWorld；缺省时返回 null（含错误已记录）。</summary>
        static HexWorldContentDefinition ResolveScenarioHexWorld(
            DefinitionRegistry registry,
            OpeningScenarioDefinition scenario,
            string ctx,
            ValidationReport report)
        {
            var hexWorldId = scenario?.OpeningHexWorldId;
            if (string.IsNullOrWhiteSpace(hexWorldId))
                return null;
            if (!DefinitionId.TryParse(hexWorldId, out var id))
            {
                report.Add(ErrorCode.InvalidDefinitionId, "Invalid openingHexWorldId.", ctx + ":" + hexWorldId);
                return null;
            }

            if (!registry.HexWorldContents.TryGetValue(id, out var def))
            {
                report.Add(ErrorCode.NotFound, "openingHexWorldId missing.", ctx + ":" + hexWorldId);
                return null;
            }

            return def;
        }


        /// <summary>
        /// 每个 member.characterDefinitionId 必须存在；runtimeArmyId / runtimeStackId 全局唯一；
        /// 恰好一个 leader 已在 Load 层验证，这里再补成员数 / 引用完整性。
        /// </summary>
        /// <summary>
        /// Strategic Faction cross-reference：formalArmy.factionId / legacy scenario.openingFactionId /
        /// spawns factionId / roster entries factionId / hexWorld site.ownerFactionId /
        /// territoryRegion.controlFactionId 引用的 faction 必须存在于 StrategicFactions。
        /// 未知引用 = Content Validation ERROR（不得静默随机颜色）。空引用不校验。
        /// </summary>
        static void ValidateStrategicFactions(DefinitionRegistry registry, ValidationReport report)
        {
            // CharacterDefinition.defaultFaction* 一致性 + 存在性（Case A/B）。
            foreach (var kv in registry.Characters)
            {
                var character = kv.Value;
                if (character == null)
                    continue;
                var hasDefaultFaction = !string.IsNullOrWhiteSpace(character.DefaultFactionId);
                var hasDefaultRole = !string.IsNullOrWhiteSpace(character.DefaultFactionRole);
                if (hasDefaultFaction)
                {
                    RequireFaction(registry, character.DefaultFactionId, character.Id + ".defaultFactionId", report, allowEmpty: false);
                    if (!hasDefaultRole ||
                        !Enum.TryParse(character.DefaultFactionRole.Trim(), true, out FactionRoleKind role) ||
                        role == FactionRoleKind.None)
                    {
                        report.Add(
                            ErrorCode.InvalidArgument,
                            "Character defaultFactionId requires a non-None defaultFactionRole.",
                            character.Id + ".defaultFactionRole");
                    }
                }
                else if (hasDefaultRole)
                {
                    report.Add(
                        ErrorCode.InvalidArgument,
                        "Character defaultFactionRole requires defaultFactionId.",
                        character.Id + ".defaultFactionRole");
                }
            }

            foreach (var kv in registry.FormalArmies)
            {
                var def = kv.Value;
                if (def == null)
                    continue;
                RequireFaction(registry, def.FactionId, def.Id + ".factionId", report, allowEmpty: false);
            }

            foreach (var kv in registry.OpeningScenarios)
            {
                var scenario = kv.Value;
                if (scenario == null)
                    continue;
                RequireFaction(registry, scenario.OpeningFactionId, scenario.Id + ".openingFactionId", report, allowEmpty: true);
                ValidateStrategicOpening(registry, scenario, report);
                if (scenario.Spawns == null)
                    continue;
                for (var i = 0; i < scenario.Spawns.Count; i++)
                {
                    var spawn = scenario.Spawns[i];
                    if (spawn == null)
                        continue;
                    ValidateSpawnMembership(registry, spawn, scenario.Id + ".spawns[" + i + "]", report);
                }
            }

            foreach (var kv in registry.CharacterRosters)
            {
                var roster = kv.Value;
                if (roster?.Entries == null)
                    continue;
                for (var i = 0; i < roster.Entries.Count; i++)
                {
                    var entry = roster.Entries[i];
                    if (entry == null)
                        continue;
                    ValidateSpawnMembership(registry, entry, roster.Id + ".entries[" + i + "]", report);
                }
            }

            foreach (var kv in registry.HexWorldContents)
            {
                var world = kv.Value;
                if (world == null)
                    continue;
                var worldCtx = world.Id.ToString();
                if (world.Sites != null)
                {
                    for (var i = 0; i < world.Sites.Count; i++)
                    {
                        var site = world.Sites[i];
                        if (site == null)
                            continue;
                        RequireFaction(
                            registry,
                            site.OwnerFactionId,
                            worldCtx + ".sites[" + i + "]:" + site.SiteId + ".ownerFactionId",
                            report);
                    }
                }

                if (world.TerritoryRegions != null)
                {
                    for (var i = 0; i < world.TerritoryRegions.Count; i++)
                    {
                        var region = world.TerritoryRegions[i];
                        if (region == null)
                            continue;
                        RequireFaction(
                            registry,
                            region.ControlFactionId,
                            worldCtx + ".territoryRegions[" + i + "]:" + region.RegionId + ".controlFactionId",
                            report);
                    }
                }

                if (world.StandaloneTerritoryHexes != null)
                {
                    for (var i = 0; i < world.StandaloneTerritoryHexes.Count; i++)
                    {
                        var control = world.StandaloneTerritoryHexes[i];
                        if (control == null)
                            continue;
                        RequireFaction(
                            registry,
                            control.ControlFactionId,
                            worldCtx + ".standaloneTerritoryHexes[" + i + "]:(" +
                            control.Q + "," + control.R + ").controlFactionId",
                            report);
                    }
                }
            }
        }

        static void ValidateBuildings(DefinitionRegistry registry, ValidationReport report)
        {
            foreach (var kv in registry.Buildings)
            {
                var building = kv.Value;
                if (building == null)
                    continue;
                if (building.PlacementKind != "factionFlag" && building.PlacementKind != "farmField" &&
                    building.PlacementKind != "recoverySpot" && building.PlacementKind != "storageRoom")
                    report.Add(ErrorCode.InvalidArgument, "Unknown building placementKind.",
                        building.Id + ".placementKind:" + building.PlacementKind);
                if (building.PlacementKind == "farmField" && (building.CreatesWorldSite ||
                    !XianXia.Core.Exploration.OutdoorAdministrativeAssetSemantics.IsAdministrativeAssetKind(building.OutdoorKind) ||
                    building.FootprintCellsW <= 0 || building.FootprintCellsH <= 0))
                    report.Add(ErrorCode.InvalidArgument, "Invalid farmField kind, dimensions or createsWorldSite.", building.Id.ToString());
                if (building.PlacementKind == "recoverySpot" && (building.CreatesWorldSite ||
                    !string.Equals(building.OutdoorKind, "recoverySpot", StringComparison.Ordinal) ||
                    building.FootprintCellsW != 2 || building.FootprintCellsH != 2))
                    report.Add(ErrorCode.InvalidArgument, "Invalid recoverySpot kind, 2x2 dimensions or createsWorldSite.", building.Id.ToString());
                if (building.PlacementKind == "storageRoom" && (building.CreatesWorldSite ||
                    !string.Equals(building.OutdoorKind, "storageRoom", StringComparison.Ordinal) ||
                    building.FootprintCellsW != 3 || building.FootprintCellsH != 3 ||
                    building.DismantleRefundRate != 0f))
                    report.Add(ErrorCode.InvalidArgument,
                        "Invalid storageRoom kind, 3x3 dimensions, createsWorldSite or dismantle refund.", building.Id.ToString());
                if (building.Costs == null)
                    continue;
                for (var i = 0; i < building.Costs.Count; i++)
                {
                    var cost = building.Costs[i];
                    if (cost == null || string.IsNullOrWhiteSpace(cost.ItemId) ||
                        !DefinitionId.TryParse(cost.ItemId, out var id) ||
                        (!registry.Resources.ContainsKey(id) && !registry.Items.ContainsKey(id)))
                        report.Add(ErrorCode.NotFound, "building cost must reference a resource or item.",
                            building.Id + ".costs[" + i + "]:" + (cost?.ItemId ?? string.Empty));
                }
            }
        }

        static void ValidateStrategicOpening(DefinitionRegistry registry, OpeningScenarioDefinition scenario, ValidationReport report)
        {
            var s = scenario.StrategicOpening;
            if (s == null) return;
            var ctx = scenario.Id + ".strategicOpening";
            RequireFaction(registry, s.PlayerFactionId, ctx + ".playerFactionId", report, false);
            var vassals = new Dictionary<string, string>(StringComparer.Ordinal);
            var allianceMembers = new HashSet<string>(StringComparer.Ordinal);
            var alliancePairs = new HashSet<string>(StringComparer.Ordinal);
            for (var i = 0; i < s.Vassalages.Count; i++)
            {
                var v = s.Vassalages[i]; var p = ctx + ".vassalages[" + i + "]";
                RequireFaction(registry, v.VassalFactionId, p + ".vassalFactionId", report, false); RequireFaction(registry, v.OverlordFactionId, p + ".overlordFactionId", report, false);
                if (v.VassalFactionId == v.OverlordFactionId) report.Add(ErrorCode.InvalidArgument, "Opening vassal and overlord must differ.", p);
                if (vassals.ContainsKey(v.VassalFactionId)) report.Add(ErrorCode.InvalidArgument, "Faction '" + v.VassalFactionId + "' has duplicate/conflicting authored overlord.", p);
                else vassals[v.VassalFactionId] = v.OverlordFactionId;
            }
            foreach (var v in vassals) if (vassals.ContainsKey(v.Value)) report.Add(ErrorCode.InvalidArgument, "Opening vassalage nesting is not supported: " + v.Key + " -> " + v.Value, ctx + ".vassalages");
            for (var i = 0; i < s.Alliances.Count; i++)
            {
                var a=s.Alliances[i]; var p=ctx+".alliances["+i+"]"; RequireFaction(registry,a.FactionAId,p+".factionAId",report,false); RequireFaction(registry,a.FactionBId,p+".factionBId",report,false);
                var key=string.CompareOrdinal(a.FactionAId,a.FactionBId)<=0?a.FactionAId+"|"+a.FactionBId:a.FactionBId+"|"+a.FactionAId;
                if(a.FactionAId==a.FactionBId||!alliancePairs.Add(key)||!allianceMembers.Add(a.FactionAId)||!allianceMembers.Add(a.FactionBId)||vassals.ContainsKey(a.FactionAId)||vassals.ContainsKey(a.FactionBId)) report.Add(ErrorCode.InvalidArgument,"Opening alliance is invalid or conflicts with authored membership/vassalage.",p);
            }
            var wars=new HashSet<string>(StringComparer.Ordinal);
            for(var i=0;i<s.InitialWars.Count;i++){var w=s.InitialWars[i];var p=ctx+".initialWars["+i+"]";RequireFaction(registry,w.DeclarerFactionId,p+".declarerFactionId",report,false);RequireFaction(registry,w.TargetFactionId,p+".targetFactionId",report,false);var key=string.CompareOrdinal(w.DeclarerFactionId,w.TargetFactionId)<=0?w.DeclarerFactionId+"|"+w.TargetFactionId:w.TargetFactionId+"|"+w.DeclarerFactionId;if(w.DeclarerFactionId==w.TargetFactionId||!wars.Add(key)||alliancePairs.Contains(key))report.Add(ErrorCode.InvalidArgument,"Opening war declarer and target must differ and cannot duplicate/allied pair.",p);}
        }

        static void ValidateSpawnMembership(
            DefinitionRegistry registry,
            OpeningSpawnEntry entry,
            string context,
            ValidationReport report)
        {
            var hasFaction = !string.IsNullOrWhiteSpace(entry.FactionId);
            var hasRole = !string.IsNullOrWhiteSpace(entry.FactionRole) &&
                          Enum.TryParse(entry.FactionRole.Trim(), true, out FactionRoleKind role) &&
                          role != FactionRoleKind.None;
            var modeExplicit = entry.FactionModeExplicit;

            switch (entry.FactionMode)
            {
                case OpeningFactionMode.Override:
                    // Override：factionId 非空 + role 有效 + faction 存在。
                    if (!hasFaction)
                    {
                        report.Add(ErrorCode.InvalidArgument,
                            "Spawn factionMode=Override requires factionId.", context + ".factionId");
                        return;
                    }
                    RequireFaction(registry, entry.FactionId, context + ".factionId", report, allowEmpty: false);
                    if (!hasRole)
                        report.Add(ErrorCode.InvalidArgument,
                            "Spawn factionMode=Override requires a non-None factionRole.", context + ".factionRole");
                    return;

                case OpeningFactionMode.Unaffiliated:
                    // Unaffiliated：禁止 factionId/factionRole。
                    if (hasFaction || !string.IsNullOrWhiteSpace(entry.FactionRole))
                    {
                        report.Add(ErrorCode.InvalidArgument,
                            "Spawn factionMode=Unaffiliated must not carry factionId/factionRole.", context + ".factionId");
                    }
                    return;

                case OpeningFactionMode.CharacterDefault:
                default:
                    if (modeExplicit)
                    {
                        // 显式 CharacterDefault：新格式 spawn 自己不得带 factionId/factionRole。
                        if (hasFaction || !string.IsNullOrWhiteSpace(entry.FactionRole))
                        {
                            report.Add(ErrorCode.InvalidArgument,
                                "Spawn factionMode=CharacterDefault must not carry factionId/factionRole (inherit CharacterDefinition).",
                                context + ".factionId");
                        }
                        return;
                    }

                    // mode 缺省：区分三态。
                    if (hasFaction)
                    {
                        // Legacy Explicit Override：无 mode 但显式 factionId → 按 Override 校验（deprecated）。
                        RequireFaction(registry, entry.FactionId, context + ".factionId", report, allowEmpty: false);
                        if (!hasRole)
                            report.Add(ErrorCode.InvalidArgument, "Spawn factionId requires a non-None factionRole.", context + ".factionRole");
                        return;
                    }

                    if (entry.AssignOpeningFaction)
                    {
                        // Legacy assignOpeningFaction：role 与 scenario.openingFactionId 的隐式继承仍被接受。
                        if (!hasRole)
                            report.Add(ErrorCode.InvalidArgument, "Legacy assignOpeningFaction requires a non-None factionRole.", context + ".factionRole");
                        return;
                    }

                    if (!string.IsNullOrWhiteSpace(entry.FactionRole))
                        report.Add(ErrorCode.InvalidArgument, "Spawn factionRole requires factionId.", context + ".factionRole");
                    return;
            }
        }

        /// <summary>factionId 必须能解析为 DefinitionId 且存在于 StrategicFactions；成员资格不检查 territorySelectable。</summary>
        static void RequireFaction(
            DefinitionRegistry registry,
            string factionId,
            string ctx,
            ValidationReport report,
            bool allowEmpty = true)
        {
            if (string.IsNullOrEmpty(factionId))
            {
                if (!allowEmpty)
                    report.Add(ErrorCode.MissingRequiredField, "strategicFaction reference required.", ctx);
                return;
            }
            if (!DefinitionId.TryParse(factionId, out var id) ||
                !registry.TryGetStrategicFaction(id, out _))
            {
                report.Add(
                    ErrorCode.NotFound,
                    "strategicFaction reference missing: " + factionId,
                    ctx);
            }
        }

        static void ValidateFormalArmies(DefinitionRegistry registry, ValidationReport report)
        {
            var seenArmyIds = new HashSet<string>(StringComparer.Ordinal);
            var seenStackIds = new HashSet<string>(StringComparer.Ordinal);

            foreach (var kv in registry.FormalArmies)
            {
                var def = kv.Value;
                var ctx = def.Id.ToString();
                if (def.Members == null || def.Members.Count == 0)
                {
                    report.Add(ErrorCode.MissingRequiredField, "formalArmy.members empty.", ctx);
                    continue;
                }

                if (!string.IsNullOrEmpty(def.RuntimeArmyId) && !seenArmyIds.Add(def.RuntimeArmyId))
                {
                    report.Add(
                        ErrorCode.DuplicateDefinitionId,
                        "Duplicate formalArmy.runtimeArmyId.",
                        ctx + ":" + def.RuntimeArmyId);
                }

                if (!string.IsNullOrEmpty(def.RuntimeStackId) && !seenStackIds.Add(def.RuntimeStackId))
                {
                    report.Add(
                        ErrorCode.DuplicateDefinitionId,
                        "Duplicate formalArmy.runtimeStackId.",
                        ctx + ":" + def.RuntimeStackId);
                }

                for (var i = 0; i < def.Members.Count; i++)
                {
                    var member = def.Members[i];
                    if (member == null)
                        continue;
                    RequireDef(
                        registry,
                        member.CharacterDefinitionId,
                        "character",
                        ctx + ".members[" + i + "].characterDefinitionId",
                        report);
                }
            }
        }

        static void ValidateNpcSquads(DefinitionRegistry registry, ValidationReport report)
        {
            var squadIds = new HashSet<string>(StringComparer.Ordinal);
            foreach (var pair in registry.NpcSquads)
            {
                var def = pair.Value;
                var ctx = def.Id.ToString();
                if (!squadIds.Add(def.SquadId)) report.Add(ErrorCode.DuplicateDefinitionId, "Duplicate npcSquad.squadId.", ctx);
                RequireFaction(registry, def.FactionId, ctx + ".factionId", report, false);
                if (def.Members == null || def.Members.Count == 0) report.Add(ErrorCode.MissingRequiredField, "npcSquad.members empty.", ctx);
                else for (var i = 0; i < def.Members.Count; i++)
                    RequireDef(registry, def.Members[i].CharacterDefinitionId, "character", ctx + ".members[" + i + "].characterDefinitionId", report);
                if (def.InitialSurfacePosition != null)
                {
                    var position = def.InitialSurfacePosition;
                    if (!registry.TryGetOutdoorSurfaceGeography(position.SurfaceId, out var geography) ||
                        geography?.Navigation == null)
                        report.Add(ErrorCode.NotFound, "npcSquad initial position Surface geography missing.",
                            ctx + ":" + position.SurfaceId);
                    else if (!geography.Navigation.Contains(position.WorldX, position.WorldY) ||
                             !geography.Navigation.IsWalkable(position.WorldX, position.WorldY))
                        report.Add(ErrorCode.InvalidArgument, "npcSquad initial position is outside or blocked.", ctx);
                }
                else if (def.InitialSurfaceDeployment != null)
                {
                    var deployment = def.InitialSurfaceDeployment;
                    if (!registry.TryGetOutdoorSurfaceGeography(deployment.SurfaceId, out var geography) ||
                        geography?.Navigation == null)
                        report.Add(ErrorCode.NotFound, "npcSquad deployment Surface geography missing.",
                            ctx + ":" + deployment.SurfaceId);
                    else if (!NpcSquadContentBootstrap.TryResolveCoreCenter(registry,
                                 deployment.AnchorSiteId, deployment.SurfaceId, out var anchor))
                        report.Add(ErrorCode.NotFound, "npcSquad deployment anchor Site is not exactly resolvable.",
                            ctx + ":" + deployment.AnchorSiteId);
                    else
                    {
                        var point = new WorldVec2(
                            anchor.X + deployment.OffsetCellsX * geography.Navigation.CellSize,
                            anchor.Y + deployment.OffsetCellsY * geography.Navigation.CellSize);
                        if (!geography.Navigation.Contains(point.X, point.Y) ||
                            !geography.Navigation.IsWalkable(point.X, point.Y))
                            report.Add(ErrorCode.InvalidArgument,
                                "npcSquad deployment result is outside or blocked.", ctx);
                    }
                }
                else if (!TryResolveNpcSquadSiteArrival(registry, def.AssemblySiteId,
                             out var arrivalSurface, out var arrival))
                    report.Add(ErrorCode.NotFound, "npcSquad AssemblySite has no unique SiteArrival.",
                        ctx + ":" + def.AssemblySiteId);
                else if (!registry.TryGetOutdoorSurfaceGeography(arrivalSurface, out var arrivalGeography) ||
                         arrivalGeography?.Navigation == null ||
                         !arrivalGeography.Navigation.Contains(arrival.X, arrival.Y) ||
                         !arrivalGeography.Navigation.IsWalkable(arrival.X, arrival.Y))
                    report.Add(ErrorCode.InvalidArgument,
                        "npcSquad AssemblySite SiteArrival is outside or blocked.", ctx);
            }
        }

        static bool TryResolveNpcSquadSiteArrival(DefinitionRegistry registry, string siteId,
            out string surfaceId, out WorldVec2 arrival)
        {
            surfaceId = string.Empty;
            arrival = default;
            if (registry == null || string.IsNullOrWhiteSpace(siteId)) return false;
            var found = false;
            foreach (var pair in registry.OutdoorSurfaces)
            {
                var surface = pair.Value;
                if (surface?.SiteRegions == null) continue;
                for (var i = 0; i < surface.SiteRegions.Count; i++)
                {
                    var region = surface.SiteRegions[i];
                    if (region == null || !string.Equals(region.SiteId, siteId, StringComparison.Ordinal)) continue;
                    if (found) return false;
                    surfaceId = string.IsNullOrWhiteSpace(region.SurfaceId)
                        ? surface.SurfaceId : region.SurfaceId;
                    arrival = new WorldVec2(region.ArrivalWorldX, region.ArrivalWorldY);
                    found = true;
                }
            }
            return found;
        }

        void ValidateWorldRegions(
            DefinitionRegistry registry,
            HashSet<string> locations,
            ValidationReport report)
        {
            foreach (var kv in registry.WorldRegions)
            {
                var region = kv.Value;
                var ctx = region.Id.ToString();
                if (!string.IsNullOrEmpty(region.StartLocationId) && !locations.Contains(region.StartLocationId))
                    report.Add(ErrorCode.NotFound, "startLocationId missing in locations.", ctx + ":" + region.StartLocationId);

                if (region.Locations == null)
                    continue;
                for (var i = 0; i < region.Locations.Count; i++)
                {
                    var loc = region.Locations[i];
                    var lctx = ctx + "." + loc.Id;
                    if (loc.AdjacentIds != null)
                    {
                        for (var a = 0; a < loc.AdjacentIds.Count; a++)
                        {
                            if (!locations.Contains(loc.AdjacentIds[a]))
                                report.Add(ErrorCode.NotFound, "adjacent location missing.", lctx + "->" + loc.AdjacentIds[a]);
                        }
                    }

                    RequireDef(registry, loc.OpportunitySiteId, "opportunitySite", lctx + ".opportunitySiteId", report);
                    RequireDef(registry, loc.ResidentNpcDefinitionId, "character", lctx + ".residentNpc", report);
                    RequireDef(registry, loc.ResourceOnExploreId, "resource", lctx + ".resourceOnExploreId", report);
                    ScanConditions(loc.EnterConditions, registry, locations, null, null, lctx + ".enter", report);
                    if (loc.QuestOfferIds != null)
                    {
                        for (var q = 0; q < loc.QuestOfferIds.Count; q++)
                            RequireDef(registry, loc.QuestOfferIds[q], "quest", lctx + ".questOffer", report);
                    }
                }
            }
        }

        void ValidateLocalPlaceSets(
            DefinitionRegistry registry,
            HashSet<string> locations,
            ValidationReport report)
        {
            foreach (var kv in registry.LocalPlaceSets)
            {
                var set = kv.Value;
                var ctx = set.Id.ToString();
                if (!string.IsNullOrEmpty(set.MapLayoutId))
                {
                    var mapParsed = DefinitionId.Parse(set.MapLayoutId);
                    if (mapParsed.IsFailure || !registry.MapLayouts.ContainsKey(mapParsed.Value))
                    {
                        report.Add(
                            ErrorCode.NotFound,
                            "localPlaceSet.mapLayoutId missing.",
                            ctx + ":" + set.MapLayoutId);
                    }
                }

                if (!string.IsNullOrEmpty(set.StartLocationId) && !locations.Contains(set.StartLocationId))
                    report.Add(ErrorCode.NotFound, "startLocationId missing in locations.", ctx + ":" + set.StartLocationId);

                if (set.Locations == null)
                    continue;
                for (var i = 0; i < set.Locations.Count; i++)
                {
                    var loc = set.Locations[i];
                    var lctx = ctx + "." + loc.Id;
                    if (loc.AdjacentIds != null)
                    {
                        for (var a = 0; a < loc.AdjacentIds.Count; a++)
                        {
                            if (!locations.Contains(loc.AdjacentIds[a]))
                                report.Add(ErrorCode.NotFound, "adjacent location missing.", lctx + "->" + loc.AdjacentIds[a]);
                        }
                    }

                    RequireDef(registry, loc.OpportunitySiteId, "opportunitySite", lctx + ".opportunitySiteId", report);
                    RequireDef(registry, loc.ResidentNpcDefinitionId, "character", lctx + ".residentNpc", report);
                    RequireDef(registry, loc.ResourceOnExploreId, "resource", lctx + ".resourceOnExploreId", report);
                    ScanConditions(loc.EnterConditions, registry, locations, null, null, lctx + ".enter", report);
                    if (loc.QuestOfferIds != null)
                    {
                        for (var q = 0; q < loc.QuestOfferIds.Count; q++)
                            RequireDef(registry, loc.QuestOfferIds[q], "quest", lctx + ".questOffer", report);
                    }
                }
            }
        }

        void ValidateQuests(
            DefinitionRegistry registry,
            HashSet<string> locations,
            HashSet<string> producedFlags,
            HashSet<string> consumedFlags,
            ValidationReport report)
        {
            foreach (var kv in registry.Quests)
            {
                var q = kv.Value;
                var ctx = q.Id.ToString();
                ScanConditions(q.OfferConditions, registry, locations, producedFlags, consumedFlags, ctx + ".offer", report);
                ScanConditions(q.CompleteConditions, registry, locations, producedFlags, consumedFlags, ctx + ".complete", report);
                ScanConditions(q.FailConditions, registry, locations, producedFlags, consumedFlags, ctx + ".fail", report);
                ScanOutcomes(q.Rewards, registry, locations, producedFlags, consumedFlags, ctx + ".reward", report);
                ScanOutcomes(q.FailResults, registry, locations, producedFlags, consumedFlags, ctx + ".failResult", report);
            }
        }

        void ValidateContentEvents(
            DefinitionRegistry registry,
            HashSet<string> locations,
            HashSet<string> producedFlags,
            HashSet<string> consumedFlags,
            ValidationReport report)
        {
            foreach (var kv in registry.ContentEvents)
            {
                var e = kv.Value;
                var ctx = e.Id.ToString();
                if (!string.IsNullOrEmpty(e.LocationId) && !locations.Contains(e.LocationId))
                    report.Add(ErrorCode.NotFound, "contentEvent.locationId missing.", ctx + ":" + e.LocationId);
                RequireDef(registry, e.QuestId, "quest", ctx + ".questId", report);
                ScanConditions(e.Conditions, registry, locations, producedFlags, consumedFlags, ctx + ".cond", report);
                if (e.Choices == null)
                    continue;
                for (var i = 0; i < e.Choices.Count; i++)
                {
                    var c = e.Choices[i];
                    var cctx = ctx + ".choice." + c.Id;
                    ScanConditions(c.Conditions, registry, locations, producedFlags, consumedFlags, cctx, report);
                    ScanOutcomes(c.Outcomes, registry, locations, producedFlags, consumedFlags, cctx, report);
                }
            }
        }

        void ValidateChapters(
            DefinitionRegistry registry,
            HashSet<string> locations,
            HashSet<string> producedFlags,
            HashSet<string> consumedFlags,
            ValidationReport report)
        {
            foreach (var kv in registry.Chapters)
            {
                var ch = kv.Value;
                var ctx = ch.Id.ToString();
                // openingScenarioId is documentary; warn only if set and missing
                if (!string.IsNullOrEmpty(ch.OpeningScenarioId))
                    RequireDef(registry, ch.OpeningScenarioId, "openingScenario", ctx + ".openingScenarioId", report);

                for (var i = 0; i < ch.QuestChainIds.Count; i++)
                    RequireDef(registry, ch.QuestChainIds[i], "quest", ctx + ".questChain", report);
                for (var i = 0; i < ch.EventChainIds.Count; i++)
                    RequireDef(registry, ch.EventChainIds[i], "contentEvent", ctx + ".eventChain", report);

                for (var b = 0; b < ch.DayBeats.Count; b++)
                {
                    var beat = ch.DayBeats[b];
                    var bctx = ctx + ".dayBeat[" + beat.DayIndex + "]";
                    ScanConditions(beat.Conditions, registry, locations, producedFlags, consumedFlags, bctx, report);
                    for (var i = 0; i < beat.QuestOfferIds.Count; i++)
                        RequireDef(registry, beat.QuestOfferIds[i], "quest", bctx + ".questOffer", report);
                    for (var i = 0; i < beat.ContentEventIds.Count; i++)
                        RequireDef(registry, beat.ContentEventIds[i], "contentEvent", bctx + ".event", report);
                    for (var i = 0; i < beat.SetFlags.Count; i++)
                    {
                        if (!string.IsNullOrEmpty(beat.SetFlags[i]))
                            producedFlags.Add(beat.SetFlags[i]);
                    }
                }
            }
        }

        void ScanConditions(
            IList<ContentCondition> conditions,
            DefinitionRegistry registry,
            HashSet<string> locations,
            HashSet<string> producedFlags,
            HashSet<string> consumedFlags,
            string ctx,
            ValidationReport report)
        {
            if (conditions == null)
                return;
            for (var i = 0; i < conditions.Count; i++)
            {
                var c = conditions[i];
                if (c == null || string.IsNullOrEmpty(c.Kind))
                    continue;
                var kind = c.Kind.Trim().ToLowerInvariant();
                switch (kind)
                {
                    case "atlocation":
                    case "exploredlocation":
                        if (!string.IsNullOrEmpty(c.Id) && !locations.Contains(c.Id))
                            report.Add(ErrorCode.NotFound, "condition location missing.", ctx + ":" + c.Id);
                        break;
                    case "laboratlocation":
                    case "uniquelaboratlocation":
                    case "uniqueharvestatlocation":
                        if (!string.IsNullOrEmpty(c.Id) && !locations.Contains(c.Id))
                            report.Add(ErrorCode.NotFound, "condition location missing.", ctx + ":" + c.Id);
                        if (kind == "laboratlocation" && !string.IsNullOrEmpty(c.CharacterId))
                            RequireDef(registry, c.CharacterId, "character", ctx + "." + c.Kind, report);
                        break;
                    case "characteratlocation":
                        if (!string.IsNullOrEmpty(c.Id) && !locations.Contains(c.Id))
                            report.Add(ErrorCode.NotFound, "condition location missing.", ctx + ":" + c.Id);
                        if (!string.IsNullOrEmpty(c.CharacterId))
                            RequireDef(registry, c.CharacterId, "character", ctx + "." + c.Kind, report);
                        break;
                    case "knowssite":
                        RequireDef(registry, c.Id, "opportunitySite", ctx + ".knowsSite", report);
                        break;
                    case "stockatleast":
                        RequireDef(registry, c.Id, "resource", ctx + ".stock", report);
                        break;
                    case "questactive":
                    case "questcompleted":
                        RequireDef(registry, c.Id, "quest", ctx + ".quest", report);
                        break;
                    case "hasmanual":
                        RequireDef(registry, c.Id, "cultivation", ctx + ".manual", report);
                        break;
                    case "counteratleast":
                    case "missingdailyflag":
                    case "hasdailyflag":
                        if (string.IsNullOrEmpty(c.Id))
                        {
                            report.Add(
                                ErrorCode.MissingRequiredField,
                                c.Kind + " requires id.",
                                ctx);
                        }

                        break;
                    case "encountercleared":
                        if (string.IsNullOrEmpty(c.Id))
                        {
                            report.Add(
                                ErrorCode.MissingRequiredField,
                                "encounterCleared requires id.",
                                ctx);
                        }
                        else if (consumedFlags != null)
                        {
                            consumedFlags.Add(ContentConditionEvaluator.EncounterFlag(c.Id));
                        }

                        break;
                    case "hasflag":
                    case "storyflag":
                    case "missingflag":
                    case "missingstoryflag":
                        if (!string.IsNullOrEmpty(c.Id) && consumedFlags != null)
                            consumedFlags.Add(c.Id);
                        break;
                }
            }
        }

        void ScanOutcomes(
            IList<ContentOutcome> outcomes,
            DefinitionRegistry registry,
            HashSet<string> locations,
            HashSet<string> producedFlags,
            HashSet<string> consumedFlags,
            string ctx,
            ValidationReport report)
        {
            if (outcomes == null)
                return;
            for (var i = 0; i < outcomes.Count; i++)
            {
                var o = outcomes[i];
                if (o == null || string.IsNullOrEmpty(o.Kind))
                    continue;
                var kind = o.Kind.Trim().ToLowerInvariant();
                switch (kind)
                {
                    case "setflag":
                    case "setstoryflag":
                        if (!string.IsNullOrEmpty(o.Id) && producedFlags != null)
                            producedFlags.Add(o.Id);
                        break;
                    case "clearflag":
                    case "clearstoryflag":
                        if (!string.IsNullOrEmpty(o.Id) && consumedFlags != null)
                            consumedFlags.Add(o.Id);
                        break;
                    case "addstock":
                    {
                        if (string.IsNullOrEmpty(o.Id) || !DefinitionId.TryParse(o.Id, out var stockId))
                        {
                            RequireDef(registry, o.Id, "resource", ctx + ".addStock", report);
                            break;
                        }

                        if (registry.Resources.ContainsKey(stockId) || registry.Items.ContainsKey(stockId))
                            break;
                        report.Add(
                            ErrorCode.NotFound,
                            "resource/item reference missing.",
                            ctx + ".addStock:" + o.Id);
                        break;
                    }
                    case "startquest":
                        RequireDef(registry, o.Id, "quest", ctx + ".startQuest", report);
                        break;
                    case "discoversite":
                        RequireDef(registry, o.Id, "opportunitySite", ctx + ".discoverSite", report);
                        break;
                    case "learnmanual":
                        RequireDef(registry, o.Id, "cultivation", ctx + ".learnManual", report);
                        break;
                    case "addcounter":
                    case "setcounter":
                    case "setdailyflag":
                    case "cleardailyflag":
                        if (string.IsNullOrEmpty(o.Id))
                        {
                            report.Add(
                                ErrorCode.MissingRequiredField,
                                o.Kind + " requires id.",
                                ctx);
                        }

                        break;
                    case "setencountercleared":
                        if (string.IsNullOrEmpty(o.Id))
                        {
                            report.Add(
                                ErrorCode.MissingRequiredField,
                                o.Kind + " requires id.",
                                ctx);
                        }
                        else if (producedFlags != null)
                        {
                            producedFlags.Add(ContentConditionEvaluator.EncounterFlag(o.Id));
                        }

                        break;
                    case "relationdelta":
                        RequireDef(registry, o.FromDefinitionId, "character", ctx + ".relation.from", report);
                        if (o.ToDefinitionIds.Count > 0)
                        {
                            for (var ti = 0; ti < o.ToDefinitionIds.Count; ti++)
                            {
                                var targetId = o.ToDefinitionIds[ti];
                                if (string.Equals(targetId, "@party", StringComparison.OrdinalIgnoreCase))
                                    continue;
                                RequireDef(registry, targetId, "character", ctx + ".relation.to", report);
                            }
                        }
                        else if (!string.IsNullOrEmpty(o.ToDefinitionId))
                        {
                            if (!string.Equals(o.ToDefinitionId, "@party", StringComparison.OrdinalIgnoreCase))
                                RequireDef(registry, o.ToDefinitionId, "character", ctx + ".relation.to", report);
                        }
                        else
                        {
                            report.Add(
                                ErrorCode.MissingRequiredField,
                                "relationDelta requires toDefinitionId or toDefinitionIds.",
                                ctx);
                        }

                        break;
                }
            }
        }

        static void ValidateFlagConsumers(
            HashSet<string> producedFlags,
            HashSet<string> consumedFlags,
            ValidationReport report)
        {
            foreach (var flag in consumedFlags)
            {
                if (IsRuntimeProducedFlag(flag))
                    continue;
                if (!producedFlags.Contains(flag))
                {
                    report.Add(
                        ErrorCode.NotFound,
                        "Flag consumed but never produced by content outcomes／dayBeats.",
                        flag);
                }
            }
        }

        static bool IsRuntimeProducedFlag(string flag)
        {
            if (string.IsNullOrEmpty(flag))
                return true;
            // Core exploration writes explored:<locationId>
            if (flag.StartsWith("explored:", StringComparison.Ordinal))
                return true;
            // setEncounterCleared writes encounter:<id>
            if (flag.StartsWith("encounter:", StringComparison.Ordinal))
                return true;
            // SupervisorPressureHandler writes this at day end.
            if (string.Equals(flag, "story:supervisor_pressure", StringComparison.Ordinal))
                return true;
            return false;
        }

        static void ValidateWorldSiteEconomies(DefinitionRegistry registry, ValidationReport report)
        {
            var siteIds = CollectAuthoredSiteIds(registry);
            foreach (var worldPair in registry.HexWorldContents)
            {
                var hexWorld = worldPair.Value;
                if (hexWorld?.Sites != null)
                    for (var i = 0; i < hexWorld.Sites.Count; i++)
                        if (!string.IsNullOrWhiteSpace(hexWorld.Sites[i]?.SiteId)) siteIds.Add(hexWorld.Sites[i].SiteId);
                if (hexWorld?.FactionFlags != null)
                    for (var i = 0; i < hexWorld.FactionFlags.Count; i++)
                    {
                        var flag = hexWorld.FactionFlags[i];
                        if (flag != null && flag.CreatesWorldSite && !string.IsNullOrWhiteSpace(flag.FlagId))
                            siteIds.Add(FactionFlagService.SiteIdForCoreFlag(flag.FlagId));
                    }
            }
            var boundSites = new HashSet<string>(StringComparer.Ordinal);
            foreach (var pair in registry.WorldSiteEconomies)
            {
                var economy = pair.Value;
                var context = pair.Key.ToString();
                if (economy == null || string.IsNullOrWhiteSpace(economy.SiteId) || !siteIds.Contains(economy.SiteId))
                    report.Add(ErrorCode.NotFound, "worldSiteEconomy.siteId must reference an authored WorldSite.", context);
                else if (!boundSites.Add(economy.SiteId))
                    report.Add(ErrorCode.DuplicateDefinitionId, "WorldSite has duplicate economy definitions.", economy.SiteId);
                var resources = new HashSet<string>(StringComparer.Ordinal);
                if (economy?.InitialPublicStock == null) continue;
                for (var i = 0; i < economy.InitialPublicStock.Count; i++)
                {
                    var entry = economy.InitialPublicStock[i];
                    if (entry == null || entry.Amount < 0 || string.IsNullOrWhiteSpace(entry.ResourceId) ||
                        !DefinitionId.TryParse(entry.ResourceId, out var resourceId) ||
                        !registry.Resources.ContainsKey(resourceId))
                        report.Add(ErrorCode.InvalidArgument, "Invalid worldSiteEconomy stock resource/amount.", context + "[" + i + "]");
                    else if (!resources.Add(entry.ResourceId))
                        report.Add(ErrorCode.DuplicateDefinitionId, "Duplicate worldSiteEconomy resource.", context + ":" + entry.ResourceId);
                }
            }
        }

        static HashSet<string> CollectAuthoredSiteIds(DefinitionRegistry registry)
        {
            var ids = new HashSet<string>(StringComparer.Ordinal);
            foreach (var pair in registry.OutdoorSurfaces)
                if (pair.Value?.SiteRegions != null && !pair.Value.AcceptanceOnly)
                    foreach (var region in pair.Value.SiteRegions)
                        if (!string.IsNullOrWhiteSpace(region?.SiteId)) ids.Add(region.SiteId);
            foreach (var pair in registry.HexWorldContents)
                if (pair.Value?.Sites != null)
                    foreach (var site in pair.Value.Sites)
                        if (!string.IsNullOrWhiteSpace(site?.SiteId)) ids.Add(site.SiteId);
            return ids;
        }

        static void RequireDef(
            DefinitionRegistry registry,
            string idText,
            string expectedKind,
            string context,
            ValidationReport report)
        {
            if (string.IsNullOrWhiteSpace(idText))
                return;
            if (!DefinitionId.TryParse(idText, out var id))
            {
                report.Add(ErrorCode.InvalidDefinitionId, "Invalid DefinitionId.", context + ":" + idText);
                return;
            }

            var ok = false;
            switch (expectedKind)
            {
                case "character":
                    ok = registry.Characters.ContainsKey(id);
                    break;
                case "quest":
                    ok = registry.Quests.ContainsKey(id);
                    break;
                case "contentEvent":
                    ok = registry.ContentEvents.ContainsKey(id);
                    break;
                case "chapter":
                    ok = registry.Chapters.ContainsKey(id);
                    break;
                case "openingScenario":
                    ok = registry.OpeningScenarios.ContainsKey(id);
                    break;
                case "worldRegion":
                    ok = registry.WorldRegions.ContainsKey(id);
                    break;
                case "hexWorld":
                    ok = registry.HexWorldContents.ContainsKey(id);
                    break;
                case "localPlaceSet":
                    ok = registry.LocalPlaceSets.ContainsKey(id);
                    break;
                case "job":
                    ok = registry.Jobs.ContainsKey(id);
                    break;
                case "workArea":
                    ok = registry.WorkAreas.ContainsKey(id);
                    break;
                case "schedule":
                    ok = registry.Schedules.ContainsKey(id);
                    break;
                case "resource":
                    ok = registry.Resources.ContainsKey(id);
                    break;
                case "opportunitySite":
                    ok = registry.OpportunitySites.ContainsKey(id);
                    break;
                case "cultivation":
                    ok = registry.Cultivations.ContainsKey(id);
                    break;
                case "combatArt":
                    ok = registry.CombatArts.ContainsKey(id);
                    break;
                case "item":
                    ok = registry.Items.ContainsKey(id);
                    break;
                case "spawnTable":
                    ok = registry.SpawnTables.ContainsKey(id);
                    break;
                case "formalArmy":
                    ok = registry.FormalArmies.ContainsKey(id);
                    break;
                case "npcSquad":
                    ok = registry.NpcSquads.ContainsKey(id);
                    break;
            }

            if (!ok)
                report.Add(ErrorCode.NotFound, expectedKind + " reference missing.", context + ":" + idText);
        }
    }
}
