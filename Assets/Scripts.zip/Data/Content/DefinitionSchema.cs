using System;
using System.Collections.Generic;
using XianXia.Core.Attributes;
using XianXia.Core.Results;
using XianXia.Data.Serialization;

namespace XianXia.Data.Content
{
    /// <summary>
    /// Strict JSON field allow-lists for Data Pipeline M1-A.
    /// </summary>
    public static class DefinitionSchema
    {
        public static readonly HashSet<string> CharacterFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "id", "type", "name", "displayNameKey", "nameKey", "baseAttributes", "tags",
            "personalityTags", "backgroundTags", "talentTags",
            "spiritRootPlaceholder", "spiritRoots", "initialRealmPlaceholder",
            "hometown", "reputation", "goals", "desires",
            "playerControllable", "activityCapabilities", "activityPriorities", "preferredWorkAreaIds",
            "homeWorkAreaId", "defeatEncounterId", "defaultFactionId", "defaultFactionRole"
        };

        public static readonly HashSet<string> OpeningScenarioFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "id", "type", "name", "scheduleId", "openingFactionId", "openingSettlementId",
            "openingWorldRegionId", "openingLocalPlaceSetId", "openingHexWorldId", "openingChapterId", "spawns", "openingRelations", "openingBonds",
            "initialFormalArmyIds", "strategicOpening"
        };

        public static readonly HashSet<string> FormalArmyFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "id", "type", "name", "runtimeArmyId", "runtimeStackId", "factionId", "assemblySiteId", "initialHex", "members"
        };

        public static readonly HashSet<string> StrategicFactionFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "id", "type", "name", "mapColor", "territorySelectable", "sortOrder"
        };

        public static readonly HashSet<string> FormalArmyInitialHexFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "q", "r"
        };

        public static readonly HashSet<string> FormalArmyMemberFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "characterDefinitionId", "displayName", "leader", "reuseOpeningSpawn"
        };

        public static readonly HashSet<string> CharacterRosterFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "id", "type", "name", "entries"
        };

        public static readonly HashSet<string> ChapterFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "id", "type", "name", "description", "openingScenarioId", "plannedDays",
            "questChainIds", "eventChainIds", "dayBeats"
        };

        public static readonly HashSet<string> ChapterDayBeatFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "dayIndex", "conditions", "questOfferIds", "contentEventIds", "setFlags"
        };

        public static readonly HashSet<string> WorldRegionFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "id", "type", "name", "startLocationId", "locations"
        };

        public static readonly HashSet<string> LocalPlaceSetFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "id", "type", "name", "mapLayoutId", "startLocationId", "locations"
        };

        public static readonly HashSet<string> WorldLocationFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "id", "name", "kind", "adjacentIds", "resourceOnExploreId", "resourceOnExploreAmount",
            "opportunitySiteId", "residentNpcDefinitionId", "presentationX", "presentationZ",
            "enterConditions", "questOfferIds", "tags", "allowedActivities",
            "localMapId", "enterLocalMapId", "enterSpawnLocationId", "surveySenseRequired"
        };

        public static readonly HashSet<string> WorkAreaFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "id", "type", "name", "locationId", "tags", "allowedActivities", "offsetX", "offsetZ", "capacity",
            "residentTags", "isControlCore", "maxDurability", "defense", "occupyHoldSeconds", "grantsPrivileges"
        };

        public static readonly HashSet<string> JobFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "id", "type", "name", "primaryWorkAreaId", "activityBindings"
        };

        public static readonly HashSet<string> JobActivityBindingFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "activity", "workAreaIds", "mode"
        };

        public static readonly HashSet<string> ScheduleFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "id", "type", "name", "blocks"
        };

        public static readonly HashSet<string> ScheduleBlockFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "startTick", "endTick", "activity", "orderDurationTicks"
        };

        public static readonly HashSet<string> MapLayoutFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "id", "type", "name", "worldRegionId",
            "originX", "originY", "cellSize", "width", "height", "exitTriggerDepth", "placements"
        };

        public static readonly HashSet<string> OutdoorSurfaceFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "id", "type", "name", "originWorldX", "originWorldY", "cellSize", "chunkWidth", "chunkHeight", "chunks"
        };
        public static readonly HashSet<string> OutdoorSurfaceChunkFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "id", "x", "y", "sourceMapLayoutId"
        };

        public static readonly HashSet<string> MapPlacementFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "id", "kind", "x", "y", "w", "h", "blocksMovement", "boundLocationId", "label", "lootItemId",
            "spawnTableId", "spawnCount"
        };

        public static readonly HashSet<string> SpawnTableFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "id", "type", "name", "entries"
        };

        public static readonly HashSet<string> SpawnTableEntryFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "definitionId", "weight", "countMin", "countMax"
        };

        public static readonly HashSet<string> HexWorldFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "id", "type", "name", "width", "height", "hexSize", "defaultTerrain", "defaultPassable", "cells", "sites",
            "territoryRegions", "standaloneTerritoryHexes", "factionFlags"
        };

        public static readonly HashSet<string> HexWorldCellFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "q", "r", "terrain", "passable", "isRoad"
        };

        public static readonly HashSet<string> HexWorldSiteFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "siteId", "displayName", "siteType", "anchorQ", "anchorR", "presenceQ", "presenceR", "footprint",
            "localMapId", "ownerFactionId", "territoryRegionId", "controlEstablishedOrder"
        };

        public static readonly HashSet<string> HexWorldTerritoryRegionFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "regionId", "primaryWorldSiteId", "controlFactionId", "hexes"
        };

        public static readonly HashSet<string> HexWorldStandaloneHexFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "q", "r", "controlFactionId"
        };

        public static readonly HashSet<string> QuestFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "id", "type", "name", "description", "autoOffer", "abandonable", "deadlineDays",
            "offerConditions", "completeConditions", "failConditions", "rewards", "failResults"
        };

        public static readonly HashSet<string> ContentEventFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "id", "type", "name", "body", "trigger", "locationId", "questId", "npcDefinitionId", "once",
            "conditions", "choices"
        };

        public static readonly HashSet<string> ContentEventChoiceFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "id", "text", "conditions", "outcomes"
        };

        public static readonly HashSet<string> ContentConditionFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "kind", "id", "amount", "realm", "characterId"
        };

        public static readonly HashSet<string> ContentOutcomeFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "kind", "id", "amount", "fromDefinitionId", "toDefinitionId", "toDefinitionIds"
        };

        public static readonly HashSet<string> OpeningSpawnFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "definitionId", "entityKind", "displayName", "assignOpeningFaction", "factionMode", "factionId", "factionRole",
            "bindSchedule", "bindDailyTask", "recruitable", "workRole", "scheduleId", "aiRole", "jobId",
            "worldSiteId", "localLocationId", "localPosition"
        };

        public static readonly HashSet<string> HexWorldFactionFlagFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "flagId", "factionId", "anchorQ", "anchorR", "establishedOrder",
            "hasLocalPosition", "localX", "localZ"
        };
        public static readonly HashSet<string> OpeningStrategicFields = new HashSet<string>(StringComparer.Ordinal) { "playerFactionId", "vassalages", "alliances", "initialWars" };
        public static readonly HashSet<string> OpeningVassalageFields = new HashSet<string>(StringComparer.Ordinal) { "vassalFactionId", "overlordFactionId" };
        public static readonly HashSet<string> OpeningAllianceFields = new HashSet<string>(StringComparer.Ordinal) { "factionAId", "factionBId" };
        public static readonly HashSet<string> OpeningWarFields = new HashSet<string>(StringComparer.Ordinal) { "declarerFactionId", "targetFactionId" };

        public static readonly HashSet<string> OpeningLocalPositionFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "x", "z"
        };

        public static readonly HashSet<string> ResourceFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "id", "type", "name", "nameKey", "tags"
        };

        public static readonly HashSet<string> FacilityFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "id", "type", "name", "laborResourceId", "laborAmountPerWorker",
            "gatherResourceId", "gatherAmountPerWorker", "cultivateProgressBonusPerWorker", "tags"
        };

        public static readonly HashSet<string> SettlementFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "id", "type", "name", "initialStock", "facilities"
        };

        public static readonly HashSet<string> SettlementStockFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "resourceId", "amount"
        };

        public static readonly HashSet<string> OpeningRelationFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "fromDefinitionId", "toDefinitionId", "delta", "reasonTag", "mutual"
        };

        public static readonly HashSet<string> CultivationFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "id", "type", "name", "displayNameKey", "nameKey", "requiredRealm",
            "grade", "effectSummary",
            "cultivationSpeed", "breakthroughProgress", "grantedModifiers", "mastery", "tags"
        };

        public static readonly HashSet<string> CombatArtFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "id", "type", "name", "grade", "effectSummary",
            "attackBonusPercent", "damageFlat", "damageAttackMult", "hitCount", "cooldownSeconds",
            "mastery", "tags"
        };

        public static readonly HashSet<string> ItemFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "id", "type", "name", "displayNameKey", "nameKey", "maxStack", "teachesManualId", "teachesArtId", "tags"
        };

        public static readonly HashSet<string> OpeningBondFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "kind", "fromDefinitionId", "toDefinitionId"
        };

        public static readonly HashSet<string> BuildingFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "id", "type", "name", "description", "unlockedByDefault", "placementKind",
            "dismantleRefundRate", "costs"
        };

        public static readonly HashSet<string> BuildingCostFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "itemId", "count"
        };

        public static readonly HashSet<string> OpportunitySiteFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "id", "type", "name", "nameKey", "description", "allowsCultivation", "offeredManualId", "tags"
        };

        public static readonly HashSet<string> ModifierGrantFields = new HashSet<string>(StringComparer.Ordinal)
        {
            "targetAttribute", "operation", "value", "stackingKey"
        };

        public static readonly HashSet<string> AllowedOperations = new HashSet<string>(StringComparer.Ordinal)
        {
            "Fixed", "Percentage"
        };

        public static bool TryParseAttributeId(string name, out AttributeId id)
        {
            return Enum.TryParse(name, ignoreCase: false, out id);
        }

        public static void RejectUnknownFields(
            JsonValue obj,
            HashSet<string> allowed,
            ValidationReport report,
            string context)
        {
            if (obj == null || obj.Kind != JsonValueKind.Object || obj.Object == null)
            {
                report.Add(ErrorCode.ContentLoadFailed, "Expected JSON object.", context);
                return;
            }

            foreach (var key in obj.Object.Keys)
            {
                if (!allowed.Contains(key))
                    report.Add(ErrorCode.InvalidArgument, "Unknown field in definition.", context + "." + key);
            }
        }
    }
}
