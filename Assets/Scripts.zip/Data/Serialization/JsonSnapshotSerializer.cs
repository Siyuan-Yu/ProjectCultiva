using System.Collections.Generic;
using System.Globalization;
using XianXia.Core.Persistence;
using XianXia.Core.Results;
using XianXia.Data.Serialization;

namespace XianXia.Data.Serialization
{
    public sealed class JsonSnapshotSerializer : ISnapshotSerializer
    {
        public Result<string> Serialize(WorldSnapshot snapshot)
        {
            if (snapshot == null)
                return Result.Fail<string>(ErrorCode.SnapshotInvalid, "Snapshot is null.");

            var root = new Dictionary<string, JsonValue>(System.StringComparer.Ordinal)
            {
                ["schemaVersion"] = JsonValue.FromNumber(snapshot.SchemaVersion),
                ["snapshotId"] = U(snapshot.SnapshotId),
                ["worldTick"] = U(snapshot.WorldTick),
                ["regionId"] = U(snapshot.RegionId),
                ["enabledPackageId"] = JsonValue.FromString(snapshot.EnabledPackageId ?? string.Empty),
                ["enabledPackageVersion"] = JsonValue.FromString(snapshot.EnabledPackageVersion ?? string.Empty),
                ["randomS0"] = U(snapshot.RandomS0),
                ["randomS1"] = U(snapshot.RandomS1),
                ["randomStreamId"] = U(snapshot.RandomStreamId),
                ["eventCursor"] = JsonValue.FromNumber(snapshot.EventCursor),
                ["nextEventId"] = U(snapshot.NextEventId),
                ["nextEntityId"] = U(snapshot.NextEntityId),
                ["nextOrderId"] = U(snapshot.NextOrderId),
                ["nextActionId"] = U(snapshot.NextActionId),
                ["nextModifierId"] = U(snapshot.NextModifierId),
                ["entities"] = JsonValue.FromArray(SerializeEntities(snapshot.Entities)),
                ["activeActions"] = JsonValue.FromArray(SerializeActions(snapshot.ActiveActions)),
                ["orders"] = JsonValue.FromArray(SerializeOrders(snapshot.Orders)),
                ["schedules"] = JsonValue.FromArray(SerializeSchedules(snapshot.Schedules)),
                ["opportunitySites"] = JsonValue.FromArray(SerializeOpportunitySites(snapshot.OpportunitySites)),
                ["manuals"] = JsonValue.FromArray(SerializeManuals(snapshot.Manuals)),
                ["observationDiscoverChancePercent"] = JsonValue.FromNumber(snapshot.ObservationDiscoverChancePercent),
                ["partyInventorySlots"] = JsonValue.FromArray(SerializePartyInventorySlots(snapshot.PartyInventorySlots)),
                ["hasTakenWorldLootSnapshotAuthority"] =
                    JsonValue.FromBool(snapshot.HasTakenWorldLootSnapshotAuthority),
                ["takenWorldLootSpotIds"] =
                    JsonValue.FromArray(SerializeStringList(snapshot.TakenWorldLootSpotIds)),
                ["relationshipEvents"] = JsonValue.FromArray(SerializeRelationshipEvents(snapshot.RelationshipEvents)),
                ["socialBonds"] = JsonValue.FromArray(SerializeSocialBonds(snapshot.SocialBonds)),
                ["nextOutdoorConstructedAssetSequence"] = JsonValue.FromString(snapshot.NextOutdoorConstructedAssetSequence.ToString(System.Globalization.CultureInfo.InvariantCulture)),
                ["outdoorConstructedAssets"] = JsonValue.FromArray(SerializeConstructedAssets(snapshot.OutdoorConstructedAssets)),
                ["outdoorDestructibles"] = JsonValue.FromArray(
                    SerializeOutdoorDestructibles(snapshot.OutdoorDestructibles)),
                ["outdoorFarmPlots"] = JsonValue.FromArray(
                    SerializeOutdoorFarmPlots(snapshot.OutdoorFarmPlots)),
                ["strategic"] = SerializeStrategic(snapshot.Strategic)
            };

            var suppressedContacts = new List<JsonValue>();
            foreach (var key in snapshot.SuppressedCharacterContacts) suppressedContacts.Add(JsonValue.FromString(key));
            root["suppressedCharacterContacts"] = JsonValue.FromArray(suppressedContacts);
            if (snapshot.CharacterEncounter != null)
                root["characterEncounter"] = CharacterEncounterJson.Write(snapshot.CharacterEncounter);
            return Result.Ok(SimpleJson.Stringify(JsonValue.FromObject(root)));
        }

        public Result<WorldSnapshot> Deserialize(string json)
        {
            if (string.IsNullOrEmpty(json))
                return Result.Fail<WorldSnapshot>(ErrorCode.SnapshotInvalid, "JSON is empty.");

            try
            {
                var root = SimpleJson.Parse(json);
                var snapshot = new WorldSnapshot
                {
                    SchemaVersion = (int)root.GetNumber("schemaVersion"),
                    SnapshotId = ReadU(root, "snapshotId"),
                    WorldTick = ReadU(root, "worldTick"),
                    RegionId = ReadU(root, "regionId"),
                    EnabledPackageId = root.GetString("enabledPackageId", string.Empty),
                    EnabledPackageVersion = root.GetString("enabledPackageVersion", string.Empty),
                    RandomS0 = ReadU(root, "randomS0"),
                    RandomS1 = ReadU(root, "randomS1"),
                    RandomStreamId = ReadU(root, "randomStreamId"),
                    EventCursor = (int)root.GetNumber("eventCursor"),
                    NextEventId = ReadU(root, "nextEventId"),
                    NextEntityId = ReadU(root, "nextEntityId"),
                    NextOrderId = ReadU(root, "nextOrderId"),
                    NextActionId = ReadU(root, "nextActionId"),
                    NextModifierId = ReadU(root, "nextModifierId")
                };

                if (root.TryGetProperty("entities", out var entities) && entities.Kind == JsonValueKind.Array)
                {
                    foreach (var e in entities.Array)
                        snapshot.Entities.Add(ReadEntity(e));
                }

                if (root.TryGetProperty("activeActions", out var actions) && actions.Kind == JsonValueKind.Array)
                {
                    foreach (var a in actions.Array)
                        snapshot.ActiveActions.Add(ReadAction(a));
                }

                if (root.TryGetProperty("orders", out var orders) && orders.Kind == JsonValueKind.Array)
                {
                    foreach (var o in orders.Array)
                        snapshot.Orders.Add(ReadOrder(o));
                }

                if (root.TryGetProperty("schedules", out var schedules) && schedules.Kind == JsonValueKind.Array)
                {
                    foreach (var s in schedules.Array)
                        snapshot.Schedules.Add(ReadSchedule(s));
                }

                if (root.TryGetProperty("opportunitySites", out var sites) && sites.Kind == JsonValueKind.Array)
                {
                    foreach (var s in sites.Array)
                        snapshot.OpportunitySites.Add(ReadOpportunitySite(s));
                }

                if (root.TryGetProperty("manuals", out var manuals) && manuals.Kind == JsonValueKind.Array)
                {
                    foreach (var m in manuals.Array)
                        snapshot.Manuals.Add(ReadManual(m));
                }

                if (root.TryGetProperty("observationDiscoverChancePercent", out var chance) &&
                    chance.Kind == JsonValueKind.Number)
                {
                    snapshot.ObservationDiscoverChancePercent = (int)chance.Number;
                }

                if (root.TryGetProperty("partyInventorySlots", out var invSlots) &&
                    invSlots.Kind == JsonValueKind.Array)
                {
                    foreach (var slot in invSlots.Array)
                    {
                        if (slot.Kind != JsonValueKind.Object)
                            continue;
                        var itemId = slot.GetString("itemId", string.Empty);
                        var count = (int)slot.GetNumber("count");
                        if (string.IsNullOrEmpty(itemId) || count <= 0)
                            continue;
                        snapshot.PartyInventorySlots.Add(new PartyInventorySlotSnapshotDto
                        {
                            ItemId = itemId,
                            Count = count
                        });
                    }
                }

                snapshot.HasTakenWorldLootSnapshotAuthority =
                    root.GetBool("hasTakenWorldLootSnapshotAuthority", false);
                if (root.TryGetProperty("takenWorldLootSpotIds", out var takenLoot) &&
                    takenLoot.Kind == JsonValueKind.Array)
                {
                    foreach (var value in takenLoot.Array)
                        if (value.Kind == JsonValueKind.String && !string.IsNullOrWhiteSpace(value.String))
                            snapshot.TakenWorldLootSpotIds.Add(value.String);
                }

                if (root.TryGetProperty("relationshipEvents", out var relEvents) &&
                    relEvents.Kind == JsonValueKind.Array)
                {
                    foreach (var ev in relEvents.Array)
                    {
                        if (ev.Kind != JsonValueKind.Object)
                            continue;
                        var hasAxis = ev.TryGetProperty("axis", out var axisNode) &&
                                      axisNode.Kind == JsonValueKind.Number;
                        snapshot.RelationshipEvents.Add(new RelationshipEventSnapshotDto
                        {
                            Tick = ReadU(ev, "tick"),
                            FromEntityId = ReadU(ev, "fromEntityId"),
                            ToEntityId = ReadU(ev, "toEntityId"),
                            Axis = hasAxis ? (int)axisNode.Number : (int)XianXia.Core.Social.SocialAttitudeAxis.Affection,
                            HasAxis = hasAxis,
                            Delta = (int)ev.GetNumber("delta"),
                            ReasonTag = ev.GetString("reasonTag", string.Empty),
                            CauseEventId = ReadU(ev, "causeEventId"),
                            HasCauseEventId = ev.TryGetProperty("hasCauseEventId", out var hce) &&
                                              hce.Kind == JsonValueKind.Boolean &&
                                              hce.Bool,
                            ContextEntityId = ReadU(ev, "contextEntityId"),
                            HasContextEntityId = ev.TryGetProperty("hasContextEntityId", out var hcx) &&
                                                 hcx.Kind == JsonValueKind.Boolean && hcx.Bool
                        });
                    }
                }

                if (root.TryGetProperty("socialBonds", out var socialBonds) &&
                    socialBonds.Kind == JsonValueKind.Array)
                {
                    foreach (var bond in socialBonds.Array)
                    {
                        if (bond.Kind != JsonValueKind.Object)
                            continue;
                        snapshot.SocialBonds.Add(new SocialBondSnapshotDto
                        {
                            Kind = (int)bond.GetNumber("kind"),
                            FromEntityId = ReadU(bond, "fromEntityId"),
                            ToEntityId = ReadU(bond, "toEntityId")
                        });
                    }
                }

                if (root.TryGetProperty("outdoorConstructedAssets", out var constructed))
                {
                    if (constructed.Kind != JsonValueKind.Array ||
                        !root.TryGetProperty("nextOutdoorConstructedAssetSequence", out var sequence) ||
                        sequence.Kind != JsonValueKind.String || !long.TryParse(sequence.String, System.Globalization.NumberStyles.None,
                            System.Globalization.CultureInfo.InvariantCulture, out var next) || next < 1)
                        throw new System.FormatException("Invalid runtime constructed asset list/sequence.");
                    snapshot.NextOutdoorConstructedAssetSequence = next;
                    foreach (var node in constructed.Array)
                    {
                        if (node.Kind != JsonValueKind.Object) throw new System.FormatException("Invalid runtime farm object.");
                        if (!node.TryGetProperty("stableAssetId", out var stableAssetIdValue) || stableAssetIdValue.Kind != JsonValueKind.String) throw new System.FormatException("Invalid farm stableAssetId.");
                        if (!node.TryGetProperty("buildingId", out var buildingIdValue) || buildingIdValue.Kind != JsonValueKind.String) throw new System.FormatException("Invalid farm buildingId.");
                        if (!node.TryGetProperty("kind", out var kindValue) || kindValue.Kind != JsonValueKind.String) throw new System.FormatException("Invalid farm kind.");
                        if (!node.TryGetProperty("surfaceId", out var surfaceIdValue) || surfaceIdValue.Kind != JsonValueKind.String) throw new System.FormatException("Invalid farm surfaceId.");
                        if (!node.TryGetProperty("worldX", out var worldXValue) || worldXValue.Kind != JsonValueKind.Number) throw new System.FormatException("Invalid farm worldX.");
                        if (!node.TryGetProperty("worldY", out var worldYValue) || worldYValue.Kind != JsonValueKind.Number) throw new System.FormatException("Invalid farm worldY.");
                        if (!node.TryGetProperty("worldWidth", out var worldWidthValue) || worldWidthValue.Kind != JsonValueKind.Number) throw new System.FormatException("Invalid farm worldWidth.");
                        if (!node.TryGetProperty("worldHeight", out var worldHeightValue) || worldHeightValue.Kind != JsonValueKind.Number) throw new System.FormatException("Invalid farm worldHeight.");
                        if (!node.TryGetProperty("cellsW", out var cellsWValue) || cellsWValue.Kind != JsonValueKind.Number) throw new System.FormatException("Invalid farm cellsW.");
                        if (cellsWValue.Number < 1 || cellsWValue.Number > int.MaxValue || cellsWValue.Number != System.Math.Floor(cellsWValue.Number)) throw new System.FormatException("Invalid farm cellsW integer.");
                        if (!node.TryGetProperty("cellsH", out var cellsHValue) || cellsHValue.Kind != JsonValueKind.Number) throw new System.FormatException("Invalid farm cellsH.");
                        if (cellsHValue.Number < 1 || cellsHValue.Number > int.MaxValue || cellsHValue.Number != System.Math.Floor(cellsHValue.Number)) throw new System.FormatException("Invalid farm cellsH integer.");
                        if (!node.TryGetProperty("boundLocationId", out var boundLocationIdValue) || boundLocationIdValue.Kind != JsonValueKind.String) throw new System.FormatException("Invalid farm boundLocationId.");
                        var boundWorldSiteId = node.GetString("boundWorldSiteId", string.Empty);
                        snapshot.OutdoorConstructedAssets.Add(new OutdoorConstructedAssetSnapshotDto {
                            StableAssetId = stableAssetIdValue.String,
                            BuildingId = buildingIdValue.String,
                            Kind = kindValue.String,
                            SurfaceId = surfaceIdValue.String,
                            WorldX = (float)worldXValue.Number,
                            WorldY = (float)worldYValue.Number,
                            WorldWidth = (float)worldWidthValue.Number,
                            WorldHeight = (float)worldHeightValue.Number,
                            CellsW = (int)cellsWValue.Number,
                            CellsH = (int)cellsHValue.Number,
                            BoundLocationId = boundLocationIdValue.String,
                            BoundWorldSiteId = boundWorldSiteId });
                    }
                }
                else if (root.TryGetProperty("nextOutdoorConstructedAssetSequence", out _))
                    throw new System.FormatException("Constructed asset sequence without list.");

                // Additive v6 optional fields: older saves omit both arrays and therefore retain
                // the WorldSnapshot defaults (empty collections).
                if (root.TryGetProperty("outdoorDestructibles", out var outdoorDestructibles) &&
                    outdoorDestructibles.Kind == JsonValueKind.Array)
                {
                    foreach (var node in outdoorDestructibles.Array)
                    {
                        if (node.Kind != JsonValueKind.Object)
                            continue;
                        snapshot.OutdoorDestructibles.Add(new OutdoorDestructibleSnapshotDto
                        {
                            StableId = node.GetString("stableId", string.Empty),
                            CurrentHp = (int)node.GetNumber("currentHp"),
                            Destroyed = node.GetBool("destroyed")
                        });
                    }
                }

                if (root.TryGetProperty("outdoorFarmPlots", out var outdoorFarmPlots) &&
                    outdoorFarmPlots.Kind == JsonValueKind.Array)
                {
                    foreach (var node in outdoorFarmPlots.Array)
                    {
                        if (node.Kind != JsonValueKind.Object)
                            continue;
                        snapshot.OutdoorFarmPlots.Add(new OutdoorFarmPlotSnapshotDto
                        {
                            StableCellId = node.GetString("stableCellId", string.Empty),
                            CropId = node.GetString("cropId", string.Empty),
                            CropStage = (int)node.GetNumber("cropStage"),
                            Growth = (float)node.GetNumber("growth")
                        });
                    }
                }

                if (root.TryGetProperty("strategic", out var strategic) &&
                    strategic.Kind == JsonValueKind.Object)
                {
                    snapshot.Strategic = ReadStrategic(strategic);
                }

                if (root.TryGetProperty("suppressedCharacterContacts", out var contacts))
                {
                    if (contacts.Kind != JsonValueKind.Array) throw new System.FormatException("Invalid contact suppression list.");
                    foreach (var contact in contacts.Array)
                    {
                        if (contact.Kind != JsonValueKind.String) throw new System.FormatException("Invalid suppressed contact key.");
                        snapshot.SuppressedCharacterContacts.Add(contact.String);
                    }
                }
                if (root.TryGetProperty("characterEncounter", out var characterEncounter))
                    snapshot.CharacterEncounter = CharacterEncounterJson.Read(characterEncounter);
                return Result.Ok(snapshot);
            }
            catch (System.Exception ex)
            {
                return Result.Fail<WorldSnapshot>(ErrorCode.SnapshotInvalid, "JSON parse failed.", ex.Message);
            }
        }

        static List<JsonValue> SerializeEntities(List<EntitySnapshotDto> entities)
        {
            var list = new List<JsonValue>();
            foreach (var e in entities)
            {
                var bases = new List<JsonValue>();
                foreach (var b in e.Bases)
                {
                    bases.Add(JsonValue.FromObject(new Dictionary<string, JsonValue>
                    {
                        ["attributeId"] = JsonValue.FromNumber(b.AttributeId),
                        ["value"] = JsonValue.FromNumber(b.Value)
                    }));
                }

                var mods = new List<JsonValue>();
                foreach (var m in e.Modifiers)
                {
                    mods.Add(JsonValue.FromObject(new Dictionary<string, JsonValue>
                    {
                        ["id"] = JsonValue.FromNumber(m.Id),
                        ["attributeId"] = JsonValue.FromNumber(m.AttributeId),
                        ["operation"] = JsonValue.FromNumber(m.Operation),
                        ["value"] = JsonValue.FromNumber(m.Value),
                        ["sourceKind"] = JsonValue.FromNumber(m.SourceKind),
                        ["sourceDefinitionId"] = JsonValue.FromString(m.SourceDefinitionId ?? string.Empty),
                        ["sourceEntityId"] = JsonValue.FromNumber(m.SourceEntityId),
                        ["hasSourceEntity"] = JsonValue.FromBool(m.HasSourceEntity),
                        ["sourceModifierId"] = JsonValue.FromNumber(m.SourceModifierId),
                        ["hasSourceModifier"] = JsonValue.FromBool(m.HasSourceModifier)
                    }));
                }

                list.Add(JsonValue.FromObject(new Dictionary<string, JsonValue>
                {
                    ["id"] = JsonValue.FromNumber(e.Id),
                    ["definitionId"] = JsonValue.FromString(e.DefinitionId ?? string.Empty),
                    ["displayName"] = JsonValue.FromString(e.DisplayName ?? string.Empty),
                    ["tags"] = JsonValue.FromNumber(e.Tags),
                    ["lifecycle"] = JsonValue.FromNumber(e.Lifecycle),
                    ["bases"] = JsonValue.FromArray(bases),
                    ["modifiers"] = JsonValue.FromArray(mods),
                    ["activeActionId"] = JsonValue.FromNumber(e.ActiveActionId),
                    ["activeTotalTicks"] = JsonValue.FromNumber(e.ActiveTotalTicks),
                    ["activeRemainingTicks"] = JsonValue.FromNumber(e.ActiveRemainingTicks),
                    ["hasActiveClock"] = JsonValue.FromBool(e.HasActiveClock),
                    ["hasCultivation"] = JsonValue.FromBool(e.HasCultivation),
                    ["realm"] = JsonValue.FromNumber(e.Realm),
                    ["cultivationMinorStage"] = JsonValue.FromNumber(e.CultivationMinorStage),
                    ["cultivationProgress"] = JsonValue.FromNumber(e.CultivationProgress),
                    ["breakthroughProgressRequired"] = JsonValue.FromNumber(e.BreakthroughProgressRequired),
                    ["cultivationSpeed"] = JsonValue.FromNumber(e.CultivationSpeed),
                    ["learnedManualId"] = JsonValue.FromString(e.LearnedManualId ?? string.Empty),
                    ["hasManualMastery"] = JsonValue.FromBool(e.HasManualMastery),
                    ["manualMasteryTier"] = JsonValue.FromNumber(e.ManualMasteryTier),
                    ["manualMasteryProgress"] = JsonValue.FromNumber(e.ManualMasteryProgress),
                    ["manualMasteryProgressRequired"] = JsonValue.FromNumber(e.ManualMasteryProgressRequired),
                    ["combatArtsLearned"] = JsonValue.FromArray(SerializeStringList(e.CombatArtsLearned)),
                    ["combatArtsEquipped"] = JsonValue.FromArray(SerializeStringList(e.CombatArtsEquipped)),
                    ["combatArtMastery"] = JsonValue.FromArray(SerializeArtMastery(e.CombatArtMastery)),
                    ["requiredRealmName"] = JsonValue.FromString(e.RequiredRealmName ?? string.Empty),
                    ["hasDailyTask"] = JsonValue.FromBool(e.HasDailyTask),
                    ["laborProgress"] = JsonValue.FromNumber(e.LaborProgress),
                    ["laborQuota"] = JsonValue.FromNumber(e.LaborQuota),
                    ["requiredAmount"] = JsonValue.FromNumber(e.RequiredAmount),
                    ["completedAmount"] = JsonValue.FromNumber(e.CompletedAmount),
                    ["deviation"] = JsonValue.FromNumber(e.Deviation),
                    ["pendingReprimand"] = JsonValue.FromBool(e.PendingReprimand),
                    ["lastSettledDeviation"] = JsonValue.FromNumber(e.LastSettledDeviation),
                    ["hasSchedule"] = JsonValue.FromBool(e.HasSchedule),
                    ["scheduleDefinitionId"] = JsonValue.FromString(e.ScheduleDefinitionId ?? string.Empty),
                    ["activeOrderSource"] = JsonValue.FromNumber(e.ActiveOrderSource),
                    ["knownSiteIds"] = JsonValue.FromArray(SerializeStringList(e.KnownSiteIds)),
                    ["personalConcealmentRisk"] = JsonValue.FromNumber(e.PersonalConcealmentRisk),
                    ["hasEntityLocation"] = JsonValue.FromBool(e.HasEntityLocation),
                    ["locationId"] = JsonValue.FromString(e.LocationId ?? string.Empty),
                    ["hasPresentationOverride"] = JsonValue.FromBool(e.HasPresentationOverride),
                    ["presentationOverrideX"] = JsonValue.FromNumber(e.PresentationOverrideX),
                    ["presentationOverrideZ"] = JsonValue.FromNumber(e.PresentationOverrideZ),
                    ["factionId"] = JsonValue.FromString(e.FactionId ?? string.Empty),
                    ["factionRole"] = JsonValue.FromNumber(e.FactionRole),
                    ["hasCombatVitals"] = JsonValue.FromBool(e.HasCombatVitals),
                    ["currentHp"] = JsonValue.FromNumber(e.CurrentHp),
                    ["currentSpiritPower"] = JsonValue.FromNumber(e.CurrentSpiritPower),
                    ["vitalsPoolsInitialized"] = JsonValue.FromBool(e.VitalsPoolsInitialized),
                    ["bleedOutAfterTick"] = U(e.BleedOutAfterTick),
                    ["hasCorpse"] = JsonValue.FromBool(e.HasCorpse),
                    ["corpseRemoveAfterTick"] = U(e.CorpseRemoveAfterTick),
                    ["hasResponsibleAttacker"] = JsonValue.FromBool(e.HasResponsibleAttacker),
                    ["responsibleAttackerEntityId"] = U(e.ResponsibleAttackerEntityId),
                    ["personalityTags"] = JsonValue.FromArray(SerializeStringList(e.PersonalityTags))
                }));
            }
            return list;
        }

        static List<JsonValue> SerializePartyInventorySlots(List<PartyInventorySlotSnapshotDto> slots)
        {
            var list = new List<JsonValue>();
            if (slots == null)
                return list;
            for (var i = 0; i < slots.Count; i++)
            {
                var s = slots[i];
                if (s == null || string.IsNullOrEmpty(s.ItemId) || s.Count <= 0)
                    continue;
                list.Add(JsonValue.FromObject(new Dictionary<string, JsonValue>
                {
                    ["itemId"] = JsonValue.FromString(s.ItemId ?? string.Empty),
                    ["count"] = JsonValue.FromNumber(s.Count)
                }));
            }

            return list;
        }

        static List<JsonValue> SerializeOutdoorDestructibles(
            List<OutdoorDestructibleSnapshotDto> destructibles)
        {
            var list = new List<JsonValue>();
            if (destructibles == null)
                return list;
            for (var i = 0; i < destructibles.Count; i++)
            {
                var state = destructibles[i];
                if (state == null)
                    continue;
                list.Add(JsonValue.FromObject(new Dictionary<string, JsonValue>
                {
                    ["stableId"] = JsonValue.FromString(state.StableId ?? string.Empty),
                    ["currentHp"] = JsonValue.FromNumber(state.CurrentHp),
                    ["destroyed"] = JsonValue.FromBool(state.Destroyed)
                }));
            }
            return list;
        }

        static List<JsonValue> SerializeConstructedAssets(List<OutdoorConstructedAssetSnapshotDto> assets)
        {
            var list = new List<JsonValue>();
            foreach (var a in assets)
                list.Add(JsonValue.FromObject(new Dictionary<string, JsonValue> {
                    ["stableAssetId"] = JsonValue.FromString(a.StableAssetId),
                    ["buildingId"] = JsonValue.FromString(a.BuildingId),
                    ["kind"] = JsonValue.FromString(a.Kind),
                    ["surfaceId"] = JsonValue.FromString(a.SurfaceId),
                    ["worldX"] = JsonValue.FromNumber(a.WorldX),
                    ["worldY"] = JsonValue.FromNumber(a.WorldY),
                    ["worldWidth"] = JsonValue.FromNumber(a.WorldWidth),
                    ["worldHeight"] = JsonValue.FromNumber(a.WorldHeight),
                    ["cellsW"] = JsonValue.FromNumber(a.CellsW),
                    ["cellsH"] = JsonValue.FromNumber(a.CellsH),
                    ["boundLocationId"] = JsonValue.FromString(a.BoundLocationId),
                    ["boundWorldSiteId"] = JsonValue.FromString(a.BoundWorldSiteId ?? string.Empty) }));
            return list;
        }

        static List<JsonValue> SerializeOutdoorFarmPlots(List<OutdoorFarmPlotSnapshotDto> plots)
        {
            var list = new List<JsonValue>();
            if (plots == null)
                return list;
            for (var i = 0; i < plots.Count; i++)
            {
                var state = plots[i];
                if (state == null)
                    continue;
                list.Add(JsonValue.FromObject(new Dictionary<string, JsonValue>
                {
                    ["stableCellId"] = JsonValue.FromString(state.StableCellId ?? string.Empty),
                    ["cropId"] = JsonValue.FromString(state.CropId ?? string.Empty),
                    ["cropStage"] = JsonValue.FromNumber(state.CropStage),
                    ["growth"] = JsonValue.FromNumber(state.Growth)
                }));
            }
            return list;
        }

        static List<JsonValue> SerializeRelationshipEvents(List<RelationshipEventSnapshotDto> events)
        {
            var list = new List<JsonValue>();
            if (events == null)
                return list;
            for (var i = 0; i < events.Count; i++)
            {
                var ev = events[i];
                if (ev == null)
                    continue;
                list.Add(JsonValue.FromObject(new Dictionary<string, JsonValue>
                {
                    ["tick"] = U(ev.Tick),
                    ["fromEntityId"] = U(ev.FromEntityId),
                    ["toEntityId"] = U(ev.ToEntityId),
                    ["axis"] = JsonValue.FromNumber(ev.Axis),
                    ["delta"] = JsonValue.FromNumber(ev.Delta),
                    ["reasonTag"] = JsonValue.FromString(ev.ReasonTag ?? string.Empty),
                    ["causeEventId"] = U(ev.CauseEventId),
                    ["hasCauseEventId"] = JsonValue.FromBool(ev.HasCauseEventId),
                    ["contextEntityId"] = U(ev.ContextEntityId),
                    ["hasContextEntityId"] = JsonValue.FromBool(ev.HasContextEntityId)
                }));
            }

            return list;
        }

        static List<JsonValue> SerializeSocialBonds(List<SocialBondSnapshotDto> bonds)
        {
            var list = new List<JsonValue>();
            if (bonds == null)
                return list;
            for (var i = 0; i < bonds.Count; i++)
            {
                var bond = bonds[i];
                if (bond == null)
                    continue;
                list.Add(JsonValue.FromObject(new Dictionary<string, JsonValue>
                {
                    ["kind"] = JsonValue.FromNumber(bond.Kind),
                    ["fromEntityId"] = U(bond.FromEntityId),
                    ["toEntityId"] = U(bond.ToEntityId)
                }));
            }
            return list;
        }

        static List<JsonValue> SerializeStringList(List<string> values)
        {
            var list = new List<JsonValue>();
            if (values == null)
                return list;
            foreach (var v in values)
                list.Add(JsonValue.FromString(v ?? string.Empty));
            return list;
        }

        static List<JsonValue> SerializeArtMastery(List<ArtMasterySnapshotDto> values)
        {
            var list = new List<JsonValue>();
            if (values == null)
                return list;
            for (var i = 0; i < values.Count; i++)
            {
                var value = values[i];
                if (value == null || string.IsNullOrEmpty(value.ArtId))
                    continue;
                list.Add(JsonValue.FromObject(new Dictionary<string, JsonValue>
                {
                    ["artId"] = JsonValue.FromString(value.ArtId),
                    ["tier"] = JsonValue.FromNumber(value.Tier),
                    ["progress"] = JsonValue.FromNumber(value.Progress),
                    ["progressRequired"] = JsonValue.FromNumber(value.ProgressRequired)
                }));
            }

            return list;
        }

        static List<JsonValue> SerializeOpportunitySites(List<OpportunitySiteSnapshotDto> sites)
        {
            var list = new List<JsonValue>();
            if (sites == null)
                return list;
            foreach (var s in sites)
            {
                list.Add(JsonValue.FromObject(new Dictionary<string, JsonValue>
                {
                    ["id"] = JsonValue.FromString(s.Id ?? string.Empty),
                    ["allowsCultivation"] = JsonValue.FromBool(s.AllowsCultivation),
                    ["offeredManualId"] = JsonValue.FromString(s.OfferedManualId ?? string.Empty),
                    ["nameKey"] = JsonValue.FromString(s.NameKey ?? string.Empty),
                    ["description"] = JsonValue.FromString(s.Description ?? string.Empty)
                }));
            }

            return list;
        }

        static List<JsonValue> SerializeManuals(List<ManualSnapshotDto> manuals)
        {
            var list = new List<JsonValue>();
            if (manuals == null)
                return list;
            foreach (var m in manuals)
            {
                list.Add(JsonValue.FromObject(new Dictionary<string, JsonValue>
                {
                    ["id"] = JsonValue.FromString(m.Id ?? string.Empty),
                    ["requiredRealm"] = JsonValue.FromString(m.RequiredRealm ?? string.Empty),
                    ["cultivationSpeed"] = JsonValue.FromNumber(m.CultivationSpeed),
                    ["breakthroughProgress"] = JsonValue.FromNumber(m.BreakthroughProgress)
                }));
            }

            return list;
        }

        static List<JsonValue> SerializeSchedules(List<ScheduleDefinitionSnapshotDto> schedules)
        {
            var list = new List<JsonValue>();
            if (schedules == null)
                return list;
            foreach (var s in schedules)
            {
                var blocks = new List<JsonValue>();
                if (s.Blocks != null)
                {
                    foreach (var b in s.Blocks)
                    {
                        blocks.Add(JsonValue.FromObject(new Dictionary<string, JsonValue>
                        {
                            ["startTickInDay"] = JsonValue.FromNumber(b.StartTickInDay),
                            ["endTickInDay"] = JsonValue.FromNumber(b.EndTickInDay),
                            ["activity"] = JsonValue.FromNumber(b.Activity),
                            ["orderDurationTicks"] = JsonValue.FromNumber(b.OrderDurationTicks)
                        }));
                    }
                }

                list.Add(JsonValue.FromObject(new Dictionary<string, JsonValue>
                {
                    ["id"] = JsonValue.FromString(s.Id ?? string.Empty),
                    ["blocks"] = JsonValue.FromArray(blocks)
                }));
            }

            return list;
        }

        static List<JsonValue> SerializeActions(List<ActiveActionSnapshotDto> actions)
        {
            var list = new List<JsonValue>();
            foreach (var a in actions)
            {
                list.Add(JsonValue.FromObject(new Dictionary<string, JsonValue>
                {
                    ["id"] = JsonValue.FromNumber(a.Id),
                    ["subjectId"] = JsonValue.FromNumber(a.SubjectId),
                    ["sourceOrderId"] = JsonValue.FromNumber(a.SourceOrderId),
                    ["kind"] = JsonValue.FromString(a.Kind ?? "Wait"),
                    ["status"] = JsonValue.FromNumber(a.Status),
                    ["totalTicks"] = JsonValue.FromNumber(a.TotalTicks),
                    ["remainingTicks"] = JsonValue.FromNumber(a.RemainingTicks),
                    ["targetRef"] = JsonValue.FromString(a.TargetRef ?? string.Empty),
                    ["activity"] = JsonValue.FromNumber(a.Activity)
                }));
            }
            return list;
        }

        static List<JsonValue> SerializeOrders(List<OrderSnapshotDto> orders)
        {
            var list = new List<JsonValue>();
            foreach (var o in orders)
            {
                list.Add(JsonValue.FromObject(new Dictionary<string, JsonValue>
                {
                    ["id"] = JsonValue.FromNumber(o.Id),
                    ["subjectId"] = JsonValue.FromNumber(o.SubjectId),
                    ["type"] = JsonValue.FromNumber(o.Type),
                    ["source"] = JsonValue.FromNumber(o.Source),
                    ["waitTicks"] = JsonValue.FromNumber(o.WaitTicks),
                    ["targetRef"] = JsonValue.FromString(o.TargetRef ?? string.Empty),
                    ["activity"] = JsonValue.FromNumber(o.Activity)
                }));
            }
            return list;
        }

        static EntitySnapshotDto ReadEntity(JsonValue e)
        {
            var dto = new EntitySnapshotDto
            {
                Id = (ulong)e.GetNumber("id"),
                DefinitionId = e.GetString("definitionId", string.Empty),
                DisplayName = e.GetString("displayName", string.Empty),
                Tags = (int)e.GetNumber("tags"),
                Lifecycle = (int)e.GetNumber("lifecycle"),
                ActiveActionId = (ulong)e.GetNumber("activeActionId"),
                ActiveTotalTicks = (ulong)e.GetNumber("activeTotalTicks"),
                ActiveRemainingTicks = (ulong)e.GetNumber("activeRemainingTicks"),
                HasActiveClock = e.TryGetProperty("hasActiveClock", out var hac) && hac.Kind == JsonValueKind.Boolean && hac.Bool,
                HasCultivation = e.TryGetProperty("hasCultivation", out var hc) && hc.Kind == JsonValueKind.Boolean && hc.Bool,
                Realm = (int)e.GetNumber("realm"),
                CultivationMinorStage = (int)e.GetNumber("cultivationMinorStage"),
                CultivationProgress = (int)e.GetNumber("cultivationProgress"),
                BreakthroughProgressRequired = (int)e.GetNumber("breakthroughProgressRequired"),
                CultivationSpeed = (int)e.GetNumber("cultivationSpeed"),
                LearnedManualId = e.GetString("learnedManualId", string.Empty),
                HasManualMastery = e.TryGetProperty("hasManualMastery", out var hmm) &&
                                   hmm.Kind == JsonValueKind.Boolean && hmm.Bool,
                ManualMasteryTier = (int)e.GetNumber("manualMasteryTier"),
                ManualMasteryProgress = (int)e.GetNumber("manualMasteryProgress"),
                ManualMasteryProgressRequired = (int)e.GetNumber("manualMasteryProgressRequired"),
                RequiredRealmName = e.GetString("requiredRealmName", string.Empty),
                HasDailyTask = e.TryGetProperty("hasDailyTask", out var hdt) && hdt.Kind == JsonValueKind.Boolean && hdt.Bool,
                LaborProgress = (int)e.GetNumber("laborProgress"),
                LaborQuota = (int)e.GetNumber("laborQuota"),
                RequiredAmount = (int)e.GetNumber("requiredAmount"),
                CompletedAmount = (int)e.GetNumber("completedAmount"),
                Deviation = (int)e.GetNumber("deviation"),
                PendingReprimand = e.TryGetProperty("pendingReprimand", out var pr) &&
                                  pr.Kind == JsonValueKind.Boolean && pr.Bool,
                LastSettledDeviation = (int)e.GetNumber("lastSettledDeviation"),
                HasSchedule = e.TryGetProperty("hasSchedule", out var hs) && hs.Kind == JsonValueKind.Boolean && hs.Bool,
                ScheduleDefinitionId = e.GetString("scheduleDefinitionId", string.Empty),
                ActiveOrderSource = (int)e.GetNumber("activeOrderSource"),
                PersonalConcealmentRisk = (int)e.GetNumber("personalConcealmentRisk"),
                HasEntityLocation = e.TryGetProperty("hasEntityLocation", out var hel) && hel.Kind == JsonValueKind.Boolean && hel.Bool,
                EntityLocationSnapshotFieldPresent = e.TryGetProperty("hasEntityLocation", out _),
                LocationId = e.GetString("locationId", string.Empty),
                HasPresentationOverride = e.TryGetProperty("hasPresentationOverride", out var hpo) && hpo.Kind == JsonValueKind.Boolean && hpo.Bool,
                PresentationOverrideX = (float)e.GetNumber("presentationOverrideX"),
                PresentationOverrideZ = (float)e.GetNumber("presentationOverrideZ"),
                FactionId = e.GetString("factionId", string.Empty),
                FactionRole = (int)e.GetNumber("factionRole"),
                HasCombatVitals = e.TryGetProperty("hasCombatVitals", out var hcv) &&
                                  hcv.Kind == JsonValueKind.Boolean &&
                                  hcv.Bool,
                CurrentHp = (int)e.GetNumber("currentHp"),
                CurrentSpiritPower = (int)e.GetNumber("currentSpiritPower"),
                VitalsPoolsInitialized = e.TryGetProperty("vitalsPoolsInitialized", out var vpi) &&
                                         vpi.Kind == JsonValueKind.Boolean &&
                                         vpi.Bool,
                BleedOutAfterTick = ReadU(e, "bleedOutAfterTick"),
                HasCorpse = e.TryGetProperty("hasCorpse", out var hco) &&
                            hco.Kind == JsonValueKind.Boolean &&
                            hco.Bool,
                CorpseRemoveAfterTick = ReadU(e, "corpseRemoveAfterTick"),
                HasResponsibleAttacker = e.TryGetProperty("hasResponsibleAttacker", out var hra) &&
                                         hra.Kind == JsonValueKind.Boolean && hra.Bool,
                ResponsibleAttackerEntityId = ReadU(e, "responsibleAttackerEntityId")
            };

            if (e.TryGetProperty("knownSiteIds", out var known) && known.Kind == JsonValueKind.Array)
            {
                foreach (var k in known.Array)
                {
                    if (k.Kind == JsonValueKind.String)
                        dto.KnownSiteIds.Add(k.String);
                }
            }

            if (e.TryGetProperty("combatArtsLearned", out var learnedArts) && learnedArts.Kind == JsonValueKind.Array)
            {
                foreach (var art in learnedArts.Array)
                    if (art.Kind == JsonValueKind.String)
                        dto.CombatArtsLearned.Add(art.String);
            }

            if (e.TryGetProperty("combatArtsEquipped", out var equippedArts) && equippedArts.Kind == JsonValueKind.Array)
            {
                foreach (var art in equippedArts.Array)
                    if (art.Kind == JsonValueKind.String)
                        dto.CombatArtsEquipped.Add(art.String);
            }

            if (e.TryGetProperty("combatArtMastery", out var artMastery) && artMastery.Kind == JsonValueKind.Array)
            {
                foreach (var mastery in artMastery.Array)
                {
                    if (mastery.Kind != JsonValueKind.Object)
                        continue;
                    dto.CombatArtMastery.Add(new ArtMasterySnapshotDto
                    {
                        ArtId = mastery.GetString("artId", string.Empty),
                        Tier = (int)mastery.GetNumber("tier"),
                        Progress = (int)mastery.GetNumber("progress"),
                        ProgressRequired = (int)mastery.GetNumber("progressRequired")
                    });
                }
            }

            if (e.TryGetProperty("personalityTags", out var personalityTags) &&
                personalityTags.Kind == JsonValueKind.Array)
            {
                foreach (var tag in personalityTags.Array)
                {
                    if (tag.Kind == JsonValueKind.String)
                        dto.PersonalityTags.Add(tag.String);
                }
            }

            if (e.TryGetProperty("bases", out var bases) && bases.Kind == JsonValueKind.Array)
            {
                foreach (var b in bases.Array)
                {
                    dto.Bases.Add(new AttrBaseDto
                    {
                        AttributeId = (int)b.GetNumber("attributeId"),
                        Value = (int)b.GetNumber("value")
                    });
                }
            }

            if (e.TryGetProperty("modifiers", out var mods) && mods.Kind == JsonValueKind.Array)
            {
                foreach (var m in mods.Array)
                {
                    dto.Modifiers.Add(new ModifierSnapshotDto
                    {
                        Id = (ulong)m.GetNumber("id"),
                        AttributeId = (int)m.GetNumber("attributeId"),
                        Operation = (int)m.GetNumber("operation"),
                        Value = m.GetNumber("value"),
                        SourceKind = (int)m.GetNumber("sourceKind"),
                        SourceDefinitionId = m.GetString("sourceDefinitionId", string.Empty),
                        SourceEntityId = (ulong)m.GetNumber("sourceEntityId"),
                        HasSourceEntity = m.TryGetProperty("hasSourceEntity", out var hse) && hse.Kind == JsonValueKind.Boolean && hse.Bool,
                        SourceModifierId = (ulong)m.GetNumber("sourceModifierId"),
                        HasSourceModifier = m.TryGetProperty("hasSourceModifier", out var hsm) && hsm.Kind == JsonValueKind.Boolean && hsm.Bool
                    });
                }
            }

            return dto;
        }

        static ActiveActionSnapshotDto ReadAction(JsonValue a) => new ActiveActionSnapshotDto
        {
            Id = (ulong)a.GetNumber("id"),
            SubjectId = (ulong)a.GetNumber("subjectId"),
            SourceOrderId = (ulong)a.GetNumber("sourceOrderId"),
            Kind = a.GetString("kind", "Wait"),
            Status = (int)a.GetNumber("status"),
            TotalTicks = (ulong)a.GetNumber("totalTicks"),
            RemainingTicks = (ulong)a.GetNumber("remainingTicks"),
            TargetRef = a.GetString("targetRef", string.Empty),
            Activity = (int)a.GetNumber("activity")
        };

        static JsonValue U(ulong value) => JsonValue.FromString(value.ToString(CultureInfo.InvariantCulture));

        static ulong ReadU(JsonValue root, string name)
        {
            if (!root.TryGetProperty(name, out var v)) return 0;
            return ReadUValue(v);
        }

        static ulong ReadUValue(JsonValue v)
        {
            if (v == null) return 0;
            if (v.Kind == JsonValueKind.String &&
                ulong.TryParse(v.String, NumberStyles.Integer, CultureInfo.InvariantCulture, out var parsed))
                return parsed;
            if (v.Kind == JsonValueKind.Number)
                return (ulong)v.Number;
            return 0;
        }

        static OrderSnapshotDto ReadOrder(JsonValue o) => new OrderSnapshotDto
        {
            Id = (ulong)o.GetNumber("id"),
            SubjectId = (ulong)o.GetNumber("subjectId"),
            Type = (int)o.GetNumber("type"),
            Source = (int)o.GetNumber("source"),
            WaitTicks = (ulong)o.GetNumber("waitTicks"),
            TargetRef = o.GetString("targetRef", string.Empty),
            Activity = (int)o.GetNumber("activity")
        };

        static ScheduleDefinitionSnapshotDto ReadSchedule(JsonValue s)
        {
            var dto = new ScheduleDefinitionSnapshotDto
            {
                Id = s.GetString("id", string.Empty)
            };
            if (s.TryGetProperty("blocks", out var blocks) && blocks.Kind == JsonValueKind.Array)
            {
                foreach (var b in blocks.Array)
                {
                    dto.Blocks.Add(new ScheduleBlockSnapshotDto
                    {
                        StartTickInDay = (int)b.GetNumber("startTickInDay"),
                        EndTickInDay = (int)b.GetNumber("endTickInDay"),
                        Activity = (int)b.GetNumber("activity"),
                        OrderDurationTicks = (ulong)b.GetNumber("orderDurationTicks")
                    });
                }
            }

            return dto;
        }

        static OpportunitySiteSnapshotDto ReadOpportunitySite(JsonValue s) => new OpportunitySiteSnapshotDto
        {
            Id = s.GetString("id", string.Empty),
            AllowsCultivation = s.TryGetProperty("allowsCultivation", out var ac) &&
                                ac.Kind == JsonValueKind.Boolean && ac.Bool,
            OfferedManualId = s.GetString("offeredManualId", string.Empty),
            NameKey = s.GetString("nameKey", string.Empty),
            Description = s.GetString("description", string.Empty)
        };

        static ManualSnapshotDto ReadManual(JsonValue m) => new ManualSnapshotDto
        {
            Id = m.GetString("id", string.Empty),
            RequiredRealm = m.GetString("requiredRealm", string.Empty),
            CultivationSpeed = (int)m.GetNumber("cultivationSpeed"),
            BreakthroughProgress = (int)m.GetNumber("breakthroughProgress")
        };

        static List<JsonValue> SerializeHexPath(List<HexCoordSnapshotDto> path)
        {
            var list = new List<JsonValue>();
            if (path == null)
                return list;
            for (var i = 0; i < path.Count; i++)
            {
                var coord = path[i];
                if (coord == null)
                    continue;
                list.Add(JsonValue.FromObject(new Dictionary<string, JsonValue>
                {
                    ["q"] = JsonValue.FromNumber(coord.Q),
                    ["r"] = JsonValue.FromNumber(coord.R)
                }));
            }

            return list;
        }

        static List<HexCoordSnapshotDto> ReadHexPath(JsonValue pathNode)
        {
            var list = new List<HexCoordSnapshotDto>();
            if (pathNode.Kind != JsonValueKind.Array)
                return list;
            foreach (var node in pathNode.Array)
            {
                list.Add(new HexCoordSnapshotDto
                {
                    Q = (int)node.GetNumber("q"),
                    R = (int)node.GetNumber("r")
                });
            }

            return list;
        }

        static List<JsonValue> SerializeWorldPath(List<WorldPointSnapshotDto> path)
        {
            var list = new List<JsonValue>();
            if (path == null) return list;
            for (var i = 0; i < path.Count; i++)
            {
                var point = path[i];
                if (point == null) continue;
                list.Add(JsonValue.FromObject(new Dictionary<string, JsonValue>
                {
                    ["x"] = JsonValue.FromNumber(point.X),
                    ["y"] = JsonValue.FromNumber(point.Y)
                }));
            }
            return list;
        }

        static JsonValue SerializeStrategic(StrategicSnapshotDto strategic)
        {
            strategic ??= new StrategicSnapshotDto();
            var squads = new List<JsonValue>();
            if (strategic.Squads != null)
                for (var i = 0; i < strategic.Squads.Count; i++)
                {
                    var s = strategic.Squads[i];
                    if (s == null) continue;
                    var members = new List<JsonValue>();
                    for (var m = 0; m < s.MemberCharacterIds.Count; m++) members.Add(U(s.MemberCharacterIds[m]));
                    squads.Add(JsonValue.FromObject(new Dictionary<string, JsonValue>
                    {
                        ["squadId"] = JsonValue.FromString(s.SquadId ?? string.Empty),
                        ["displayName"] = JsonValue.FromString(s.DisplayName ?? string.Empty),
                        ["factionId"] = JsonValue.FromString(s.FactionId ?? string.Empty),
                        ["leaderCharacterId"] = U(s.LeaderCharacterId),
                        ["legacyArmyId"] = JsonValue.FromString(s.LegacyArmyId ?? string.Empty),
                        ["commandKind"] = JsonValue.FromNumber(s.CommandKind),
                        ["commandRevision"] = U(s.CommandRevision),
                        ["commandTargetCharacterId"] = U(s.CommandTargetCharacterId),
                        ["memberCharacterIds"] = JsonValue.FromArray(members)
                    }));
                }
            var squadWorldMotions = new List<JsonValue>();
            if (strategic.SquadWorldMotions != null)
                for (var i = 0; i < strategic.SquadWorldMotions.Count; i++)
                {
                    var m = strategic.SquadWorldMotions[i];
                    if (m == null) continue;
                    squadWorldMotions.Add(JsonValue.FromObject(new Dictionary<string, JsonValue>
                    {
                        ["squadId"] = JsonValue.FromString(m.SquadId ?? string.Empty),
                        ["surfaceId"] = JsonValue.FromString(m.SurfaceId ?? string.Empty),
                        ["siteId"] = JsonValue.FromString(m.SiteId ?? string.Empty),
                        ["worldX"] = JsonValue.FromNumber(m.WorldX), ["worldY"] = JsonValue.FromNumber(m.WorldY),
                        ["isMoving"] = JsonValue.FromBool(m.IsMoving),
                        ["destinationX"] = JsonValue.FromNumber(m.DestinationX), ["destinationY"] = JsonValue.FromNumber(m.DestinationY),
                        ["waypointIndex"] = JsonValue.FromNumber(m.WaypointIndex),
                        ["segmentProgress"] = JsonValue.FromNumber(m.SegmentProgress),
                        ["sourceRevision"] = JsonValue.FromString(m.SourceRevision ?? string.Empty),
                        ["sourceHash"] = JsonValue.FromString(m.SourceHash ?? string.Empty),
                        ["route"] = JsonValue.FromArray(SerializeWorldPath(m.Route))
                    }));
                }
            var armies = new List<JsonValue>();
            if (strategic.FormalArmies != null)
            {
                for (var i = 0; i < strategic.FormalArmies.Count; i++)
                {
                    var a = strategic.FormalArmies[i];
                    if (a == null)
                        continue;
                    var members = new List<JsonValue>();
                    if (a.MemberCharacterIds != null)
                    {
                        for (var j = 0; j < a.MemberCharacterIds.Count; j++)
                            members.Add(U(a.MemberCharacterIds[j]));
                    }

                    armies.Add(JsonValue.FromObject(new Dictionary<string, JsonValue>
                    {
                        ["armyId"] = JsonValue.FromString(a.ArmyId ?? string.Empty),
                        ["factionId"] = JsonValue.FromString(a.FactionId ?? string.Empty),
                        ["leaderCharacterId"] = U(a.LeaderCharacterId),
                        ["state"] = JsonValue.FromNumber(a.State),
                        ["usesHexStrategicPosition"] = JsonValue.FromBool(a.UsesHexStrategicPosition),
                        ["currentHexQ"] = JsonValue.FromNumber(a.CurrentHexQ),
                        ["currentHexR"] = JsonValue.FromNumber(a.CurrentHexR),
                        ["destinationHexQ"] = JsonValue.FromNumber(a.DestinationHexQ),
                        ["destinationHexR"] = JsonValue.FromNumber(a.DestinationHexR),
                        ["stepProgress"] = JsonValue.FromNumber(a.StepProgress),
                        ["stepRemainingTicks"] = JsonValue.FromNumber(a.StepRemainingTicks),
                        ["stepTotalTicks"] = JsonValue.FromNumber(a.StepTotalTicks),
                        ["currentPathIndex"] = JsonValue.FromNumber(a.CurrentPathIndex),
                        ["locationKind"] = JsonValue.FromNumber(a.LocationKind),
                        ["siteId"] = JsonValue.FromString(a.SiteId ?? string.Empty),
                        ["worldX"] = JsonValue.FromNumber(a.WorldX),
                        ["worldY"] = JsonValue.FromNumber(a.WorldY),
                        ["destinationSiteId"] = JsonValue.FromString(a.DestinationSiteId ?? string.Empty),
                        ["currentOrderKind"] = JsonValue.FromNumber(a.CurrentOrderKind),
                        ["orderTargetArmyId"] = JsonValue.FromString(a.OrderTargetArmyId ?? string.Empty),
                        ["segmentProgress"] = JsonValue.FromNumber(a.SegmentProgress),
                        ["segmentIndex"] = JsonValue.FromNumber(a.SegmentIndex),
                        ["travelMode"] = JsonValue.FromNumber(a.TravelMode),
                        ["hasSiteDepartureState"] = JsonValue.FromBool(a.HasSiteDepartureState),
                        ["isSiteDeparturePending"] = JsonValue.FromBool(a.IsSiteDeparturePending),
                        ["siteDepartureVirtualX"] = JsonValue.FromNumber(a.SiteDepartureVirtualX),
                        ["siteDepartureVirtualY"] = JsonValue.FromNumber(a.SiteDepartureVirtualY),
                        ["siteDepartureBoundaryX"] = JsonValue.FromNumber(a.SiteDepartureBoundaryX),
                        ["siteDepartureBoundaryY"] = JsonValue.FromNumber(a.SiteDepartureBoundaryY),
                        ["siteDepartureFootprintQ"] = JsonValue.FromNumber(a.SiteDepartureFootprintQ),
                        ["siteDepartureFootprintR"] = JsonValue.FromNumber(a.SiteDepartureFootprintR),
                        ["siteDepartureExitQ"] = JsonValue.FromNumber(a.SiteDepartureExitQ),
                        ["siteDepartureExitR"] = JsonValue.FromNumber(a.SiteDepartureExitR),
                        ["routeKind"] = JsonValue.FromNumber(a.RouteKind),
                        ["surfaceId"] = JsonValue.FromString(a.SurfaceId ?? string.Empty),
                        ["surfaceSourceRevision"] = JsonValue.FromString(a.SurfaceSourceRevision ?? string.Empty),
                        ["surfaceSourceHash"] = JsonValue.FromString(a.SurfaceSourceHash ?? string.Empty),
                        ["physicalDestinationX"] = JsonValue.FromNumber(a.PhysicalDestinationX),
                        ["physicalDestinationY"] = JsonValue.FromNumber(a.PhysicalDestinationY),
                        ["surfaceWaypointIndex"] = JsonValue.FromNumber(a.SurfaceWaypointIndex),
                        ["routeDiagnostic"] = JsonValue.FromString(a.RouteDiagnostic ?? string.Empty),
                        ["surfacePath"] = JsonValue.FromArray(SerializeWorldPath(a.SurfacePath)),
                        ["memberCharacterIds"] = JsonValue.FromArray(members),
                        ["hexPath"] = JsonValue.FromArray(SerializeHexPath(a.HexPath))
                    }));
                }
            }

            var memberships = new List<JsonValue>();
            if (strategic.ArmyMemberships != null)
            {
                for (var i = 0; i < strategic.ArmyMemberships.Count; i++)
                {
                    var m = strategic.ArmyMemberships[i];
                    if (m == null)
                        continue;
                    memberships.Add(JsonValue.FromObject(new Dictionary<string, JsonValue>
                    {
                        ["characterId"] = U(m.CharacterId),
                        ["armyId"] = JsonValue.FromString(m.ArmyId ?? string.Empty)
                    }));
                }
            }

            var residuals = new List<JsonValue>();
            if (strategic.ResidualCharacterPresences != null)
            {
                for (var i = 0; i < strategic.ResidualCharacterPresences.Count; i++)
                {
                    var r = strategic.ResidualCharacterPresences[i];
                    if (r == null)
                        continue;
                    residuals.Add(JsonValue.FromObject(new Dictionary<string, JsonValue>
                    {
                        ["characterId"] = U(r.CharacterId),
                        ["hexQ"] = JsonValue.FromNumber(r.HexQ),
                        ["hexR"] = JsonValue.FromNumber(r.HexR)
                    }));
                }
            }

            var characterWorldPresences = new List<JsonValue>();
            if (strategic.CharacterWorldPresences != null)
            {
                for (var i = 0; i < strategic.CharacterWorldPresences.Count; i++)
                {
                    var p = strategic.CharacterWorldPresences[i];
                    if (p == null)
                        continue;
                    characterWorldPresences.Add(JsonValue.FromObject(new Dictionary<string, JsonValue>
                    {
                        ["characterId"] = U(p.CharacterId),
                        ["mode"] = JsonValue.FromNumber(p.Mode),
                        ["siteId"] = JsonValue.FromString(p.SiteId ?? string.Empty),
                        ["hexQ"] = JsonValue.FromNumber(p.HexQ),
                        ["hexR"] = JsonValue.FromNumber(p.HexR),
                        ["hasWorldPosition"] = JsonValue.FromBool(p.HasWorldPosition),
                        ["personalSurfaceId"] = JsonValue.FromString(p.PersonalSurfaceId ?? string.Empty),
                        ["worldX"] = JsonValue.FromNumber(p.WorldX),
                        ["worldY"] = JsonValue.FromNumber(p.WorldY)
                    }));
                }
            }

            var siteOwners = new List<JsonValue>();
            if (strategic.WorldSiteOwners != null)
            {
                for (var i = 0; i < strategic.WorldSiteOwners.Count; i++)
                {
                    var s = strategic.WorldSiteOwners[i];
                    if (s == null)
                        continue;
                    siteOwners.Add(JsonValue.FromObject(new Dictionary<string, JsonValue>
                    {
                        ["siteId"] = JsonValue.FromString(s.SiteId ?? string.Empty),
                        ["coreMetadataFormat"] = JsonValue.FromNumber(s.CoreMetadataFormat),
                        ["coreAssetId"] = JsonValue.FromString(s.CoreAssetId ?? ""),
                        ["coreSurfaceId"] = JsonValue.FromString(s.CoreSurfaceId ?? ""),
                        ["coreLevel"] = JsonValue.FromNumber(s.CoreLevel),
                        ["coreWorldX"] = JsonValue.FromNumber(s.CoreWorldX),
                        ["coreWorldY"] = JsonValue.FromNumber(s.CoreWorldY),
                        ["coreActive"] = JsonValue.FromBool(s.CoreActive),
                        ["ownerFactionId"] = JsonValue.FromString(s.OwnerFactionId ?? string.Empty)
                    }));
                }
            }

            var runtimeWorldSites = new List<JsonValue>();
            if (strategic.RuntimeWorldSites != null)
                for (var i = 0; i < strategic.RuntimeWorldSites.Count; i++)
                {
                    var s = strategic.RuntimeWorldSites[i];
                    if (s == null) continue;
                    runtimeWorldSites.Add(JsonValue.FromObject(new Dictionary<string, JsonValue>
                    {
                        ["siteId"] = JsonValue.FromString(s.SiteId ?? string.Empty),
                        ["displayName"] = JsonValue.FromString(s.DisplayName ?? string.Empty),
                        ["siteType"] = JsonValue.FromString(s.SiteType ?? string.Empty),
                        ["ownerFactionId"] = JsonValue.FromString(s.OwnerFactionId ?? string.Empty),
                        ["controlEstablishedOrder"] = JsonValue.FromNumber(s.ControlEstablishedOrder),
                        ["anchorQ"] = JsonValue.FromNumber(s.AnchorQ),
                        ["anchorR"] = JsonValue.FromNumber(s.AnchorR),
                        ["coreAssetId"] = JsonValue.FromString(s.CoreAssetId ?? string.Empty),
                        ["surfaceId"] = JsonValue.FromString(s.SurfaceId ?? string.Empty),
                        ["hasWorldPosition"] = JsonValue.FromBool(s.HasWorldPosition),
                        ["worldX"] = JsonValue.FromNumber(s.WorldX),
                        ["worldY"] = JsonValue.FromNumber(s.WorldY),
                        ["coreLevel"] = JsonValue.FromNumber(s.CoreLevel),
                        ["coreLevelFormat"] = JsonValue.FromNumber(s.CoreLevelFormat),
                        ["isCoreActive"] = JsonValue.FromBool(s.IsCoreActive),
                        ["coreIsRemovable"] = JsonValue.FromBool(s.CoreIsRemovable)
                    }));
                }

            var territoryClaims = new List<JsonValue>();
            if (strategic.TerritoryClaims != null)
                for (var i = 0; i < strategic.TerritoryClaims.Count; i++)
                {
                    var claim = strategic.TerritoryClaims[i];
                    if (claim == null) continue;
                    territoryClaims.Add(JsonValue.FromObject(new Dictionary<string, JsonValue>
                    {
                        ["formatVersion"] = JsonValue.FromNumber(claim.FormatVersion),
                        ["claimId"] = JsonValue.FromString(claim.ClaimId ?? string.Empty),
                        ["siteId"] = JsonValue.FromString(claim.SiteId ?? string.Empty),
                        ["surfaceId"] = JsonValue.FromString(claim.SurfaceId ?? string.Empty),
                        ["acquiredOrder"] = JsonValue.FromNumber(claim.AcquiredOrder),
                        ["centerX"] = JsonValue.FromNumber(claim.CenterX),
                        ["centerY"] = JsonValue.FromNumber(claim.CenterY),
                        ["width"] = JsonValue.FromNumber(claim.Width),
                        ["height"] = JsonValue.FromNumber(claim.Height)
                    }));
                }

            var wars = new List<JsonValue>();
            if (strategic.Wars != null)
            {
                for (var i = 0; i < strategic.Wars.Count; i++)
                {
                    var w = strategic.Wars[i];
                    if (w == null)
                        continue;
                    wars.Add(JsonValue.FromObject(new Dictionary<string, JsonValue>
                    {
                        ["warId"] = JsonValue.FromString(w.WarId ?? string.Empty),
                        ["active"] = JsonValue.FromBool(w.Active),
                        ["attackers"] = JsonValue.FromArray(SerializeStringList(w.Attackers)),
                        ["defenders"] = JsonValue.FromArray(SerializeStringList(w.Defenders))
                    }));
                }
            }

            var alliances = new List<JsonValue>();
            if (strategic.Alliances != null)
            {
                for (var i = 0; i < strategic.Alliances.Count; i++)
                {
                    var a = strategic.Alliances[i];
                    if (a == null)
                        continue;
                    alliances.Add(JsonValue.FromObject(new Dictionary<string, JsonValue>
                    {
                        ["allianceId"] = JsonValue.FromString(a.AllianceId ?? string.Empty),
                        ["members"] = JsonValue.FromArray(SerializeStringList(a.Members))
                    }));
                }
            }

            var vassalages = new List<JsonValue>();
            if (strategic.Vassalages != null)
            {
                for (var i = 0; i < strategic.Vassalages.Count; i++)
                {
                    var v = strategic.Vassalages[i];
                    if (v == null)
                        continue;
                    vassalages.Add(JsonValue.FromObject(new Dictionary<string, JsonValue>
                    {
                        ["vassalFactionId"] = JsonValue.FromString(v.VassalFactionId ?? string.Empty),
                        ["overlordFactionId"] = JsonValue.FromString(v.OverlordFactionId ?? string.Empty)
                    }));
                }
            }

            var retreating = new List<JsonValue>();
            if (strategic.RetreatingArmies != null)
            {
                for (var i = 0; i < strategic.RetreatingArmies.Count; i++)
                {
                    var r = strategic.RetreatingArmies[i];
                    if (r == null)
                        continue;
                    var retreatMembers = new List<JsonValue>();
                    if (r.MemberCharacterIds != null)
                    {
                        for (var j = 0; j < r.MemberCharacterIds.Count; j++)
                            retreatMembers.Add(U(r.MemberCharacterIds[j]));
                    }

                    retreating.Add(JsonValue.FromObject(new Dictionary<string, JsonValue>
                    {
                        ["retreatingArmyId"] = JsonValue.FromString(r.RetreatingArmyId ?? string.Empty),
                        ["sourceArmyId"] = JsonValue.FromString(r.SourceArmyId ?? string.Empty),
                        ["factionId"] = JsonValue.FromString(r.FactionId ?? string.Empty),
                        ["hexQ"] = JsonValue.FromNumber(r.HexQ),
                        ["hexR"] = JsonValue.FromNumber(r.HexR),
                        ["memberCharacterIds"] = JsonValue.FromArray(retreatMembers)
                    }));
                }
            }

            var controlCores = new List<JsonValue>();
            if (strategic.ControlCores != null)
            {
                for (var i = 0; i < strategic.ControlCores.Count; i++)
                {
                    var c = strategic.ControlCores[i];
                    if (c == null)
                        continue;
                    controlCores.Add(JsonValue.FromObject(new Dictionary<string, JsonValue>
                    {
                        ["workAreaId"] = JsonValue.FromString(c.WorkAreaId ?? string.Empty),
                        ["currentDurability"] = JsonValue.FromNumber(c.CurrentDurability),
                        ["occupyProgressSeconds"] = JsonValue.FromNumber(c.OccupyProgressSeconds)
                    }));
                }
            }

            var worldSitePublicStocks = new List<JsonValue>();
            if (strategic.WorldSitePublicStocks != null)
            {
                for (var i = 0; i < strategic.WorldSitePublicStocks.Count; i++)
                {
                    var stock = strategic.WorldSitePublicStocks[i];
                    if (stock == null) continue;
                    var entries = new List<JsonValue>();
                    if (stock.Entries != null)
                        for (var e = 0; e < stock.Entries.Count; e++)
                        {
                            var entry = stock.Entries[e];
                            if (entry == null) continue;
                            entries.Add(JsonValue.FromObject(new Dictionary<string, JsonValue>
                            {
                                ["resourceId"] = JsonValue.FromString(entry.ResourceId ?? string.Empty),
                                ["amount"] = JsonValue.FromNumber(entry.Amount)
                            }));
                        }
                    worldSitePublicStocks.Add(JsonValue.FromObject(new Dictionary<string, JsonValue>
                    {
                        ["siteId"] = JsonValue.FromString(stock.SiteId ?? string.Empty),
                        ["entries"] = JsonValue.FromArray(entries)
                    }));
                }
            }

            var root = new Dictionary<string, JsonValue>
            {
                ["playerFactionId"] = JsonValue.FromString(strategic.PlayerFactionId ?? string.Empty),
                ["ch01FormationScenarioCompat"] = JsonValue.FromBool(strategic.Ch01FormationScenarioCompat),
                ["hasSquadSnapshotAuthority"] = JsonValue.FromBool(strategic.HasSquadSnapshotAuthority),
                ["hasSquadWorldMotionSnapshotAuthority"] = JsonValue.FromBool(strategic.HasSquadWorldMotionSnapshotAuthority),
                ["controlledSquadId"] = JsonValue.FromString(strategic.ControlledSquadId ?? string.Empty),
                ["squads"] = JsonValue.FromArray(squads),
                ["squadWorldMotions"] = JsonValue.FromArray(squadWorldMotions),
                ["formalArmies"] = JsonValue.FromArray(armies),
                ["armyMemberships"] = JsonValue.FromArray(memberships),
                ["residualCharacterPresences"] = JsonValue.FromArray(residuals),
                ["characterWorldPresences"] = JsonValue.FromArray(characterWorldPresences),
                ["worldSiteOwners"] = JsonValue.FromArray(siteOwners),
                ["runtimeWorldSites"] = JsonValue.FromArray(runtimeWorldSites),
                ["hasTerritoryClaimSnapshotAuthority"] =
                    JsonValue.FromBool(strategic.HasTerritoryClaimSnapshotAuthority),
                ["wars"] = JsonValue.FromArray(wars),
                ["alliances"] = JsonValue.FromArray(alliances),
                ["vassalages"] = JsonValue.FromArray(vassalages),
                ["retreatingArmies"] = JsonValue.FromArray(retreating),
                ["controlCores"] = JsonValue.FromArray(controlCores),
                ["worldSitePublicStocks"] = JsonValue.FromArray(worldSitePublicStocks)
            };
            if (strategic.HasTerritoryClaimSnapshotAuthority)
                root["territoryClaims"] = JsonValue.FromArray(territoryClaims);
            var flagValues = new List<JsonValue>();
            foreach (var flag in strategic.FactionFlags)
                if (flag != null) flagValues.Add(JsonValue.FromObject(new Dictionary<string, JsonValue>
                {
                    ["flagId"]=JsonValue.FromString(flag.FlagId??string.Empty), ["factionId"]=JsonValue.FromString(flag.FactionId??string.Empty),
                    ["anchorQ"]=JsonValue.FromNumber(flag.AnchorQ), ["anchorR"]=JsonValue.FromNumber(flag.AnchorR), ["establishedOrder"]=JsonValue.FromNumber(flag.EstablishedOrder),
                    ["currentHp"]=JsonValue.FromNumber(flag.CurrentHp), ["maxHp"]=JsonValue.FromNumber(flag.MaxHp), ["hasLocalPosition"]=JsonValue.FromBool(flag.HasLocalPosition),
                    ["localX"]=JsonValue.FromNumber(flag.LocalX), ["localZ"]=JsonValue.FromNumber(flag.LocalZ),
                    ["siteCoreFormat"]=JsonValue.FromNumber(1),
                    ["hasWorldPosition"]=JsonValue.FromBool(flag.HasWorldPosition),
                    ["worldX"]=JsonValue.FromNumber(flag.WorldX), ["worldY"]=JsonValue.FromNumber(flag.WorldY),
                    ["siteId"]=JsonValue.FromString(flag.SiteId??string.Empty),
                    ["surfaceId"]=JsonValue.FromString(flag.SurfaceId??string.Empty),
                    ["isSiteCore"]=JsonValue.FromBool(flag.IsSiteCore)
                }));
            if (strategic.HasFactionFlagSnapshotAuthority) root["factionFlags"] = JsonValue.FromArray(flagValues);

            // Additive NPC travel intent. Legacy Hex paths remain readable; Surface paths are
            // recomputed from exact WorldPosition and authored Site arrival after shell rehydrate.
            var backgroundTravels = new List<JsonValue>();
            foreach (var travel in strategic.BackgroundCharacterTravels)
            {
                if (travel == null) continue;
                backgroundTravels.Add(JsonValue.FromObject(new Dictionary<string, JsonValue>
                {
                    ["characterId"] = U(travel.CharacterId),
                    ["locationKind"] = JsonValue.FromNumber(travel.LocationKind),
                    ["siteId"] = JsonValue.FromString(travel.SiteId ?? string.Empty),
                    ["worldX"] = JsonValue.FromNumber(travel.WorldX),
                    ["worldY"] = JsonValue.FromNumber(travel.WorldY),
                    ["currentHexQ"] = JsonValue.FromNumber(travel.CurrentHexQ),
                    ["currentHexR"] = JsonValue.FromNumber(travel.CurrentHexR),
                    ["isTraveling"] = JsonValue.FromBool(travel.IsTraveling),
                    ["destinationHexQ"] = JsonValue.FromNumber(travel.DestinationHexQ),
                    ["destinationHexR"] = JsonValue.FromNumber(travel.DestinationHexR),
                    ["destinationSiteId"] = JsonValue.FromString(travel.DestinationSiteId ?? string.Empty),
                    ["segmentIndex"] = JsonValue.FromNumber(travel.SegmentIndex),
                    ["segmentProgress"] = JsonValue.FromNumber(travel.SegmentProgress),
                    ["lastProcessedWorldTick"] = U(travel.LastProcessedWorldTick),
                    ["hexPath"] = JsonValue.FromArray(SerializeHexPath(travel.HexPath)),
                    ["isSurfaceRoute"] = JsonValue.FromBool(travel.IsSurfaceRoute),
                    ["surfaceId"] = JsonValue.FromString(travel.SurfaceId ?? string.Empty),
                    ["surfaceDestinationX"] = JsonValue.FromNumber(travel.SurfaceDestinationX),
                    ["surfaceDestinationY"] = JsonValue.FromNumber(travel.SurfaceDestinationY)
                }));
            }
            root["backgroundCharacterTravels"] = JsonValue.FromArray(backgroundTravels);

            if (strategic.PlayerPartyTravel != null && strategic.PlayerPartyTravel.HasPosition)
            {
                var p = strategic.PlayerPartyTravel;
                root["playerPartyTravel"] = JsonValue.FromObject(new Dictionary<string, JsonValue>
                {
                    ["hasPosition"] = JsonValue.FromBool(true),
                    ["locationKind"] = JsonValue.FromNumber(p.LocationKind),
                    ["siteId"] = JsonValue.FromString(p.SiteId ?? string.Empty),
                    ["worldX"] = JsonValue.FromNumber(p.WorldX),
                    ["worldY"] = JsonValue.FromNumber(p.WorldY),
                    ["currentHexQ"] = JsonValue.FromNumber(p.CurrentHexQ),
                    ["currentHexR"] = JsonValue.FromNumber(p.CurrentHexR),
                    ["isMoving"] = JsonValue.FromBool(p.IsMoving),
                    ["hasContinuousPhysicalDestination"] = JsonValue.FromBool(p.HasContinuousPhysicalDestination),
                    ["destinationWorldX"] = JsonValue.FromNumber(p.DestinationWorldX),
                    ["destinationWorldY"] = JsonValue.FromNumber(p.DestinationWorldY),
                    ["arrivalRadius"] = JsonValue.FromNumber(p.ArrivalRadius),
                    ["destinationSiteId"] = JsonValue.FromString(p.DestinationSiteId ?? string.Empty),
                    ["executionMode"] = JsonValue.FromNumber(p.ExecutionMode)
                });
            }

            if (strategic.PlayerParty != null && strategic.PlayerParty.MemberCharacterIds != null &&
                strategic.PlayerParty.MemberCharacterIds.Count > 0)
            {
                var members = new List<JsonValue>();
                for (var i = 0; i < strategic.PlayerParty.MemberCharacterIds.Count; i++)
                    members.Add(U(strategic.PlayerParty.MemberCharacterIds[i]));
                root["playerParty"] = JsonValue.FromObject(new Dictionary<string, JsonValue>
                {
                    ["activeCharacterId"] = U(strategic.PlayerParty.ActiveCharacterId),
                    ["memberCharacterIds"] = JsonValue.FromArray(members)
                });
            }

            if (strategic.LoadedLocalMapCharacterPlacements != null &&
                strategic.LoadedLocalMapCharacterPlacements.Count > 0)
            {
                var placements = new List<JsonValue>();
                for (var i = 0; i < strategic.LoadedLocalMapCharacterPlacements.Count; i++)
                {
                    var p = strategic.LoadedLocalMapCharacterPlacements[i];
                    if (p == null || p.CharacterId == 0 || string.IsNullOrWhiteSpace(p.LocalMapId))
                        continue;
                    placements.Add(JsonValue.FromObject(new Dictionary<string, JsonValue>
                    {
                        ["characterId"] = U(p.CharacterId),
                        ["localMapId"] = JsonValue.FromString(p.LocalMapId),
                        ["localX"] = JsonValue.FromNumber(p.LocalX),
                        ["localZ"] = JsonValue.FromNumber(p.LocalZ)
                    }));
                }

                if (placements.Count > 0)
                    root["loadedLocalMapCharacterPlacements"] = JsonValue.FromArray(placements);
            }

            if (strategic.PendingEngagement != null &&
                !string.IsNullOrEmpty(strategic.PendingEngagement.EngagementId))
            {
                root["pendingEngagement"] = SerializePendingEngagement(strategic.PendingEngagement);
            }

            return JsonValue.FromObject(root);
        }

        static StrategicSnapshotDto ReadStrategic(JsonValue strategic)
        {
            var dto = new StrategicSnapshotDto
            {
                PlayerFactionId = strategic.GetString("playerFactionId", string.Empty),
                Ch01FormationScenarioCompat = strategic.TryGetProperty("ch01FormationScenarioCompat", out var c) &&
                                              c.Kind == JsonValueKind.Boolean && c.Bool,
                HasSquadSnapshotAuthority = strategic.GetBool("hasSquadSnapshotAuthority", false),
                HasSquadWorldMotionSnapshotAuthority = strategic.GetBool("hasSquadWorldMotionSnapshotAuthority", false),
                HasTerritoryClaimSnapshotAuthority =
                    strategic.GetBool("hasTerritoryClaimSnapshotAuthority", false),
                ControlledSquadId = strategic.GetString("controlledSquadId", string.Empty)
            };
            if (!dto.HasTerritoryClaimSnapshotAuthority &&
                strategic.TryGetProperty("territoryClaims", out _))
                throw new System.FormatException(
                    "territoryClaims cannot be present without territory claim authority.");

            if (strategic.TryGetProperty("squads", out var squads) && squads.Kind == JsonValueKind.Array)
            {
                // An explicitly legacy DTO may serialize an empty squads array. Only infer
                // authority for the transitional format which has no explicit flag.
                if (squads.Array.Count > 0 || !strategic.TryGetProperty("hasSquadSnapshotAuthority", out _))
                    dto.HasSquadSnapshotAuthority = true;
                foreach (var node in squads.Array)
                {
                    var item = new SquadSnapshotDto
                    {
                        SquadId = node.GetString("squadId", string.Empty),
                        DisplayName = node.GetString("displayName", string.Empty),
                        FactionId = node.GetString("factionId", string.Empty),
                        LeaderCharacterId = ReadU(node, "leaderCharacterId"),
                        LegacyArmyId = node.GetString("legacyArmyId", string.Empty),
                        CommandKind = node.TryGetProperty("commandKind", out var ck) ? (int)ck.Number : 0,
                        CommandRevision = ReadU(node, "commandRevision"),
                        CommandTargetCharacterId = ReadU(node, "commandTargetCharacterId")
                    };
                    if (node.TryGetProperty("memberCharacterIds", out var members) && members.Kind == JsonValueKind.Array)
                        foreach (var member in members.Array) item.MemberCharacterIds.Add(ReadUValue(member));
                    dto.Squads.Add(item);
                }
            }

            if (strategic.TryGetProperty("squadWorldMotions", out var squadMotions) && squadMotions.Kind == JsonValueKind.Array)
            {
                if (!strategic.TryGetProperty("hasSquadWorldMotionSnapshotAuthority", out _)) dto.HasSquadWorldMotionSnapshotAuthority = true;
                foreach (var node in squadMotions.Array)
                {
                    var item = new SquadWorldMotionSnapshotDto
                    {
                        SquadId = node.GetString("squadId", string.Empty), SurfaceId = node.GetString("surfaceId", string.Empty), SiteId = node.GetString("siteId", string.Empty),
                        WorldX = (float)node.GetNumber("worldX"), WorldY = (float)node.GetNumber("worldY"),
                        IsMoving = node.GetBool("isMoving", false), DestinationX = (float)node.GetNumber("destinationX"), DestinationY = (float)node.GetNumber("destinationY"),
                        WaypointIndex = (int)node.GetNumber("waypointIndex"), SegmentProgress = (float)node.GetNumber("segmentProgress"),
                        SourceRevision = node.GetString("sourceRevision", string.Empty), SourceHash = node.GetString("sourceHash", string.Empty)
                    };
                    if (node.TryGetProperty("route", out var route) && route.Kind == JsonValueKind.Array)
                        foreach (var point in route.Array) item.Route.Add(new WorldPointSnapshotDto
                        { X = (float)point.GetNumber("x"), Y = (float)point.GetNumber("y") });
                    dto.SquadWorldMotions.Add(item);
                }
            }

            if (strategic.TryGetProperty("formalArmies", out var armies) && armies.Kind == JsonValueKind.Array)
            {
                foreach (var a in armies.Array)
                {
                    var army = new FormalArmySnapshotDto
                    {
                        ArmyId = a.GetString("armyId", string.Empty),
                        FactionId = a.GetString("factionId", string.Empty),
                        LeaderCharacterId = ReadU(a, "leaderCharacterId"),
                        State = (int)a.GetNumber("state"),
                        UsesHexStrategicPosition = a.TryGetProperty("usesHexStrategicPosition", out var usesHex) &&
                                                     usesHex.Kind == JsonValueKind.Boolean && usesHex.Bool,
                        CurrentHexQ = a.TryGetProperty("currentHexQ", out var cq) ? (int)cq.Number : 0,
                        CurrentHexR = a.TryGetProperty("currentHexR", out var cr) ? (int)cr.Number : 0,
                        DestinationHexQ = a.TryGetProperty("destinationHexQ", out var dq) ? (int)dq.Number : 0,
                        DestinationHexR = a.TryGetProperty("destinationHexR", out var dr) ? (int)dr.Number : 0,
                        StepProgress = a.TryGetProperty("stepProgress", out var sp) ? (float)sp.Number : 0f,
                        StepRemainingTicks = a.TryGetProperty("stepRemainingTicks", out var srt) ? (int)srt.Number : 0,
                        StepTotalTicks = a.TryGetProperty("stepTotalTicks", out var stt) ? (int)stt.Number : 0,
                        CurrentPathIndex = a.TryGetProperty("currentPathIndex", out var cpi) ? (int)cpi.Number : 0,
                        LocationKind = a.TryGetProperty("locationKind", out var lk) ? (int)lk.Number : 0,
                        SiteId = a.GetString("siteId", string.Empty),
                        WorldX = a.TryGetProperty("worldX", out var wx) ? (float)wx.Number : 0f,
                        WorldY = a.TryGetProperty("worldY", out var wy) ? (float)wy.Number : 0f,
                        DestinationSiteId = a.GetString("destinationSiteId", string.Empty),
                        CurrentOrderKind = a.TryGetProperty("currentOrderKind", out var ok) ? (int)ok.Number : 0,
                        OrderTargetArmyId = a.GetString("orderTargetArmyId", string.Empty),
                        SegmentProgress = a.TryGetProperty("segmentProgress", out var sp2) ? (float)sp2.Number : 0f,
                        SegmentIndex = a.TryGetProperty("segmentIndex", out var si) ? (int)si.Number : 0,
                        TravelMode = a.TryGetProperty("travelMode", out var tm) ? (int)tm.Number : 0,
                        HasSiteDepartureState = a.TryGetProperty("hasSiteDepartureState", out var hsds) &&
                                                hsds.Kind == JsonValueKind.Boolean && hsds.Bool,
                        IsSiteDeparturePending = a.TryGetProperty("isSiteDeparturePending", out var isdp) &&
                                                 isdp.Kind == JsonValueKind.Boolean && isdp.Bool,
                        SiteDepartureVirtualX = a.TryGetProperty("siteDepartureVirtualX", out var sdvx) ? (float)sdvx.Number : 0f,
                        SiteDepartureVirtualY = a.TryGetProperty("siteDepartureVirtualY", out var sdvy) ? (float)sdvy.Number : 0f,
                        SiteDepartureBoundaryX = a.TryGetProperty("siteDepartureBoundaryX", out var sdbx) ? (float)sdbx.Number : 0f,
                        SiteDepartureBoundaryY = a.TryGetProperty("siteDepartureBoundaryY", out var sdby) ? (float)sdby.Number : 0f,
                        SiteDepartureFootprintQ = a.TryGetProperty("siteDepartureFootprintQ", out var sdfq) ? (int)sdfq.Number : 0,
                        SiteDepartureFootprintR = a.TryGetProperty("siteDepartureFootprintR", out var sdfr) ? (int)sdfr.Number : 0,
                        SiteDepartureExitQ = a.TryGetProperty("siteDepartureExitQ", out var sdeq) ? (int)sdeq.Number : 0,
                        SiteDepartureExitR = a.TryGetProperty("siteDepartureExitR", out var sder) ? (int)sder.Number : 0,
                        RouteKind = a.TryGetProperty("routeKind", out var rk) ? (int)rk.Number : 0,
                        SurfaceId = a.GetString("surfaceId", string.Empty),
                        SurfaceSourceRevision = a.GetString("surfaceSourceRevision", string.Empty),
                        SurfaceSourceHash = a.GetString("surfaceSourceHash", string.Empty),
                        PhysicalDestinationX = a.TryGetProperty("physicalDestinationX", out var pdx) ? (float)pdx.Number : 0f,
                        PhysicalDestinationY = a.TryGetProperty("physicalDestinationY", out var pdy) ? (float)pdy.Number : 0f,
                        SurfaceWaypointIndex = a.TryGetProperty("surfaceWaypointIndex", out var swi) ? (int)swi.Number : 0,
                        RouteDiagnostic = a.GetString("routeDiagnostic", string.Empty),
                    };
                    if (a.TryGetProperty("memberCharacterIds", out var members) && members.Kind == JsonValueKind.Array)
                    {
                        foreach (var m in members.Array)
                            army.MemberCharacterIds.Add(ReadUValue(m));
                    }

                    if (a.TryGetProperty("hexPath", out var hexPath))
                        army.HexPath = ReadHexPath(hexPath);
                    if (a.TryGetProperty("surfacePath", out var surfacePath) &&
                        surfacePath.Kind == JsonValueKind.Array)
                    {
                        foreach (var point in surfacePath.Array)
                            army.SurfacePath.Add(new WorldPointSnapshotDto
                            {
                                X = point.TryGetProperty("x", out var x) ? (float)x.Number : 0f,
                                Y = point.TryGetProperty("y", out var y) ? (float)y.Number : 0f
                            });
                    }

                    dto.FormalArmies.Add(army);
                }
            }

            if (strategic.TryGetProperty("armyMemberships", out var armyMemberships) &&
                armyMemberships.Kind == JsonValueKind.Array)
            {
                foreach (var m in armyMemberships.Array)
                {
                    dto.ArmyMemberships.Add(new ArmyMembershipSnapshotDto
                    {
                        CharacterId = ReadU(m, "characterId"),
                        ArmyId = m.GetString("armyId", string.Empty)
                    });
                }
            }

            if (strategic.TryGetProperty("residualCharacterPresences", out var residuals) &&
                residuals.Kind == JsonValueKind.Array)
            {
                foreach (var r in residuals.Array)
                {
                    dto.ResidualCharacterPresences.Add(new ResidualCharacterPresenceDto
                    {
                        CharacterId = ReadU(r, "characterId"),
                        HexQ = (int)r.GetNumber("hexQ"),
                        HexR = (int)r.GetNumber("hexR")
                    });
                }
            }

            if (strategic.TryGetProperty("characterWorldPresences", out var charPresences) &&
                charPresences.Kind == JsonValueKind.Array)
            {
                foreach (var p in charPresences.Array)
                {
                    if (!string.IsNullOrEmpty(p.GetString("personalSurfaceId", string.Empty)) &&
                        (!p.TryGetProperty("worldX", out var personalX) || personalX.Kind != JsonValueKind.Number ||
                         !p.TryGetProperty("worldY", out var personalY) || personalY.Kind != JsonValueKind.Number))
                        throw new System.FormatException("Personal spatial authority requires explicit numeric worldX/worldY.");
                    dto.CharacterWorldPresences.Add(new CharacterWorldPresenceSnapshotDto
                    {
                        CharacterId = ReadU(p, "characterId"),
                        PersonalSurfaceId = p.GetString("personalSurfaceId", string.Empty),
                        Mode = p.TryGetProperty("mode", out var modeNode) ? (int)modeNode.Number : 0,
                        SiteId = p.GetString("siteId", string.Empty),
                        HexQ = p.TryGetProperty("hexQ", out var hq) ? (int)hq.Number : int.MinValue,
                        HexR = p.TryGetProperty("hexR", out var hr) ? (int)hr.Number : int.MinValue,
                        HasWorldPosition =
                            p.TryGetProperty("hasWorldPosition", out var hwp) &&
                            hwp.Kind == JsonValueKind.Boolean &&
                            hwp.Bool,
                        WorldX = p.TryGetProperty("worldX", out var wx)
                            ? (float)wx.Number
                            : 0f,
                        WorldY = p.TryGetProperty("worldY", out var wy)
                            ? (float)wy.Number
                            : 0f
                    });
                }
            }

            if (strategic.TryGetProperty("worldSiteOwners", out var siteOwners) &&
                siteOwners.Kind == JsonValueKind.Array)
            {
                foreach (var s in siteOwners.Array)
                {
                    dto.WorldSiteOwners.Add(new WorldSiteOwnerSnapshotDto
                    {
                        CoreMetadataFormat = (int)s.GetNumber("coreMetadataFormat", 0),
                        CoreAssetId = s.GetString("coreAssetId", ""), CoreSurfaceId = s.GetString("coreSurfaceId", ""),
                        CoreLevel = (int)s.GetNumber("coreLevel", 0),
                        CoreWorldX = (float)s.GetNumber("coreWorldX", double.NaN),
                        CoreWorldY = (float)s.GetNumber("coreWorldY", double.NaN),
                        CoreActive = s.GetBool("coreActive", false),
                        SiteId = s.GetString("siteId", string.Empty),
                        OwnerFactionId = s.GetString("ownerFactionId", string.Empty)
                    });
                }
            }

            if (strategic.TryGetProperty("territoryRegionControllers", out var territoryControllers) &&
                territoryControllers.Kind == JsonValueKind.Array)
            {
                foreach (var r in territoryControllers.Array)
                {
                    dto.TerritoryRegionControllers.Add(new TerritoryRegionControllerSnapshotDto
                    {
                        RegionId = r.GetString("regionId", string.Empty),
                        ControlFactionId = r.GetString("controlFactionId", string.Empty)
                    });
                }
            }
            if (dto.HasTerritoryClaimSnapshotAuthority)
            {
                if (!strategic.TryGetProperty("territoryClaims", out var territoryClaims) ||
                    territoryClaims.Kind != JsonValueKind.Array)
                    throw new System.FormatException(
                        "Territory claim authority requires an explicit territoryClaims array.");
                foreach (var claim in territoryClaims.Array)
                    dto.TerritoryClaims.Add(new TerritoryClaimSnapshotDto
                    {
                        FormatVersion = (int)claim.GetNumber("formatVersion"),
                        ClaimId = claim.GetString("claimId", string.Empty),
                        SiteId = claim.GetString("siteId", string.Empty),
                        SurfaceId = claim.GetString("surfaceId", string.Empty),
                        AcquiredOrder = (long)claim.GetNumber("acquiredOrder"),
                        CenterX = (float)claim.GetNumber("centerX", double.NaN),
                        CenterY = (float)claim.GetNumber("centerY", double.NaN),
                        Width = (float)claim.GetNumber("width", double.NaN),
                        Height = (float)claim.GetNumber("height", double.NaN)
                    });
            }
            if (strategic.TryGetProperty("runtimeWorldSites", out var runtimeSites) &&
                runtimeSites.Kind == JsonValueKind.Array)
            {
                dto.HasRuntimeWorldSiteSnapshotAuthority = true;
                foreach (var site in runtimeSites.Array)
                    dto.RuntimeWorldSites.Add(new RuntimeWorldSiteSnapshotDto
                    {
                        SiteId = site.GetString("siteId", string.Empty),
                        DisplayName = site.GetString("displayName", string.Empty),
                        SiteType = site.GetString("siteType", string.Empty),
                        OwnerFactionId = site.GetString("ownerFactionId", string.Empty),
                        ControlEstablishedOrder = (long)site.GetNumber("controlEstablishedOrder"),
                        AnchorQ = (int)site.GetNumber("anchorQ"),
                        AnchorR = (int)site.GetNumber("anchorR"),
                        CoreAssetId = site.GetString("coreAssetId", string.Empty),
                        SurfaceId = site.GetString("surfaceId", string.Empty),
                        HasWorldPosition = site.GetBool("hasWorldPosition", false),
                        WorldX = (float)site.GetNumber("worldX"),
                        WorldY = (float)site.GetNumber("worldY"),
                        CoreLevel = (int)site.GetNumber("coreLevel"),
                        CoreLevelFormat = (int)site.GetNumber("coreLevelFormat", 0),
                        RangeWidth = (float)site.GetNumber("rangeWidth"),
                        RangeHeight = (float)site.GetNumber("rangeHeight"),
                        IsCoreActive = site.GetBool("isCoreActive", false),
                        CoreIsRemovable = site.GetBool("coreIsRemovable", false)
                    });
            }
            if (strategic.TryGetProperty("factionFlags", out var factionFlags) && factionFlags.Kind == JsonValueKind.Array)
            {
                dto.HasFactionFlagSnapshotAuthority = true;
                foreach (var flag in factionFlags.Array)
                {
                    var siteCoreFormat = (int)flag.GetNumber("siteCoreFormat", 0);
                    dto.FactionFlags.Add(new FactionFlagSnapshotDto
                {
                    SiteCoreFormat=siteCoreFormat,
                    FlagId=flag.GetString("flagId",string.Empty), FactionId=flag.GetString("factionId",string.Empty),
                    AnchorQ=(int)flag.GetNumber("anchorQ"), AnchorR=(int)flag.GetNumber("anchorR"), EstablishedOrder=(long)flag.GetNumber("establishedOrder"),
                    CurrentHp=(int)flag.GetNumber("currentHp"), MaxHp=(int)flag.GetNumber("maxHp"), HasLocalPosition=flag.GetBool("hasLocalPosition"),
                    LocalX=(float)flag.GetNumber("localX"), LocalZ=(float)flag.GetNumber("localZ"),
                    HasWorldPosition=flag.GetBool("hasWorldPosition", false),
                    WorldX=(float)flag.GetNumber("worldX"), WorldY=(float)flag.GetNumber("worldY"),
                    SiteId=flag.GetString("siteId", string.Empty),
                    SurfaceId=flag.GetString("surfaceId", string.Empty),
                    IsSiteCore=flag.GetBool("isSiteCore", false)
                });
                }
            }

            if (strategic.TryGetProperty("wars", out var wars) && wars.Kind == JsonValueKind.Array)
            {
                foreach (var w in wars.Array)
                {
                    var war = new WarSnapshotDto
                    {
                        WarId = w.GetString("warId", string.Empty),
                        Active = w.TryGetProperty("active", out var active) &&
                                 active.Kind == JsonValueKind.Boolean && active.Bool
                    };
                    if (w.TryGetProperty("attackers", out var attackers) && attackers.Kind == JsonValueKind.Array)
                    {
                        foreach (var faction in attackers.Array)
                        {
                            if (faction.Kind == JsonValueKind.String)
                                war.Attackers.Add(faction.String);
                        }
                    }

                    if (w.TryGetProperty("defenders", out var defenders) && defenders.Kind == JsonValueKind.Array)
                    {
                        foreach (var faction in defenders.Array)
                        {
                            if (faction.Kind == JsonValueKind.String)
                                war.Defenders.Add(faction.String);
                        }
                    }

                    dto.Wars.Add(war);
                }
            }

            if (strategic.TryGetProperty("alliances", out var alliances) && alliances.Kind == JsonValueKind.Array)
            {
                foreach (var a in alliances.Array)
                {
                    var alliance = new AllianceSnapshotDto
                    {
                        AllianceId = a.GetString("allianceId", string.Empty)
                    };
                    if (a.TryGetProperty("members", out var members) && members.Kind == JsonValueKind.Array)
                    {
                        foreach (var member in members.Array)
                        {
                            if (member.Kind == JsonValueKind.String)
                                alliance.Members.Add(member.String);
                        }
                    }

                    dto.Alliances.Add(alliance);
                }
            }

            if (strategic.TryGetProperty("vassalages", out var vassalages) && vassalages.Kind == JsonValueKind.Array)
            {
                foreach (var v in vassalages.Array)
                {
                    dto.Vassalages.Add(new VassalageSnapshotDto
                    {
                        VassalFactionId = v.GetString("vassalFactionId", string.Empty),
                        OverlordFactionId = v.GetString("overlordFactionId", string.Empty)
                    });
                }
            }

            if (strategic.TryGetProperty("retreatingArmies", out var retreating) &&
                retreating.Kind == JsonValueKind.Array)
            {
                foreach (var r in retreating.Array)
                {
                    var retreat = new RetreatingArmySnapshotDto
                    {
                        RetreatingArmyId = r.GetString("retreatingArmyId", string.Empty),
                        SourceArmyId = r.GetString("sourceArmyId", string.Empty),
                        FactionId = r.GetString("factionId", string.Empty),
                        HexQ = (int)r.GetNumber("hexQ"),
                        HexR = (int)r.GetNumber("hexR")
                    };
                    if (r.TryGetProperty("memberCharacterIds", out var members) && members.Kind == JsonValueKind.Array)
                    {
                        foreach (var member in members.Array)
                            retreat.MemberCharacterIds.Add(ReadUValue(member));
                    }

                    dto.RetreatingArmies.Add(retreat);
                }
            }

            if (strategic.TryGetProperty("controlCores", out var controlCores))
            {
                if (controlCores.Kind != JsonValueKind.Array)
                    throw new System.FormatException("strategic.controlCores must be an array.");
                dto.HasControlCoreSnapshotAuthority = true;
                foreach (var coreNode in controlCores.Array)
                {
                    if (coreNode.Kind != JsonValueKind.Object ||
                        !coreNode.TryGetProperty("workAreaId", out var workAreaId) || workAreaId.Kind != JsonValueKind.String ||
                        !coreNode.TryGetProperty("currentDurability", out var durability) || durability.Kind != JsonValueKind.Number ||
                        !coreNode.TryGetProperty("occupyProgressSeconds", out var occupyProgress) || occupyProgress.Kind != JsonValueKind.Number)
                        throw new System.FormatException("Invalid controlCores entry.");
                    dto.ControlCores.Add(new ControlCoreRuntimeSnapshotDto
                    {
                        WorkAreaId = workAreaId.String,
                        CurrentDurability = (int)durability.Number,
                        OccupyProgressSeconds = (float)occupyProgress.Number
                    });
                }
            }

            if (strategic.TryGetProperty("worldSitePublicStocks", out var stocks))
            {
                if (stocks.Kind != JsonValueKind.Array)
                    throw new System.FormatException("strategic.worldSitePublicStocks must be an array.");
                dto.HasWorldSitePublicStockSnapshotAuthority = true;
                foreach (var stockNode in stocks.Array)
                {
                    if (stockNode.Kind != JsonValueKind.Object ||
                        !stockNode.TryGetProperty("siteId", out var siteId) || siteId.Kind != JsonValueKind.String ||
                        !stockNode.TryGetProperty("entries", out var entries) || entries.Kind != JsonValueKind.Array)
                        throw new System.FormatException("Invalid worldSitePublicStocks entry.");
                    var stock = new WorldSitePublicStockSnapshotDto { SiteId = siteId.String };
                    foreach (var entryNode in entries.Array)
                    {
                        if (entryNode.Kind != JsonValueKind.Object ||
                            !entryNode.TryGetProperty("resourceId", out var resourceId) || resourceId.Kind != JsonValueKind.String ||
                            !entryNode.TryGetProperty("amount", out var amount) || amount.Kind != JsonValueKind.Number ||
                            amount.Number != System.Math.Truncate(amount.Number))
                            throw new System.FormatException("Invalid WorldSite public stock resource entry.");
                        stock.Entries.Add(new WorldSitePublicStockEntrySnapshotDto
                        { ResourceId = resourceId.String, Amount = (int)amount.Number });
                    }
                    dto.WorldSitePublicStocks.Add(stock);
                }
            }

            if (strategic.TryGetProperty("captureObjectives", out var captureObjectives) &&
                captureObjectives.Kind == JsonValueKind.Array)
            {
                foreach (var objNode in captureObjectives.Array)
                {
                    dto.LegacyCaptureObjectives.Add(new LegacyCaptureObjectiveSnapshotDto
                    {
                        ObjectiveId = objNode.GetString("objectiveId", string.Empty),
                        SiteId = objNode.GetString("siteId", string.Empty),
                        WorkAreaId = objNode.GetString("workAreaId", string.Empty),
                        CurrentHp = (int)objNode.GetNumber("currentHp"),
                        MaxHp = (int)objNode.GetNumber("maxHp"),
                        OccupyProgressSeconds = objNode.TryGetProperty("occupyProgressSeconds", out var occupyProgress)
                            ? (float)occupyProgress.Number : 0f,
                        OccupyHoldSeconds = objNode.TryGetProperty("occupyHoldSeconds", out var occupyHold)
                            ? (float)occupyHold.Number : 0f,
                        Completed = objNode.TryGetProperty("completed", out var completed) &&
                                    completed.Kind == JsonValueKind.Boolean && completed.Bool
                    });
                }
            }

            if (strategic.TryGetProperty("backgroundCharacterTravels", out var backgroundTravels) &&
                backgroundTravels.Kind == JsonValueKind.Array)
            {
                foreach (var node in backgroundTravels.Array)
                {
                    if (node.Kind != JsonValueKind.Object) continue;
                    var travel = new BackgroundCharacterTravelSnapshotDto
                    {
                        CharacterId = ReadU(node, "characterId"),
                        LocationKind = (int)node.GetNumber("locationKind"),
                        SiteId = node.GetString("siteId", string.Empty),
                        WorldX = (float)node.GetNumber("worldX"),
                        WorldY = (float)node.GetNumber("worldY"),
                        CurrentHexQ = (int)node.GetNumber("currentHexQ"),
                        CurrentHexR = (int)node.GetNumber("currentHexR"),
                        IsTraveling = node.GetBool("isTraveling"),
                        DestinationHexQ = (int)node.GetNumber("destinationHexQ"),
                        DestinationHexR = (int)node.GetNumber("destinationHexR"),
                        DestinationSiteId = node.GetString("destinationSiteId", string.Empty),
                        SegmentIndex = (int)node.GetNumber("segmentIndex"),
                        SegmentProgress = (float)node.GetNumber("segmentProgress"),
                        LastProcessedWorldTick = ReadU(node, "lastProcessedWorldTick"),
                        IsSurfaceRoute = node.GetBool("isSurfaceRoute"),
                        SurfaceId = node.GetString("surfaceId", string.Empty),
                        SurfaceDestinationX = (float)node.GetNumber("surfaceDestinationX"),
                        SurfaceDestinationY = (float)node.GetNumber("surfaceDestinationY")
                    };
                    if (node.TryGetProperty("hexPath", out var path))
                        travel.HexPath = ReadHexPath(path);
                    dto.BackgroundCharacterTravels.Add(travel);
                }
            }

            if (strategic.TryGetProperty("playerPartyTravel", out var partyTravel) &&
                partyTravel.Kind == JsonValueKind.Object)
            {
                dto.PlayerPartyTravel = new PlayerPartyTravelSnapshotDto
                {
                    HasPosition = partyTravel.TryGetProperty("hasPosition", out var hasPos) &&
                                    hasPos.Kind == JsonValueKind.Boolean && hasPos.Bool,
                    LocationKind = partyTravel.TryGetProperty("locationKind", out var lk) ? (int)lk.Number : 0,
                    SiteId = partyTravel.GetString("siteId", string.Empty),
                    WorldX = partyTravel.TryGetProperty("worldX", out var wx) ? (float)wx.Number : 0f,
                    WorldY = partyTravel.TryGetProperty("worldY", out var wy) ? (float)wy.Number : 0f,
                    CurrentHexQ = partyTravel.TryGetProperty("currentHexQ", out var cq) ? (int)cq.Number : 0,
                    CurrentHexR = partyTravel.TryGetProperty("currentHexR", out var cr) ? (int)cr.Number : 0,
                    IsMoving = partyTravel.TryGetProperty("isMoving", out var moving) && moving.Kind == JsonValueKind.Boolean && moving.Bool,
                    HasContinuousPhysicalDestination = partyTravel.TryGetProperty("hasContinuousPhysicalDestination", out var hasDestination) && hasDestination.Kind == JsonValueKind.Boolean && hasDestination.Bool,
                    DestinationWorldX = partyTravel.TryGetProperty("destinationWorldX", out var dwx) ? (float)dwx.Number : 0f,
                    DestinationWorldY = partyTravel.TryGetProperty("destinationWorldY", out var dwy) ? (float)dwy.Number : 0f,
                    ArrivalRadius = partyTravel.TryGetProperty("arrivalRadius", out var radius) ? (float)radius.Number : 0f,
                    DestinationSiteId = partyTravel.GetString("destinationSiteId", string.Empty),
                    ExecutionMode = partyTravel.TryGetProperty("executionMode", out var execution) ? (int)execution.Number : 0
                };
            }

            if (strategic.TryGetProperty("playerParty", out var playerParty) &&
                playerParty.Kind == JsonValueKind.Object)
            {
                dto.PlayerParty = new PlayerPartyRuntimeSnapshotDto
                {
                    ActiveCharacterId = ReadU(playerParty, "activeCharacterId")
                };
                if (playerParty.TryGetProperty("memberCharacterIds", out var members) &&
                    members.Kind == JsonValueKind.Array)
                {
                    foreach (var m in members.Array)
                        dto.PlayerParty.MemberCharacterIds.Add(ReadUValue(m));
                }
            }

            if (strategic.TryGetProperty("loadedLocalMapCharacterPlacements", out var placements) &&
                placements.Kind == JsonValueKind.Array)
            {
                foreach (var node in placements.Array)
                {
                    if (node.Kind != JsonValueKind.Object)
                        continue;
                    dto.LoadedLocalMapCharacterPlacements.Add(new LoadedLocalMapCharacterPlacementSnapshotDto
                    {
                        CharacterId = ReadU(node, "characterId"),
                        LocalMapId = node.GetString("localMapId", string.Empty),
                        LocalX = node.TryGetProperty("localX", out var lx) ? (float)lx.Number : 0f,
                        LocalZ = node.TryGetProperty("localZ", out var lz) ? (float)lz.Number : 0f
                    });
                }
            }

            if (strategic.TryGetProperty("pendingEngagement", out var pendingNode) &&
                pendingNode.Kind == JsonValueKind.Object)
            {
                dto.PendingEngagement = ReadPendingEngagement(pendingNode);
            }

            FactionFlagSnapshotRestore.LogDtos("FlagSnapshotParsed", dto.FactionFlags);
            return dto;
        }

        static JsonValue SerializePendingEngagement(PendingEngagementSnapshotDto p)
        {
            if (p == null)
                return JsonValue.Null;

            var battleArea = SerializeHexCoordPairs(p.BattleAreaHexQList, p.BattleAreaHexRList);
            var supportArea = SerializeHexCoordPairs(p.SupportAreaHexQList, p.SupportAreaHexRList);

            var lockedPlayer = new List<JsonValue>();
            if (p.PlayerFormalArmyIds != null)
            {
                for (var i = 0; i < p.PlayerFormalArmyIds.Count; i++)
                    lockedPlayer.Add(JsonValue.FromString(p.PlayerFormalArmyIds[i] ?? string.Empty));
            }

            var lockedEnemy = new List<JsonValue>();
            if (p.EnemyFormalArmyIds != null)
            {
                for (var i = 0; i < p.EnemyFormalArmyIds.Count; i++)
                    lockedEnemy.Add(JsonValue.FromString(p.EnemyFormalArmyIds[i] ?? string.Empty));
            }

            var lockedParty = new List<JsonValue>();
            if (p.PlayerPartyMemberIds != null)
            {
                for (var i = 0; i < p.PlayerPartyMemberIds.Count; i++)
                    lockedParty.Add(U(p.PlayerPartyMemberIds[i]));
            }

            var offer = new Dictionary<string, JsonValue>
            {
                ["offerId"] = JsonValue.FromString(p.OfferId ?? string.Empty),
                ["title"] = JsonValue.FromString(p.OfferTitle ?? string.Empty),
                ["armyStackId"] = JsonValue.FromString(p.ArmyStackId ?? string.Empty),
                ["encounterLocalMapId"] = JsonValue.FromString(p.EncounterLocalMapId ?? string.Empty),
                ["origin"] = JsonValue.FromNumber(p.OfferOrigin),
                ["requiresWarDeclaration"] = JsonValue.FromBool(p.OfferRequiresWarDeclaration),
                ["pendingWarAttackerFactionId"] = JsonValue.FromString(p.PendingWarAttackerFactionId ?? string.Empty),
                ["pendingWarDefenderFactionId"] = JsonValue.FromString(p.PendingWarDefenderFactionId ?? string.Empty)
            };

            var retreat = new Dictionary<string, JsonValue>
            {
                ["hasValue"] = JsonValue.FromBool(p.RetreatHasValue),
                ["armyLocationKind"] = JsonValue.FromNumber(p.RetreatArmyLocationKind),
                ["partyLocationKind"] = JsonValue.FromNumber(p.RetreatPartyLocationKind),
                ["siteId"] = JsonValue.FromString(p.RetreatSiteId ?? string.Empty),
                ["worldX"] = JsonValue.FromNumber(p.RetreatWorldX),
                ["worldY"] = JsonValue.FromNumber(p.RetreatWorldY),
                ["hexQ"] = JsonValue.FromNumber(p.RetreatHexQ),
                ["hexR"] = JsonValue.FromNumber(p.RetreatHexR),
                ["isPlayerParty"] = JsonValue.FromBool(p.RetreatIsPlayerParty)
            };

            var records = new List<JsonValue>();
            if (p.ParticipantRecords != null)
            {
                for (var i = 0; i < p.ParticipantRecords.Count; i++)
                {
                    var r = p.ParticipantRecords[i];
                    if (r == null)
                        continue;
                    records.Add(JsonValue.FromObject(new Dictionary<string, JsonValue>
                    {
                        ["kind"] = JsonValue.FromNumber(r.Kind),
                        ["entityId"] = U(r.EntityId),
                        ["squadId"] = JsonValue.FromString(r.SquadId ?? string.Empty),
                        ["armyStackId"] = JsonValue.FromString(r.ArmyStackId ?? string.Empty),
                        ["formalArmyId"] = JsonValue.FromString(r.FormalArmyId ?? string.Empty),
                        ["displayLabel"] = JsonValue.FromString(r.DisplayLabel ?? string.Empty),
                        ["combatPower"] = JsonValue.FromNumber(r.CombatPower),
                        ["selected"] = JsonValue.FromBool(r.Selected),
                        ["includedReason"] = JsonValue.FromString(r.IncludedReason ?? string.Empty),
                        ["hasPreBattle"] = JsonValue.FromBool(r.HasPreBattle),
                        ["preBattleMode"] = JsonValue.FromNumber(r.PreBattleMode),
                        ["preBattleSiteId"] = JsonValue.FromString(r.PreBattleSiteId ?? string.Empty),
                        ["preBattleHexQ"] = JsonValue.FromNumber(r.PreBattleHexQ),
                        ["preBattleHexR"] = JsonValue.FromNumber(r.PreBattleHexR),
                        ["preBattleFollowStackId"] = JsonValue.FromString(r.PreBattleFollowStackId ?? string.Empty),
                        ["preBattleCombatPursuitStackId"] = JsonValue.FromString(r.PreBattleCombatPursuitStackId ?? string.Empty),
                        ["preBattleHasWorldPosition"] = JsonValue.FromBool(r.PreBattleHasWorldPosition),
                        ["preBattleWorldX"] = JsonValue.FromNumber(r.PreBattleWorldX),
                        ["preBattleWorldY"] = JsonValue.FromNumber(r.PreBattleWorldY),
                        ["preBattleSurfaceId"] = JsonValue.FromString(r.PreBattleSurfaceId ?? string.Empty)
                    }));
                }
            }

            var participantSnapshot = new Dictionary<string, JsonValue>
            {
                ["offerId"] = JsonValue.FromString(p.ParticipantOfferId ?? string.Empty),
                ["attackerArmyId"] = JsonValue.FromString(p.ParticipantAttackerArmyId ?? string.Empty),
                ["defenderArmyId"] = JsonValue.FromString(p.ParticipantDefenderArmyId ?? string.Empty),
                ["primaryEnemyStackId"] = JsonValue.FromString(p.ParticipantPrimaryEnemyStackId ?? string.Empty),
                ["battleAnchorHexQ"] = JsonValue.FromNumber(p.ParticipantBattleAnchorHexQ),
                ["battleAnchorHexR"] = JsonValue.FromNumber(p.ParticipantBattleAnchorHexR),
                ["hasBattleAnchorWorldPosition"] = JsonValue.FromBool(p.ParticipantHasBattleAnchorWorldPosition),
                ["battleAnchorWorldX"] = JsonValue.FromNumber(p.ParticipantBattleAnchorWorldX),
                ["battleAnchorWorldY"] = JsonValue.FromNumber(p.ParticipantBattleAnchorWorldY),
                ["battleAnchorSurfaceId"] = JsonValue.FromString(p.ParticipantBattleAnchorSurfaceId ?? string.Empty),
                ["encounterLocalMapId"] = JsonValue.FromString(p.ParticipantEncounterLocalMapId ?? string.Empty),
                ["localMapResolutionKind"] = JsonValue.FromNumber(p.ParticipantLocalMapResolutionKind),
                ["hasLocalMapResolutionKind"] = JsonValue.FromBool(p.HasParticipantLocalMapResolutionKind),
                ["records"] = JsonValue.FromArray(records)
            };

            return JsonValue.FromObject(new Dictionary<string, JsonValue>
            {
                ["engagementId"] = JsonValue.FromString(p.EngagementId ?? string.Empty),
                ["initiatorKind"] = JsonValue.FromNumber(p.InitiatorKind),
                ["initiatorFormalArmyId"] = JsonValue.FromString(p.InitiatorFormalArmyId ?? string.Empty),
                ["initiatorIsPlayerSide"] = JsonValue.FromBool(p.InitiatorIsPlayerSide),
                ["decisionSubjectKind"] = JsonValue.FromNumber(p.DecisionSubjectKind),
                ["decisionSubjectFormalArmyId"] = JsonValue.FromString(p.DecisionSubjectFormalArmyId ?? string.Empty),
                ["battleLocationHexQ"] = JsonValue.FromNumber(p.BattleLocationHexQ),
                ["battleLocationHexR"] = JsonValue.FromNumber(p.BattleLocationHexR),
                ["battleAreaHexes"] = JsonValue.FromArray(battleArea),
                ["supportAreaHexes"] = JsonValue.FromArray(supportArea),
                ["supportBattleSiteId"] = JsonValue.FromString(p.SupportBattleSiteId ?? string.Empty),
                ["supportBattleSiteResolutionSource"] = JsonValue.FromString(p.SupportBattleSiteResolutionSource ?? string.Empty),
                ["initiatorEngagementHexQ"] = JsonValue.FromNumber(p.InitiatorEngagementHexQ),
                ["initiatorEngagementHexR"] = JsonValue.FromNumber(p.InitiatorEngagementHexR),
                ["initiatorEngagementSiteId"] = JsonValue.FromString(p.InitiatorEngagementSiteId ?? string.Empty),
                ["primaryEnemyFactionId"] = JsonValue.FromString(p.PrimaryEnemyFactionId ?? string.Empty),
                ["attackerFormalArmyId"] = JsonValue.FromString(p.AttackerFormalArmyId ?? string.Empty),
                ["defenderFormalArmyId"] = JsonValue.FromString(p.DefenderFormalArmyId ?? string.Empty),
                ["playerPartyIncluded"] = JsonValue.FromBool(p.PlayerPartyIncluded),
                ["playerInclusionReason"] = JsonValue.FromString(p.PlayerInclusionReason ?? string.Empty),
                ["involvesPlayerSide"] = JsonValue.FromBool(p.InvolvesPlayerSide),
                ["requiresPlayerDecision"] = JsonValue.FromBool(p.RequiresPlayerDecision),
                ["pendingBattleTriggerReason"] = JsonValue.FromString(p.PendingBattleTriggerReason ?? string.Empty),
                ["initiatorCommittedHexQ"] = JsonValue.FromNumber(p.InitiatorCommittedHexQ),
                ["initiatorCommittedHexR"] = JsonValue.FromNumber(p.InitiatorCommittedHexR),
                ["defenderCommittedHexQ"] = JsonValue.FromNumber(p.DefenderCommittedHexQ),
                ["defenderCommittedHexR"] = JsonValue.FromNumber(p.DefenderCommittedHexR),
                ["offer"] = JsonValue.FromObject(offer),
                ["lockedPlayerFormalArmyIds"] = JsonValue.FromArray(lockedPlayer),
                ["lockedEnemyFormalArmyIds"] = JsonValue.FromArray(lockedEnemy),
                ["lockedPlayerPartyMemberIds"] = JsonValue.FromArray(lockedParty),
                ["retreat"] = JsonValue.FromObject(retreat),
                ["participantSnapshot"] = JsonValue.FromObject(participantSnapshot)
            });
        }

        static List<JsonValue> SerializeHexCoordPairs(List<int> qList, List<int> rList)
        {
            var list = new List<JsonValue>();
            if (qList == null || rList == null)
                return list;
            var count = System.Math.Min(qList.Count, rList.Count);
            for (var i = 0; i < count; i++)
            {
                list.Add(JsonValue.FromObject(new Dictionary<string, JsonValue>
                {
                    ["q"] = JsonValue.FromNumber(qList[i]),
                    ["r"] = JsonValue.FromNumber(rList[i])
                }));
            }

            return list;
        }

        static void ReadHexCoordPairsInto(JsonValue node, List<int> qList, List<int> rList)
        {
            qList.Clear();
            rList.Clear();
            if (node == null || node.Kind != JsonValueKind.Array)
                return;
            foreach (var h in node.Array)
            {
                if (h.Kind != JsonValueKind.Object)
                    continue;
                qList.Add((int)h.GetNumber("q"));
                rList.Add((int)h.GetNumber("r"));
            }
        }

        static void ReadStringArrayInto(JsonValue node, List<string> into)
        {
            into.Clear();
            if (node == null || node.Kind != JsonValueKind.Array)
                return;
            foreach (var v in node.Array)
            {
                if (v.Kind == JsonValueKind.String)
                    into.Add(v.String);
            }
        }

        static PendingEngagementSnapshotDto ReadPendingEngagement(JsonValue node)
        {
            var p = new PendingEngagementSnapshotDto
            {
                EngagementId = node.GetString("engagementId", string.Empty),
                InitiatorKind = (int)node.GetNumber("initiatorKind"),
                InitiatorFormalArmyId = node.GetString("initiatorFormalArmyId", string.Empty),
                InitiatorIsPlayerSide = node.GetBool("initiatorIsPlayerSide"),
                DecisionSubjectKind = (int)node.GetNumber("decisionSubjectKind"),
                DecisionSubjectFormalArmyId = node.GetString("decisionSubjectFormalArmyId", string.Empty),
                BattleLocationHexQ = (int)node.GetNumber("battleLocationHexQ"),
                BattleLocationHexR = (int)node.GetNumber("battleLocationHexR"),
                SupportBattleSiteId = node.GetString("supportBattleSiteId", string.Empty),
                SupportBattleSiteResolutionSource = node.GetString("supportBattleSiteResolutionSource", string.Empty),
                InitiatorEngagementHexQ = (int)node.GetNumber("initiatorEngagementHexQ"),
                InitiatorEngagementHexR = (int)node.GetNumber("initiatorEngagementHexR"),
                InitiatorEngagementSiteId = node.GetString("initiatorEngagementSiteId", string.Empty),
                PrimaryEnemyFactionId = node.GetString("primaryEnemyFactionId", string.Empty),
                AttackerFormalArmyId = node.GetString("attackerFormalArmyId", string.Empty),
                DefenderFormalArmyId = node.GetString("defenderFormalArmyId", string.Empty),
                PlayerPartyIncluded = node.GetBool("playerPartyIncluded"),
                PlayerInclusionReason = node.GetString("playerInclusionReason", string.Empty),
                InvolvesPlayerSide = node.GetBool("involvesPlayerSide"),
                PendingBattleTriggerReason = node.GetString("pendingBattleTriggerReason", string.Empty),
                InitiatorCommittedHexQ = (int)node.GetNumber("initiatorCommittedHexQ", int.MinValue),
                InitiatorCommittedHexR = (int)node.GetNumber("initiatorCommittedHexR", int.MinValue),
                DefenderCommittedHexQ = (int)node.GetNumber("defenderCommittedHexQ", int.MinValue),
                DefenderCommittedHexR = (int)node.GetNumber("defenderCommittedHexR", int.MinValue)
            };
            // 旧 snapshot 缺 requiresPlayerDecision 时回退 involvesPlayerSide（等价历史推导，Restore 不再重推）。
            p.RequiresPlayerDecision = node.TryGetProperty("requiresPlayerDecision", out var rpd) &&
                                       rpd.Kind == JsonValueKind.Boolean
                ? rpd.Bool
                : p.InvolvesPlayerSide;

            if (node.TryGetProperty("battleAreaHexes", out var battleAreaNode))
                ReadHexCoordPairsInto(battleAreaNode, p.BattleAreaHexQList, p.BattleAreaHexRList);
            if (node.TryGetProperty("supportAreaHexes", out var supportAreaNode))
                ReadHexCoordPairsInto(supportAreaNode, p.SupportAreaHexQList, p.SupportAreaHexRList);

            if (node.TryGetProperty("lockedPlayerFormalArmyIds", out var lockedPlayerNode))
                ReadStringArrayInto(lockedPlayerNode, p.PlayerFormalArmyIds);
            if (node.TryGetProperty("lockedEnemyFormalArmyIds", out var lockedEnemyNode))
                ReadStringArrayInto(lockedEnemyNode, p.EnemyFormalArmyIds);
            if (node.TryGetProperty("lockedPlayerPartyMemberIds", out var lockedPartyNode) &&
                lockedPartyNode.Kind == JsonValueKind.Array)
            {
                p.PlayerPartyMemberIds.Clear();
                foreach (var m in lockedPartyNode.Array)
                    p.PlayerPartyMemberIds.Add(ReadUValue(m));
            }

            if (node.TryGetProperty("offer", out var offerNode) && offerNode.Kind == JsonValueKind.Object)
            {
                p.OfferId = offerNode.GetString("offerId", string.Empty);
                p.OfferTitle = offerNode.GetString("title", string.Empty);
                p.ArmyStackId = offerNode.GetString("armyStackId", string.Empty);
                p.EncounterLocalMapId = offerNode.GetString("encounterLocalMapId", string.Empty);
                p.OfferOrigin = (int)offerNode.GetNumber("origin");
                p.OfferRequiresWarDeclaration = offerNode.GetBool("requiresWarDeclaration");
                p.PendingWarAttackerFactionId = offerNode.GetString("pendingWarAttackerFactionId", string.Empty);
                p.PendingWarDefenderFactionId = offerNode.GetString("pendingWarDefenderFactionId", string.Empty);
            }

            if (node.TryGetProperty("retreat", out var retreatNode) && retreatNode.Kind == JsonValueKind.Object)
            {
                p.RetreatHasValue = retreatNode.GetBool("hasValue");
                p.RetreatArmyLocationKind = (int)retreatNode.GetNumber("armyLocationKind");
                p.RetreatPartyLocationKind = (int)retreatNode.GetNumber("partyLocationKind");
                p.RetreatSiteId = retreatNode.GetString("siteId", string.Empty);
                p.RetreatWorldX = (float)retreatNode.GetNumber("worldX");
                p.RetreatWorldY = (float)retreatNode.GetNumber("worldY");
                p.RetreatHexQ = (int)retreatNode.GetNumber("hexQ");
                p.RetreatHexR = (int)retreatNode.GetNumber("hexR");
                p.RetreatIsPlayerParty = retreatNode.GetBool("isPlayerParty");
            }

            if (node.TryGetProperty("participantSnapshot", out var snapNode) &&
                snapNode.Kind == JsonValueKind.Object)
            {
                p.ParticipantOfferId = snapNode.GetString("offerId", string.Empty);
                p.ParticipantAttackerArmyId = snapNode.GetString("attackerArmyId", string.Empty);
                p.ParticipantDefenderArmyId = snapNode.GetString("defenderArmyId", string.Empty);
                p.ParticipantPrimaryEnemyStackId = snapNode.GetString("primaryEnemyStackId", string.Empty);
                p.ParticipantBattleAnchorHexQ = (int)snapNode.GetNumber("battleAnchorHexQ");
                p.ParticipantBattleAnchorHexR = (int)snapNode.GetNumber("battleAnchorHexR");
                p.ParticipantHasBattleAnchorWorldPosition = snapNode.GetBool("hasBattleAnchorWorldPosition");
                p.ParticipantBattleAnchorWorldX = (float)snapNode.GetNumber("battleAnchorWorldX");
                p.ParticipantBattleAnchorWorldY = (float)snapNode.GetNumber("battleAnchorWorldY");
                p.ParticipantBattleAnchorSurfaceId = snapNode.GetString("battleAnchorSurfaceId", string.Empty);
                p.ParticipantEncounterLocalMapId = snapNode.GetString("encounterLocalMapId", string.Empty);
                p.ParticipantLocalMapResolutionKind = (int)snapNode.GetNumber("localMapResolutionKind");
                p.HasParticipantLocalMapResolutionKind =
                    snapNode.GetBool("hasLocalMapResolutionKind");
                if (snapNode.TryGetProperty("records", out var recordsNode) &&
                    recordsNode.Kind == JsonValueKind.Array)
                {
                    p.ParticipantRecords.Clear();
                    foreach (var r in recordsNode.Array)
                    {
                        if (r.Kind != JsonValueKind.Object)
                            continue;
                        var rec = new PendingEngagementParticipantRecordDto
                        {
                            Kind = (int)r.GetNumber("kind"),
                            EntityId = ReadU(r, "entityId"),
                            SquadId = r.GetString("squadId", string.Empty),
                            ArmyStackId = r.GetString("armyStackId", string.Empty),
                            FormalArmyId = r.GetString("formalArmyId", string.Empty),
                            DisplayLabel = r.GetString("displayLabel", string.Empty),
                            CombatPower = (int)r.GetNumber("combatPower"),
                            Selected = r.GetBool("selected"),
                            IncludedReason = r.GetString("includedReason", string.Empty),
                            HasPreBattle = r.GetBool("hasPreBattle"),
                            PreBattleMode = (int)r.GetNumber("preBattleMode"),
                            PreBattleSiteId = r.GetString("preBattleSiteId", string.Empty),
                            PreBattleHexQ = (int)r.GetNumber("preBattleHexQ", int.MinValue),
                            PreBattleHexR = (int)r.GetNumber("preBattleHexR", int.MinValue),
                            PreBattleFollowStackId = r.GetString("preBattleFollowStackId", string.Empty),
                            PreBattleCombatPursuitStackId = r.GetString("preBattleCombatPursuitStackId", string.Empty),
                            PreBattleHasWorldPosition = r.GetBool("preBattleHasWorldPosition"),
                            PreBattleWorldX = (float)r.GetNumber("preBattleWorldX"),
                            PreBattleWorldY = (float)r.GetNumber("preBattleWorldY"),
                            PreBattleSurfaceId = r.GetString("preBattleSurfaceId", string.Empty)
                        };
                        p.ParticipantRecords.Add(rec);
                    }
                }
            }

            return p;
        }
    }
}

