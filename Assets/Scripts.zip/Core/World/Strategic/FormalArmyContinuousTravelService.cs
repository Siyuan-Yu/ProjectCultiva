using System;
using System.Collections.Generic;
using XianXia.Core.Results;
using XianXia.Core.Simulation;
using XianXia.Core.World;
using XianXia.Core.World.Hex;
using XianXia.Core.World.Surface;

namespace XianXia.Core.World.Strategic
{
    /// <summary>
    /// Phase 3：FormalArmy 连续世界旅行（组织级一次路径；成员 Presence 派生）。
    /// </summary>
    public static class FormalArmyContinuousTravelService
    {
        static readonly List<HexCoord> PathScratch = new List<HexCoord>(64);
        static readonly List<HexCoord> FullPathScratch = new List<HexCoord>(64);
        static readonly List<string> AdvanceArmyScratch = new List<string>(32);
        static readonly List<WorldVec2> SurfacePathScratch = new List<WorldVec2>(256);

        public static Result MoveArmyToHex(SimulationWorld world, string armyId, HexCoord destination) =>
            BeginTravel(world, armyId, destination, string.Empty, FormalArmyOrderKind.TravelToHex);

        public static Result MoveArmyToWorldSite(SimulationWorld world, string armyId, string siteId)
        {
            if (world == null || string.IsNullOrWhiteSpace(armyId) || string.IsNullOrEmpty(siteId))
                return Result.Failure(ErrorCode.InvalidArgument, "Invalid army site travel.");
            if (!world.Strategic.Sites.TryGet(siteId, out _))
                return Result.Failure(ErrorCode.NotFound, "Site not found.", siteId);
            return BeginTravel(world, armyId, default, siteId, FormalArmyOrderKind.TravelToWorldSite);
        }

        public static Result MoveArmyToWorldPosition(
            SimulationWorld world, string armyId, WorldVec2 destination)
        {
            if (world == null || string.IsNullOrWhiteSpace(armyId) ||
                !world.Strategic.FormalArmies.TryGet(armyId, out var army) || army == null)
                return Result.Failure(ErrorCode.InvalidArgument, "Invalid Surface army travel.");
            if (army.State == FormalArmyState.Garrisoned)
                return Result.Failure(ErrorCode.InvalidOperation, "Army is garrisoned.");
            if (!FormalArmyWorldLocationQuery.TryResolve(
                    world, army, out _, out _, out var start, out _))
                return Result.Failure(ErrorCode.InvalidOperation, "Army has no world location.");
            if (!world.SurfaceGround.TryResolveShared(start, destination, out var navigation))
                return Result.Failure(ErrorCode.InvalidOperation, "No shared Surface for army route.");
            SurfacePathScratch.Clear();
            var status = navigation.TryFindRoute(start, destination, SurfacePathScratch);
            if (status != SurfaceGroundRouteStatus.Found)
                return Result.Failure(ErrorCode.InvalidOperation,
                    "Surface army route unavailable: " + status + ".");
            var wasMoving = army.State == FormalArmyState.Moving || army.WorldMotion.IsMoving;
            var derived = HexMath.WorldToHex(destination.X, destination.Y, 1f);
            army.WorldMotion.BeginSurfaceTravel(
                FormalArmyOrderKind.TravelToWorldPosition, SurfacePathScratch, destination, derived,
                string.Empty, navigation.SurfaceId, navigation.SourceRevision, navigation.SourceHash);
            army.WorldMotion.ClearOrderTarget();
            army.WorldMotion.LastProcessedWorldTick = world.Tick.Value;
            army.State = FormalArmyState.Moving;
            army.SyncLegacyFromWorldMotion();
            FormalArmyMemberPresenceSync.SyncAll(world, army);
            if (wasMoving && world.Strategic.Squads.TryGet(army.SquadId, out var command))
                command.SetCommand(SquadCommandKind.FormalArmyWorldMotion);
            return Result.Success();
        }

        public static void InitializeAtWorldSite(SimulationWorld world, FormalArmy army, string siteId)
        {
            if (world == null || army == null || string.IsNullOrEmpty(siteId))
                return;
            if (!world.Strategic.Sites.TryGet(siteId, out var site) || site == null)
                return;

            site.EnsurePresenceHexValid();
            var hexSize = world.HexWorld != null && world.HexWorld.HexSize > 0f ? world.HexWorld.HexSize : 1f;
            if (ContinuousOutdoorGameplayPolicy.IsNormalContinuousOutdoor(world) &&
                world.SurfaceGround.TryResolveSiteArrival(siteId, out var surfaceId, out var arrival))
            {
                army.UsesHexStrategicPosition = false;
                army.WorldMotion.SetAtWorldSitePreservingWorldPosition(siteId, arrival,
                    world.HexWorld?.HasGrid == true
                        ? HexMath.WorldToHex(arrival.X, arrival.Y, hexSize) : default,
                    surfaceId);
            }
            else
            {
                army.UsesHexStrategicPosition = true;
                army.WorldMotion.SetAtWorldSite(siteId, site.AnchorHex, hexSize);
            }
            army.SyncLegacyFromWorldMotion();
            army.State = FormalArmyState.Idle;
            FormalArmyMemberPresenceSync.SyncAll(world, army);
        }

        public static void InitializeAtWorldPosition(
            SimulationWorld world,
            FormalArmy army,
            WorldVec2 worldPosition,
            HexCoord derivedHex,
            string surfaceId = null,
            bool groupRelocation = false)
        {
            if (world == null || army == null)
                return;

            army.UsesHexStrategicPosition = string.IsNullOrEmpty(surfaceId);
            army.WorldMotion.SetAtWorldPosition(worldPosition, derivedHex, surfaceId);
            army.SyncLegacyFromWorldMotion();
            army.State = FormalArmyState.Idle;
            if (groupRelocation)
                FormalArmyMemberPresenceSync.SyncAllFromArmyAuthority(world, army,
                    FormalArmyMemberPresenceSync.Reason.GroupRelocation);
            else
                FormalArmyMemberPresenceSync.SyncAll(world, army);
        }

        public static void InitializeAtWorldPosition(SimulationWorld world, FormalArmy army,
            WorldVec2 worldPosition, string surfaceId)
        {
            var hex = world?.HexWorld?.HasGrid == true
                ? HexMath.WorldToHex(worldPosition.X, worldPosition.Y,
                    world.HexWorld.HexSize > 0f ? world.HexWorld.HexSize : 1f)
                : default;
            InitializeAtWorldPosition(world, army, worldPosition, hex, surfaceId,
                groupRelocation: true);
        }

        static Result BeginTravel(
            SimulationWorld world,
            string armyId,
            HexCoord destinationHex,
            string destinationSiteId,
            FormalArmyOrderKind orderKind)
        {
            if (world == null || string.IsNullOrWhiteSpace(armyId))
                return Result.Failure(ErrorCode.InvalidArgument, "Invalid army travel.");
            if (!world.Strategic.FormalArmies.TryGet(armyId, out var army) || army == null)
                return Result.Failure(ErrorCode.NotFound, "Army not found.", armyId);
            if (army.State == FormalArmyState.Garrisoned)
                return Result.Failure(ErrorCode.InvalidOperation, "Army is garrisoned.");

            if (!FormalArmyWorldLocationQuery.TryResolve(
                    world, army, out var startKind, out var startSiteId, out var startWorld, out var startHex))
                return Result.Failure(ErrorCode.InvalidOperation, "Army has no world location.");

            var motion = army.WorldMotion;
            var isReplace = army.State == FormalArmyState.Moving || motion.IsMoving;
            FormalArmyOrderReplaceTrace.Capture replaceTrace = default;
            if (isReplace)
                replaceTrace = FormalArmyOrderReplaceTrace.CaptureBeforeReplace(motion);

            // Normal Site orders resolve their physical arrival first. The Site's legacy
            // AnchorHex/footprint is a derived index, never a route prerequisite.
            var normalOutdoorSite = ContinuousOutdoorGameplayPolicy.IsNormalContinuousOutdoor(world) &&
                                    !string.IsNullOrEmpty(destinationSiteId) &&
                                    world.Strategic.Sites.TryGet(destinationSiteId, out var siteTarget) &&
                                    WorldSiteOutdoorMigrationPolicy.UsesContinuousOutdoorSurface(siteTarget);
            if (normalOutdoorSite &&
                world.SurfaceGround.TryResolveSiteArrival(
                    destinationSiteId, out _, out var continuousArrival))
            {
                if (!world.SurfaceGround.TryResolveShared(
                        startWorld, continuousArrival, out var siteNavigation))
                    return Result.Failure(ErrorCode.InvalidOperation,
                        "No shared Continuous Surface for army Site travel.");
                SurfacePathScratch.Clear();
                var siteStatus = siteNavigation.TryFindRoute(
                    startWorld, continuousArrival, SurfacePathScratch);
                if (siteStatus != SurfaceGroundRouteStatus.Found)
                    return Result.Failure(ErrorCode.InvalidOperation,
                        "Surface army Site route unavailable: " + siteStatus + ".");
                var hexSizeForIndex = world.HexWorld?.HexSize > 0f ? world.HexWorld.HexSize : 1f;
                var derivedGoal = HexMath.WorldToHex(
                    continuousArrival.X, continuousArrival.Y, hexSizeForIndex);
                motion.BeginSurfaceTravel(orderKind, SurfacePathScratch, continuousArrival,
                    derivedGoal, destinationSiteId, siteNavigation.SurfaceId,
                    siteNavigation.SourceRevision, siteNavigation.SourceHash);
                motion.ClearOrderTarget();
                motion.LastProcessedWorldTick = world.Tick.Value;
                army.State = FormalArmyState.Moving;
                army.SyncLegacyFromWorldMotion();
                FormalArmyMemberPresenceSync.SyncAll(world, army);
                if (isReplace && world.Strategic.Squads.TryGet(army.SquadId, out var command))
                    command.SetCommand(SquadCommandKind.FormalArmyWorldMotion);
                return Result.Success();
            }
            if (normalOutdoorSite)
                return Result.Failure(ErrorCode.InvalidOperation,
                    "Army Site has no authored Continuous Surface arrival.");

            destinationSiteId = TryCanonicalizeFootprintHexDestination(
                world, destinationHex, destinationSiteId, out _);

            var goalHex = destinationHex;
            if (!string.IsNullOrEmpty(destinationSiteId) &&
                world.Strategic.Sites.TryGet(destinationSiteId, out var targetSite) &&
                targetSite != null)
                goalHex = ResolveDeterministicSiteApproachHex(world, startHex, targetSite);

            var goalWorld = HexCenter(goalHex,
                world.HexWorld.HexSize > 0f ? world.HexWorld.HexSize : 1f);
            if (!string.IsNullOrEmpty(destinationSiteId) &&
                world.SurfaceGround.TryResolveSiteArrival(
                    destinationSiteId, out _, out var authoredArrival))
                goalWorld = authoredArrival;
            if (world.SurfaceGround.TryResolveShared(startWorld, goalWorld, out var surfaceNavigation))
            {
                SurfacePathScratch.Clear();
                var routeStatus = surfaceNavigation.TryFindRoute(startWorld, goalWorld, SurfacePathScratch);
                if (routeStatus != SurfaceGroundRouteStatus.Found)
                    return Result.Failure(ErrorCode.InvalidOperation,
                        "Surface army route unavailable: " + routeStatus + ".",
                        surfaceNavigation.SurfaceId);

                motion.BeginSurfaceTravel(orderKind, SurfacePathScratch, goalWorld, goalHex,
                    destinationSiteId, surfaceNavigation.SurfaceId,
                    surfaceNavigation.SourceRevision, surfaceNavigation.SourceHash);
                if (orderKind == FormalArmyOrderKind.TravelToHex ||
                    orderKind == FormalArmyOrderKind.TravelToWorldSite)
                    motion.ClearOrderTarget();
                motion.LastProcessedWorldTick = world.Tick.Value;
                army.State = FormalArmyState.Moving;
                army.SyncLegacyFromWorldMotion();
                FormalArmyMemberPresenceSync.SyncAll(world, army);
                if (isReplace && world.Strategic.Squads.TryGet(army.SquadId, out var replacedCommand))
                    replacedCommand.SetCommand(SquadCommandKind.FormalArmyWorldMotion);
                return Result.Success();
            }

            if (ContinuousOutdoorGameplayPolicy.IsNormalContinuousOutdoor(world))
                return Result.Failure(ErrorCode.InvalidOperation,
                    "Army destination has no valid Continuous Surface route.");
            if (!world.HexWorld.HasGrid)
                return Result.Failure(ErrorCode.InvalidOperation, "Hex grid not loaded for legacy army travel.");

            var startInKnownSurface = world.SurfaceGround.TryResolveContaining(startWorld, out _);
            var goalInKnownSurface = world.SurfaceGround.TryResolveContaining(goalWorld, out _);
            if (startInKnownSurface || goalInKnownSurface)
                return Result.Failure(ErrorCode.InvalidOperation,
                    "Cross-region surface route is not available; legacy travel was not used.");

            if (!world.HexWorld.TryGetTile(goalHex, out var destTile) ||
                destTile == null ||
                !destTile.IsPassable)
                return Result.Failure(ErrorCode.InvalidArgument, "Destination hex is not passable.");

            if (startKind == FormalArmyLocationKind.AtWorldSite &&
                !string.IsNullOrEmpty(startSiteId) &&
                world.Strategic.Sites.TryGet(startSiteId, out var fromSite) &&
                fromSite != null)
            {
                // Phase 5D: 非目标 Site footprint 不可作为中转（与 PlayerParty 同一 policy）。
                // 出发 Site 自身 footprint 是 departure 段合法路径（内部 → 边界），先移除。
                var blockedSiteHexes = WorldSiteTransitPolicy.BuildBlockedFootprintHexes(
                    world, destinationSiteId);
                foreach (var hex in fromSite.EnumerateFootprintHexes())
                    blockedSiteHexes.Remove(hex);

                if (!TryBuildPathLeavingSite(
                        world,
                        fromSite,
                        startHex,
                        goalHex,
                        blockedSiteHexes,
                        FullPathScratch,
                        out var exitHex,
                        out var departureFootprintHex))
                    return Result.Failure(ErrorCode.InvalidOperation, "No path leaving WorldSite.");

                if (!IsLegacyPathCompatibleWithRegisteredSurfaces(
                        world, startWorld, FullPathScratch))
                    return Result.Failure(ErrorCode.InvalidOperation,
                        "Cross-region terrain route is incomplete; legacy path intersects blocked Surface ground.");

                var hexSizeForDeparture = world.HexWorld.HexSize > 0f ? world.HexWorld.HexSize : 1f;
                if (!BackgroundCharacterSiteDepartureResolver.TryResolveDepartureBoundaryEntryWorldPosition(
                        departureFootprintHex,
                        exitHex,
                        hexSizeForDeparture,
                        out var boundaryEntryPos))
                {
                    boundaryEntryPos = HexCenter(exitHex, hexSizeForDeparture);
                }

                var departureStartWorld = motion.IsSiteDeparturePending &&
                                          motion.LocationKind == FormalArmyLocationKind.AtWorldSite
                    ? motion.SiteDepartureVirtualPosition
                    : HexCenter(startHex, hexSizeForDeparture);
                motion.BeginSiteDepartureTravel(
                    orderKind,
                    FullPathScratch,
                    goalHex,
                    destinationSiteId,
                    departureFootprintHex,
                    exitHex,
                    departureStartWorld,
                    boundaryEntryPos,
                    HexTravelMode.Ground);
                motion.LastProcessedWorldTick = world.Tick.Value;
                army.SyncLegacyFromWorldMotion();
                FormalArmyMemberPresenceSync.SyncAll(world, army);
                if (isReplace)
                {
                    FormalArmyOrderReplaceTrace.Emit(
                        army,
                        replaceTrace,
                        goalHex,
                        destinationSiteId,
                        FullPathScratch);
                }

                return Result.Success();
            }

            // Phase 5D: 与 PlayerParty 同一 WorldSite Transit Policy —— 普通非目标 Site 的
            // footprint 不可作为中转格（避免 Army 把城镇当平原直穿）。
            if (!HexPathfinder.TryFindPath(
                    world.HexWorld,
                    startHex,
                    goalHex,
                    FullPathScratch,
                    HexTravelMode.Ground,
                    WorldSiteTransitPolicy.BuildBlockedFootprintHexes(
                        world, destinationSiteId)) ||
                FullPathScratch.Count < 1)
                return Result.Failure(ErrorCode.InvalidOperation, "No hex path to destination.");

            if (!IsLegacyPathCompatibleWithRegisteredSurfaces(world, startWorld, FullPathScratch))
                return Result.Failure(ErrorCode.InvalidOperation,
                    "Cross-region terrain route is incomplete; legacy path intersects blocked Surface ground.");

            var hexSize = world.HexWorld.HexSize > 0f ? world.HexWorld.HexSize : 1f;
            if (startKind == FormalArmyLocationKind.AtWorldSite &&
                !isReplace &&
                world.Strategic.Sites.TryResolveSitePresenceHex(startSiteId, out var presenceHex))
            {
                var center = HexCenter(presenceHex, hexSize);
                motion.SetAtWorldPosition(center, presenceHex);
            }

            motion.BeginAutoTravel(orderKind, FullPathScratch, goalHex, destinationSiteId, HexTravelMode.Ground);
            if (orderKind == FormalArmyOrderKind.TravelToHex ||
                orderKind == FormalArmyOrderKind.TravelToWorldSite)
                motion.ClearOrderTarget();
            motion.LastProcessedWorldTick = world.Tick.Value;
            army.SyncLegacyFromWorldMotion();
            FormalArmyMemberPresenceSync.SyncAll(world, army);
            if (isReplace)
            {
                if (world.Strategic.Squads.TryGet(army.SquadId, out var replacedCommand))
                    replacedCommand.SetCommand(SquadCommandKind.FormalArmyWorldMotion);
                FormalArmyOrderReplaceTrace.Emit(
                    army,
                    replaceTrace,
                    goalHex,
                    destinationSiteId,
                    FullPathScratch);
            }

            return Result.Success();
        }

        public static void AdvanceAll(SimulationWorld world, int ticks)
        {
            if (world?.Strategic?.FormalArmies == null || ticks < 1)
                return;

            var hexSize = world.HexWorld.HexSize > 0f ? world.HexWorld.HexSize : 1f;
            var budget = PlayerPartyTravelRuntimeService.WorldUnitsPerTick(hexSize) * ticks;
            AdvanceArmyScratch.Clear();
            foreach (var kv in world.Strategic.FormalArmies.Armies)
            {
                var army = kv.Value;
                if (army == null || !army.WorldMotion.IsMoving)
                    continue;
                if (FormalArmyMemberPresenceSync.IsArmyEngaged(world, army))
                    continue;
                AdvanceArmyScratch.Add(kv.Key);
            }

            for (var i = 0; i < AdvanceArmyScratch.Count; i++)
            {
                if (!world.Strategic.FormalArmies.TryGet(AdvanceArmyScratch[i], out var army) ||
                    army == null ||
                    !army.WorldMotion.IsMoving)
                    continue;

                AdvanceDistanceBudget(world, army, budget);
                ArmyService.SyncNonLivingMembers(world, army);
            }
        }

        public static void AdvanceDistanceBudget(SimulationWorld world, FormalArmy army, float distanceBudget)
        {
            if (world == null || army == null || distanceBudget <= 0f)
                return;

            var motion = army.WorldMotion;
            if (!motion.IsMoving)
                return;

            var hasMover = false;
            for (var i = 0; i < army.MemberCharacterIds.Count; i++)
                if (LingeringBattlefieldPartyService.IsLivingForMacroOrder(world,
                        new Domain.Ids.EntityId(army.MemberCharacterIds[i]))) { hasMover = true; break; }
            if (!hasMover)
            {
                motion.ClearTravel();
                army.SyncLegacyFromWorldMotion();
                FormalArmyMemberPresenceSync.SyncAll(world, army);
                return;
            }
            if (!world.Strategic.Squads.TryGet(army.SquadId, out var command) ||
                command.CommandKind != SquadCommandKind.FormalArmyWorldMotion) return;

            if (motion.RouteKind == FormalArmyRouteKind.SurfaceGround)
            {
                AdvanceSurfaceDistanceBudget(world, army, distanceBudget);
                return;
            }

            var hexSize = world.HexWorld.HexSize > 0f ? world.HexWorld.HexSize : 1f;
            var pos = motion.IsSiteDeparturePending &&
                      motion.LocationKind == FormalArmyLocationKind.AtWorldSite
                ? motion.SiteDepartureVirtualPosition
                : motion.WorldPosition;
            var previousDerived = motion.CurrentHex;
            var isSiteDepartureVirtual = motion.IsSiteDeparturePending &&
                                         motion.LocationKind == FormalArmyLocationKind.AtWorldSite;

            var remainingBudget = distanceBudget;
            var guard = 0;
            while (remainingBudget > 0.0001f && motion.IsMoving && guard++ < 64)
            {
                if (!motion.TryGetActiveSegmentWorld(hexSize, out var fromPos, out var toPos))
                {
                    if (isSiteDepartureVirtual)
                    {
                        CommitSiteDepartureBoundaryCrossing(world, army, motion);
                        if (!motion.IsMoving)
                            return;
                        pos = motion.WorldPosition;
                        previousDerived = motion.CurrentHex;
                        isSiteDepartureVirtual = false;
                        continue;
                    }

                    FinishArrival(world, army, motion, hexSize);
                    return;
                }

                var segmentLen = WorldVec2.Distance(fromPos, toPos);
                if (segmentLen < 0.0001f)
                {
                    motion.IncrementPathIndex();
                    if (motion.SegmentIndex >= motion.HexPathCount - 1)
                    {
                        if (isSiteDepartureVirtual)
                        {
                            CommitSiteDepartureBoundaryCrossing(world, army, motion);
                            if (!motion.IsMoving)
                                return;
                            pos = motion.WorldPosition;
                            previousDerived = motion.CurrentHex;
                            isSiteDepartureVirtual = false;
                            continue;
                        }

                        FinishArrival(world, army, motion, hexSize);
                        return;
                    }

                    continue;
                }

                var remainingOnSegment = WorldVec2.Distance(pos, toPos);
                if (remainingOnSegment <= remainingBudget + 0.0001f)
                {
                    pos = toPos;
                    if (isSiteDepartureVirtual)
                    {
                        var previousHex = motion.CurrentHex;
                        motion.SetSiteDepartureVirtualPosition(pos, hexSize);
                        if (ShouldCommitSiteDepartureBoundaryCrossing(world, army, motion, previousHex, motion.CurrentHex))
                            CommitSiteDepartureBoundaryCrossing(world, army, motion);
                        if (!motion.IsMoving)
                            return;
                        pos = motion.WorldPosition;
                        previousDerived = motion.CurrentHex;
                        isSiteDepartureVirtual = motion.IsSiteDeparturePending &&
                                                  motion.LocationKind == FormalArmyLocationKind.AtWorldSite;
                        remainingBudget -= remainingOnSegment;
                        motion.IncrementPathIndex();
                        if (motion.SegmentIndex >= motion.HexPathCount - 1 && !isSiteDepartureVirtual)
                        {
                            FinishArrival(world, army, motion, hexSize);
                            return;
                        }

                        continue;
                    }

                    var derived = HexMath.WorldToHex(pos.X, pos.Y, hexSize);
                    motion.SetWorldPositionInternal(pos, derived);
                    motion.SetSegment(motion.SegmentIndex, 1f);
                    remainingBudget -= remainingOnSegment;
                    motion.IncrementPathIndex();
                    if (motion.SegmentIndex >= motion.HexPathCount - 1)
                    {
                        FinishArrival(world, army, motion, hexSize);
                        return;
                    }

                    continue;
                }

                var dirX = (toPos.X - pos.X) / remainingOnSegment;
                var dirY = (toPos.Y - pos.Y) / remainingOnSegment;
                var previousPosMid = pos;
                pos = new WorldVec2(pos.X + dirX * remainingBudget, pos.Y + dirY * remainingBudget);
                if (isSiteDepartureVirtual)
                {
                    var previousHex = motion.CurrentHex;
                    motion.SetSiteDepartureVirtualPosition(pos, hexSize);
                    if (ShouldCommitSiteDepartureBoundaryCrossing(world, army, motion, previousHex, motion.CurrentHex))
                        CommitSiteDepartureBoundaryCrossing(world, army, motion);
                    if (!motion.IsMoving)
                        return;
                    if (motion.IsSiteDeparturePending &&
                        motion.LocationKind == FormalArmyLocationKind.AtWorldSite)
                    {
                        var virtualProgress = 1f - WorldVec2.Distance(pos, toPos) / segmentLen;
                        motion.SetSegment(motion.SegmentIndex, virtualProgress);
                        remainingBudget = 0f;
                        continue;
                    }

                    pos = motion.WorldPosition;
                    previousDerived = motion.CurrentHex;
                    isSiteDepartureVirtual = false;
                    var used = WorldVec2.Distance(previousPosMid, pos);
                    remainingBudget = Math.Max(0f, remainingBudget - used);
                    continue;
                }

                var midDerived = HexMath.WorldToHex(pos.X, pos.Y, hexSize);
                motion.SetWorldPositionInternal(pos, midDerived);
                var progress = 1f - WorldVec2.Distance(pos, toPos) / segmentLen;
                motion.SetSegment(motion.SegmentIndex, progress);
                remainingBudget = 0f;
            }

            army.SyncLegacyFromWorldMotion();
            FormalArmyMemberPresenceSync.SyncAll(world, army);
        }

        /// <summary>
        /// Called once after static content/navigation has been rebound following load. Pending
        /// routes resume only when their exact baked identity is available; changed content is
        /// replanned from the saved precise position to the saved physical goal.
        /// </summary>
        public static void RebindPendingSurfaceRoutes(SimulationWorld world)
        {
            if (world?.Strategic?.FormalArmies == null) return;
            foreach (var pair in world.Strategic.FormalArmies.Armies)
            {
                var army = pair.Value;
                var motion = army?.WorldMotion;
                if (motion == null || motion.RouteKind != FormalArmyRouteKind.SurfacePending)
                    continue;
                if (!world.SurfaceGround.TryGet(motion.SurfaceId, out var navigation))
                    continue;
                if (string.Equals(navigation.SourceHash, motion.SurfaceSourceHash,
                        StringComparison.Ordinal))
                {
                    motion.SetSurfaceRouteState(FormalArmyRouteKind.SurfaceGround, string.Empty);
                    army.SyncLegacyFromWorldMotion();
                    continue;
                }

                SurfacePathScratch.Clear();
                var status = navigation.TryFindRoute(
                    motion.WorldPosition, motion.PhysicalDestination, SurfacePathScratch);
                if (status == SurfaceGroundRouteStatus.Found)
                {
                    motion.BeginSurfaceTravel(motion.CurrentOrderKind, SurfacePathScratch,
                        motion.PhysicalDestination, motion.DestinationHex,
                        motion.DestinationSiteId, navigation.SurfaceId,
                        navigation.SourceRevision, navigation.SourceHash);
                    army.SyncLegacyFromWorldMotion();
                }
                else
                {
                    motion.SetSurfaceRouteState(FormalArmyRouteKind.SurfaceFailed,
                        "RestoreReplanFailed:" + status);
                }
            }
        }

        static void AdvanceSurfaceDistanceBudget(
            SimulationWorld world,
            FormalArmy army,
            float distanceBudget)
        {
            var motion = army.WorldMotion;
            if (!world.SurfaceGround.TryGet(motion.SurfaceId, out var navigation))
            {
                motion.SetSurfaceRouteState(FormalArmyRouteKind.SurfacePending, "NavigationNotReady");
                return;
            }
            if (!string.Equals(navigation.SourceHash, motion.SurfaceSourceHash, StringComparison.Ordinal))
            {
                SurfacePathScratch.Clear();
                var status = navigation.TryFindRoute(
                    motion.WorldPosition, motion.PhysicalDestination, SurfacePathScratch);
                if (status != SurfaceGroundRouteStatus.Found)
                {
                    motion.SetSurfaceRouteState(FormalArmyRouteKind.SurfaceFailed,
                        "NavigationRevisionMismatch:" + status);
                    return;
                }
                motion.BeginSurfaceTravel(motion.CurrentOrderKind, SurfacePathScratch,
                    motion.PhysicalDestination, motion.DestinationHex,
                    motion.DestinationSiteId, navigation.SurfaceId,
                    navigation.SourceRevision, navigation.SourceHash);
            }

            var path = motion.SurfacePath;
            var index = motion.SurfaceWaypointIndex;
            var position = motion.WorldPosition;
            var remaining = distanceBudget;
            // Each iteration consumes a waypoint or all remaining distance, so this bound scales
            // with the actual owned route and never discards a high-speed tick at an arbitrary 64.
            var guard = Math.Max(2, path.Count + 1);
            while (remaining > 0.0001f && index < path.Count && guard-- > 0)
            {
                var target = path[index];
                var segmentRemaining = WorldVec2.Distance(position, target);
                if (segmentRemaining <= 0.0001f)
                {
                    position = target;
                    index++;
                    continue;
                }

                if (segmentRemaining <= remaining + 0.0001f)
                {
                    position = target;
                    remaining -= segmentRemaining;
                    index++;
                }
                else
                {
                    var ratio = remaining / segmentRemaining;
                    position = new WorldVec2(
                        position.X + (target.X - position.X) * ratio,
                        position.Y + (target.Y - position.Y) * ratio);
                    remaining = 0f;
                }

                var derived = HexMath.WorldToHex(position.X, position.Y,
                    world.HexWorld.HexSize > 0f ? world.HexWorld.HexSize : 1f);
                motion.SetWorldPositionInternal(position, derived);
                motion.SetSurfaceWaypoint(index,
                    index < path.Count && segmentRemaining > 0.0001f
                        ? 1f - WorldVec2.Distance(position, path[index]) / segmentRemaining
                        : 0f);
            }

            if (index >= path.Count)
            {
                var destination = motion.PhysicalDestination;
                var destinationHex = HexMath.WorldToHex(destination.X, destination.Y,
                    world.HexWorld.HexSize > 0f ? world.HexWorld.HexSize : 1f);
                var destinationSiteId = motion.DestinationSiteId;
                if (!string.IsNullOrEmpty(destinationSiteId))
                    motion.SetAtWorldSitePreservingWorldPosition(
                        destinationSiteId, destination, destinationHex);
                else
                    motion.SetWorldPositionInternal(destination, destinationHex);
                motion.ClearTravel();
                army.State = FormalArmyState.Idle;
            }
            else
            {
                army.State = FormalArmyState.Moving;
            }

            army.SyncLegacyFromWorldMotion();
            FormalArmyMemberPresenceSync.SyncAll(world, army);
        }

        static void CommitSiteDepartureBoundaryCrossing(
            SimulationWorld world,
            FormalArmy army,
            FormalArmyWorldMotion motion)
        {
            if (!motion.IsSiteDeparturePending)
                return;

            var hexSize = world.HexWorld.HexSize > 0f ? world.HexWorld.HexSize : 1f;
            var boundaryEntry = motion.SiteDepartureBoundaryEntry;
            var exitHex = motion.SiteDepartureExitHex;
            motion.SetWorldPositionInternal(boundaryEntry, exitHex);
            motion.ClearSiteDeparturePending();
            army.SyncLegacyFromWorldMotion();
            FormalArmyMemberPresenceSync.SyncAll(world, army);
        }

        static bool ShouldCommitSiteDepartureBoundaryCrossing(
            SimulationWorld world,
            FormalArmy army,
            FormalArmyWorldMotion motion,
            HexCoord previousHex,
            HexCoord newHex)
        {
            if (!motion.IsSiteDeparturePending || string.IsNullOrEmpty(motion.SiteId))
                return false;
            if (!world.Strategic.Sites.TryGet(motion.SiteId, out var site) || site == null)
                return false;
            return site.OccupiesHex(previousHex) && !site.OccupiesHex(newHex);
        }

        static void FinishArrival(
            SimulationWorld world,
            FormalArmy army,
            FormalArmyWorldMotion motion,
            float hexSize)
        {
            var destSiteId = motion.DestinationSiteId ?? string.Empty;
            if (string.IsNullOrEmpty(destSiteId))
                destSiteId = TryCanonicalizeFootprintHexDestination(
                    world, motion.DestinationHex, destSiteId, out _);

            if (!string.IsNullOrEmpty(destSiteId) &&
                world.Strategic.Sites.TryGet(destSiteId, out var site) &&
                site != null)
            {
                site.EnsurePresenceHexValid();
                motion.SetAtWorldSite(site.SiteId, site.AnchorHex, hexSize);
            }
            else
            {
                var center = HexCenter(motion.DestinationHex, hexSize);
                var derived = HexMath.WorldToHex(center.X, center.Y, hexSize);
                motion.SetAtWorldPosition(center, derived);
            }

            motion.ClearTravel();
            army.SyncLegacyFromWorldMotion();
            army.State = FormalArmyState.Idle;
            FormalArmyMemberPresenceSync.SyncAll(world, army);
        }

        static bool TryBuildPathLeavingSite(
            SimulationWorld world,
            WorldSite site,
            HexCoord startHex,
            HexCoord goalHex,
            IReadOnlyCollection<HexCoord> blocked,
            List<HexCoord> into,
            out HexCoord exitHex,
            out HexCoord departureFootprintHex)
        {
            into.Clear();
            exitHex = default;
            departureFootprintHex = default;
            if (!BackgroundCharacterSiteDepartureResolver.TryResolveDepartureHex(world, site, goalHex, out exitHex))
                return false;

            if (!BackgroundCharacterSiteDepartureResolver.TryResolveDepartureFootprintHex(
                    site,
                    exitHex,
                    out departureFootprintHex))
                return false;

            PathScratch.Clear();
            if (!startHex.Equals(departureFootprintHex) &&
                HexPathfinder.TryFindPath(
                    world.HexWorld, startHex, departureFootprintHex, PathScratch,
                    HexTravelMode.Ground, blocked) &&
                PathScratch.Count >= 1)
            {
                for (var i = 0; i < PathScratch.Count; i++)
                {
                    if (into.Count == 0 || !into[into.Count - 1].Equals(PathScratch[i]))
                        into.Add(PathScratch[i]);
                }
            }
            else if (into.Count == 0 || !into[into.Count - 1].Equals(departureFootprintHex))
            {
                into.Add(departureFootprintHex);
            }

            if (!into[into.Count - 1].Equals(departureFootprintHex))
                into.Add(departureFootprintHex);

            if (!into[into.Count - 1].Equals(exitHex))
                into.Add(exitHex);

            if (exitHex == goalHex)
                return into.Count >= 2;

            PathScratch.Clear();
            if (!HexPathfinder.TryFindPath(
                    world.HexWorld, exitHex, goalHex, PathScratch,
                    HexTravelMode.Ground, blocked) ||
                PathScratch.Count < 1)
                return false;

            for (var i = 1; i < PathScratch.Count; i++)
            {
                if (into.Count == 0 || !into[into.Count - 1].Equals(PathScratch[i]))
                    into.Add(PathScratch[i]);
            }

            return into.Count >= 2;
        }

        static HexCoord ResolveDeterministicSiteApproachHex(
            SimulationWorld world,
            HexCoord from,
            WorldSite site)
        {
            HexCoord best = site.AnchorHex;
            var bestDist = int.MaxValue;
            foreach (var hex in site.EnumerateFootprintHexes())
            {
                if (!world.HexWorld.TryGetTile(hex, out var tile) || tile == null || !tile.IsPassable)
                    continue;
                var d = HexMath.Distance(from, hex);
                if (d < bestDist ||
                    (d == bestDist && (hex.Q < best.Q || (hex.Q == best.Q && hex.R < best.R))))
                {
                    bestDist = d;
                    best = hex;
                }
            }

            return best;
        }

        static string TryCanonicalizeFootprintHexDestination(
            SimulationWorld world,
            HexCoord destinationHex,
            string destinationSiteId,
            out bool canonicalizedFromFootprint)
        {
            canonicalizedFromFootprint = false;
            if (!string.IsNullOrEmpty(destinationSiteId))
                return destinationSiteId;

            if (world.Strategic?.Sites != null &&
                world.Strategic.Sites.TryGetAtHex(destinationHex, out var site) &&
                site != null)
            {
                canonicalizedFromFootprint = true;
                return site.SiteId;
            }

            return string.Empty;
        }

        static WorldVec2 HexCenter(HexCoord hex, float hexSize)
        {
            HexMath.ToWorldPosition(hex, hexSize, out var x, out var y);
            return new WorldVec2(x, y);
        }

        static bool IsLegacyPathCompatibleWithRegisteredSurfaces(
            SimulationWorld world,
            WorldVec2 preciseStart,
            IReadOnlyList<HexCoord> path)
        {
            if (path == null || path.Count == 0 || world.SurfaceGround.Registered.Count == 0)
                return true;
            var size = world.HexWorld.HexSize > 0f ? world.HexWorld.HexSize : 1f;
            var from = preciseStart;
            for (var i = 1; i < path.Count; i++)
            {
                var to = HexCenter(path[i], size);
                foreach (var pair in world.SurfaceGround.Registered)
                {
                    var nav = pair.Value;
                    if (nav == null) continue;
                    var length = WorldVec2.Distance(from, to);
                    var steps = Math.Max(1, (int)Math.Ceiling(length / Math.Max(.01f, nav.CellSize * .5f)));
                    for (var step = 0; step <= steps; step++)
                    {
                        var t = step / (float)steps;
                        var x = from.X + (to.X - from.X) * t;
                        var y = from.Y + (to.Y - from.Y) * t;
                        if (nav.Contains(x, y) && !nav.IsWalkable(x, y))
                            return false;
                    }
                }
                from = to;
            }
            return true;
        }
    }
}
