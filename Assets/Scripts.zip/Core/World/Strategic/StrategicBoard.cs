using System.Collections.Generic;
using XianXia.Core.Domain.Ids;
using XianXia.Core.World;
using XianXia.Core.World.Hex;

namespace XianXia.Core.World.Strategic
{
    public static class StrategicObjectiveKind
    {
        public const string ControlCore = "ControlCore";
        public const string FactionFlag = "FactionFlag";
    }

    /// <summary>BattleOffer 来源：决定决策按钮集合（Local-origin 禁 Auto）与宣战 commitment 语义。</summary>
    public enum BattleOfferOrigin
    {
        /// <summary>WorldMap 战略指令（FormalArmy / PlayerParty remote attack、追击到站、残留再入）。</summary>
        StrategicCommand = 0,
        /// <summary>LocalMap 玩家主动 hostile action（对 FormalArmy member 的军事攻击）。</summary>
        LocalMapHostileAction = 1
    }

    /// <summary>
    /// Host-facing lifetime marker for a manual battle presented on the already active
    /// Continuous Outdoor surface. Strategic battle location remains in Participants;
    /// this state only identifies which physical presentation owns the active session.
    /// It is intentionally runtime-only and is rebuilt, never serialized.
    /// </summary>
    public sealed class ContinuousManualCombatPresentationState
    {
        readonly HashSet<ulong> _participantIds = new HashSet<ulong>();
        readonly HashSet<ulong> _friendlyIds = new HashSet<ulong>();
        readonly HashSet<ulong> _enemyIds = new HashSet<ulong>();

        public bool IsActive { get; private set; }
        public string OfferId { get; private set; } = string.Empty;
        public string SurfaceId { get; private set; } = string.Empty;
        public WorldVec2 BattleWorldAnchor { get; private set; }
        public IReadOnlyCollection<ulong> ParticipantIds => _participantIds;

        public bool Contains(EntityId id) =>
            IsActive && !id.IsNone && _participantIds.Contains(id.Value);

        public bool IsFriendly(EntityId id) =>
            IsActive && !id.IsNone && _friendlyIds.Contains(id.Value);

        public bool IsEnemy(EntityId id) =>
            IsActive && !id.IsNone && _enemyIds.Contains(id.Value);

        public bool AreOpposing(EntityId first, EntityId second) =>
            IsActive && ((IsFriendly(first) && IsEnemy(second)) ||
                         (IsEnemy(first) && IsFriendly(second)));

        public void Begin(
            string offerId,
            string surfaceId,
            WorldVec2 battleWorldAnchor,
            IReadOnlyList<ActualBattleParticipant> participants)
        {
            Clear();
            if (string.IsNullOrWhiteSpace(offerId) || string.IsNullOrWhiteSpace(surfaceId))
                return;
            OfferId = offerId.Trim();
            SurfaceId = surfaceId.Trim();
            BattleWorldAnchor = battleWorldAnchor;
            if (participants != null)
                for (var i = 0; i < participants.Count; i++)
                {
                    var participant = participants[i];
                    if (participant.EntityId.IsNone || !_participantIds.Add(participant.EntityId.Value))
                        continue;
                    if (participant.IsFriendly)
                        _friendlyIds.Add(participant.EntityId.Value);
                    else
                        _enemyIds.Add(participant.EntityId.Value);
                }
            IsActive = _participantIds.Count > 0;
            if (!IsActive)
                Clear();
        }

        public bool ClearOwned(string offerId)
        {
            if (!IsActive || !string.Equals(OfferId, offerId ?? string.Empty, System.StringComparison.Ordinal))
                return false;
            Clear();
            return true;
        }

        public void Clear()
        {
            IsActive = false;
            OfferId = string.Empty;
            SurfaceId = string.Empty;
            BattleWorldAnchor = default;
            _participantIds.Clear();
            _friendlyIds.Clear();
            _enemyIds.Clear();
        }
    }

    public sealed class StrategicBoard
    {
        public WorldSpatialRules SpatialRules { get; set; }
        public readonly System.Collections.Generic.HashSet<string> SuppressedCharacterContacts = new System.Collections.Generic.HashSet<string>();
        public XianXia.Core.Domain.Ids.EntityId PendingCharacterAttacker, PendingCharacterTarget;
        public CharacterEncounterState CharacterEncounter { get; set; }
        public FactionDiplomacyBoard Diplomacy { get; } = new FactionDiplomacyBoard();
        public WarBoard Wars { get; } = new WarBoard();
        public AllianceBoard Alliances { get; } = new AllianceBoard();
        public VassalageBoard Vassalages { get; } = new VassalageBoard();
        public RetreatingArmyBoard RetreatingArmies { get; } = new RetreatingArmyBoard();
        /// <summary>Unified persistent action-group membership authority.</summary>
        public SquadBoard Squads { get; } = new SquadBoard();
        public SquadWorldMotionBoard SquadWorldMotions { get; } = new SquadWorldMotionBoard();
        /// <summary>Hex 战略重要地点（155）；替代 Node 的地点职责。</summary>
        public WorldSiteBoard Sites { get; } = new WorldSiteBoard();
        /// <summary>政治辖区 Board（2J §6.3）；与 Sites 相互引用（Site.TerritoryRegionId ↔ Region.PrimaryWorldSiteId）。</summary>
        public TerritoryRegionBoard TerritoryRegions { get; } = new TerritoryRegionBoard();
        /// <summary>Site 行政范围的不可改写取得历史；Owner 仍由 WorldSite 提供。</summary>
        public TerritoryClaimBoard TerritoryClaims { get; } = new TerritoryClaimBoard();
        /// <summary>SiteId-keyed public administrative resources; ownership remains on WorldSite.</summary>
        public WorldSitePublicStockBoard SitePublicStocks { get; } = new WorldSitePublicStockBoard();
        public FactionFlagBoard FactionFlags { get; } = new FactionFlagBoard();
        public ArrivalNoticePending ArrivalNotice { get; } = new ArrivalNoticePending();
        public StrategicEncounterRuntime Encounter { get; } = new StrategicEncounterRuntime();
        public LingeringBattlefieldRegistry LingeringBattlefields { get; } = new LingeringBattlefieldRegistry();
        public StrategicClockFreezeState ClockFreeze { get; } = new StrategicClockFreezeState();
        public BattleParticipantSnapshot Participants { get; } = new BattleParticipantSnapshot();
        public ContinuousManualCombatPresentationState ContinuousManualCombat { get; } =
            new ContinuousManualCombatPresentationState();
        public ManualBattleSettlementState ManualBattleSettlement { get; } =
            new ManualBattleSettlementState();

        /// <summary>Ch01 / LevelTester：启用 presence-based 组军场景 Adapter。</summary>
        public bool Ch01FormationScenarioCompat { get; set; }

        /// <summary>Host 注入：Engagement 收集 PlayerParty 时使用（Domain 不依赖 Session）。</summary>
        public PlayerPartyRuntime PlayerPartyContext { get; set; }

        /// <summary>ReinforcementRange 战略 TravelCost 阈值（遗留）。≤0 忽略。</summary>
        public int ReinforcementTravelCostThreshold { get; set; }

        /// <summary>支援最大节点跳数（遗留）。&lt;0 忽略。</summary>
        public int ReinforcementMaxHops { get; set; } = -1;

        /// <summary>支援世界坐标半径（大地图 XY）。≤0 用默认 ≈2～3 人头像宽。</summary>
        public float ReinforcementWorldRadius { get; set; }

        /// <summary>派人探望弥留成功后，到站打开大地图时衔接「进入残留战场」菜单。</summary>
        public ulong PendingLingeringVisitIncapId { get; set; }

        readonly List<ulong> _pendingLingeringVisitPartyIds = new List<ulong>(8);

        public IReadOnlyList<ulong> PendingLingeringVisitPartyIds => _pendingLingeringVisitPartyIds;

        public void SetPendingLingeringVisit(ulong focusIncapId, IReadOnlyList<EntityId> party)
        {
            PendingLingeringVisitIncapId = focusIncapId;
            _pendingLingeringVisitPartyIds.Clear();
            if (party == null)
                return;
            for (var i = 0; i < party.Count; i++)
            {
                if (!party[i].IsNone)
                    _pendingLingeringVisitPartyIds.Add(party[i].Value);
            }
        }

        public void ClearPendingLingeringVisit()
        {
            PendingLingeringVisitIncapId = 0;
            _pendingLingeringVisitPartyIds.Clear();
        }

        /// <summary>玩家帮派 id（占点后更新）。</summary>
        public string PlayerFactionId { get; set; } = StrategicFactionCatalog.PlayerFactionId;

        public bool HasArrivalNotice =>
            ArrivalNotice != null && !ArrivalNotice.Resolved && !string.IsNullOrEmpty(ArrivalNotice.NoticeId);

        public bool HasBlockingInterrupt =>
            HasArrivalNotice ||
            (Participants != null && Participants.IsAutoSettlement);

        public bool IsWorldTickFrozen => ClockFreeze != null && ClockFreeze.IsWorldTickFrozen;

        public bool IsModalEncounter => ClockFreeze != null && ClockFreeze.IsModalEncounter;

        public void ClearArrivalNotice()
        {
            ArrivalNotice.NoticeId = string.Empty;
            ArrivalNotice.Summary = string.Empty;
            ArrivalNotice.PlaceLabel = string.Empty;
            ArrivalNotice.FocusNodeId = string.Empty;
            ArrivalNotice.ClearArrived();
            ArrivalNotice.Resolved = true;
        }
    }

    /// <summary>我方宏观到站提示（非遇敌）。</summary>
    public sealed class ArrivalNoticePending
    {
        public string NoticeId { get; set; } = string.Empty;
        public string Summary { get; set; } = string.Empty;
        public string PlaceLabel { get; set; } = string.Empty;
        public string FocusNodeId { get; set; } = string.Empty;
        public bool Resolved { get; set; } = true;
        readonly List<ulong> _arrivedIds = new List<ulong>(8);

        public IReadOnlyList<ulong> ArrivedIds => _arrivedIds;

        public void SetArrived(IReadOnlyList<EntityId> party)
        {
            _arrivedIds.Clear();
            if (party == null)
                return;
            for (var i = 0; i < party.Count; i++)
            {
                if (!party[i].IsNone && !_arrivedIds.Contains(party[i].Value))
                    _arrivedIds.Add(party[i].Value);
            }
        }

        public void ClearArrived() => _arrivedIds.Clear();
    }
}
