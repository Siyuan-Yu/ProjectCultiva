using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using XianXia.Core.Domain.Ids;
using XianXia.Core.Simulation;
using XianXia.Core.World.Hex;

namespace XianXia.Core.World.Strategic
{
    /// <summary>
    /// Formal Army compatibility identity／motion. Member queries project the unified Squad;
    /// Character-side ArmyMembershipComponent remains a legacy reverse adapter.
    /// 战略位置真源：<see cref="CurrentHex"/>（Pure Hex）。
    /// </summary>
    public sealed class FormalArmy
    {
        SquadState _squad;
        EntityId _leaderCharacterId;

        FormalArmyState _state = FormalArmyState.Idle;

        HexCoord _currentHex;
        HexCoord _destinationHex;
        readonly List<HexCoord> _hexPath = new List<HexCoord>(32);
        int _currentPathIndex;
        float _stepProgress;
        int _stepRemainingTicks;
        int _stepTotalTicks;
        bool _usesHexStrategicPosition;

        public string ArmyId { get; internal set; } = string.Empty;
        public string SquadId { get; internal set; } = string.Empty;
        public string FactionId { get; internal set; } = string.Empty;
        public EntityId LeaderCharacterId
        {
            get => _squad != null ? _squad.LeaderCharacterId : _leaderCharacterId;
            internal set { _leaderCharacterId = value; if (_squad != null) _squad.LeaderCharacterId = value; }
        }

        /// <summary>Phase 3：连续世界位置 + 旅行状态真源。</summary>
        public FormalArmyWorldMotion WorldMotion { get; } = new FormalArmyWorldMotion();

        public bool UsesHexStrategicPosition
        {
            get => _usesHexStrategicPosition;
            internal set => _usesHexStrategicPosition = value;
        }

        public ArmyHexPosition HexPosition => new ArmyHexPosition(this);

        public HexCoord CurrentHex
        {
            get => _currentHex;
            internal set => _currentHex = value;
        }

        public HexCoord DestinationHex
        {
            get => _destinationHex;
            internal set => _destinationHex = value;
        }

        public int CurrentPathIndex
        {
            get => _currentPathIndex;
            internal set => _currentPathIndex = value;
        }

        public float StepProgress
        {
            get => _stepProgress;
            internal set => _stepProgress = value;
        }

        /// <summary>相邻格间移动进度 0～1（<see cref="ArmyHexPosition"/> 语义）。</summary>
        public float MoveProgress => StepProgress;

        public bool TryGetNextHex(out HexCoord nextHex)
        {
            if (State == FormalArmyState.Moving && TryGetActiveStepHexes(out _, out nextHex))
                return true;
            nextHex = default;
            return false;
        }

        public int StepRemainingTicks
        {
            get => _stepRemainingTicks;
            internal set => _stepRemainingTicks = value;
        }

        public int StepTotalTicks
        {
            get => _stepTotalTicks;
            internal set => _stepTotalTicks = value;
        }

        public int HexPathCount => _hexPath.Count;

        public IReadOnlyList<HexCoord> HexPath =>
            _hexPathView ?? (_hexPathView = _hexPath.AsReadOnly());

        ReadOnlyCollection<HexCoord> _hexPathView;

        public FormalArmyState State
        {
            get => _state;
            internal set => FormalArmyStrategicMutationDiagnostics.WriteState(this, ref _state, value);
        }

        /// <summary>若 Army 位于 WorldSite，返回 SiteId（Phase 3：优先 WorldMotion）。</summary>
        public bool TryGetFormationSiteId(SimulationWorld world, out string siteId)
        {
            siteId = string.Empty;
            if (WorldMotion.HasPosition &&
                WorldMotion.LocationKind == FormalArmyLocationKind.AtWorldSite &&
                !string.IsNullOrEmpty(WorldMotion.SiteId))
            {
                siteId = WorldMotion.SiteId;
                return true;
            }

            if (world?.Strategic?.Sites == null)
                return false;
            if (!world.Strategic.Sites.TryGetAtHex(CurrentHex, out var site) || site == null)
                return false;
            siteId = site.SiteId ?? string.Empty;
            return !string.IsNullOrEmpty(siteId);
        }

        internal void SyncLegacyFromWorldMotion()
        {
            var motion = WorldMotion;
            UsesHexStrategicPosition = motion.HasPosition &&
                                       string.IsNullOrEmpty(motion.SurfaceId);
            CurrentHex = motion.CurrentHex;
            DestinationHex = motion.DestinationHex;
            StepProgress = motion.SegmentProgress;
            CurrentPathIndex = motion.SegmentIndex;
            StepRemainingTicks = 0;
            StepTotalTicks = 0;

            _hexPath.Clear();
            for (var i = 0; i < motion.HexPathCount; i++)
                _hexPath.Add(motion.HexPath[i]);

            if (motion.IsMoving)
            {
                if (State != FormalArmyState.Moving)
                    State = FormalArmyState.Moving;
            }
            else if (State == FormalArmyState.Moving)
            {
                State = FormalArmyState.Idle;
            }
        }

        /// <summary>兼容旧调用：仍基于 CurrentHex 查 Site。</summary>
        public bool TryGetFormationSiteIdLegacy(SimulationWorld world, out string siteId) =>
            TryGetFormationSiteId(world, out siteId);

        internal void SetHexPath(IReadOnlyList<HexCoord> path, HexCoord destination)
        {
            _hexPath.Clear();
            if (path != null)
            {
                for (var i = 0; i < path.Count; i++)
                    _hexPath.Add(path[i]);
            }

            _destinationHex = destination;
            _currentPathIndex = 0;
            _stepProgress = 0f;
            if (_hexPath.Count < 2 || _currentHex == destination)
            {
                CompleteHexMove();
                return;
            }

            State = FormalArmyState.Moving;
            _currentPathIndex = 0;
            StepTotalTicks = Math.Max(4, 8);
            StepRemainingTicks = StepTotalTicks;
            StepProgress = 0f;
        }

        internal void ClearHexPath()
        {
            _hexPath.Clear();
            _currentPathIndex = 0;
            _stepProgress = 0f;
            _stepRemainingTicks = 0;
            _stepTotalTicks = 0;
            _destinationHex = _currentHex;
        }

        internal void CompleteHexMove()
        {
            ClearHexPath();
            if (State == FormalArmyState.Moving)
                State = FormalArmyState.Idle;
        }

        public bool TryGetActiveStepHexes(out HexCoord from, out HexCoord to)
        {
            from = _currentHex;
            to = _currentHex;
            if (_hexPath.Count < 2 || _currentPathIndex < 0 || _currentPathIndex >= _hexPath.Count - 1)
                return false;
            from = _hexPath[_currentPathIndex];
            to = _hexPath[_currentPathIndex + 1];
            return true;
        }

        public IReadOnlyList<ulong> MemberCharacterIds =>
            _squad != null ? _squad.MemberCharacterIds : Array.Empty<ulong>();

        internal void BindSquad(SquadState squad)
        {
            _squad = squad;
            SquadId = squad?.SquadId ?? string.Empty;
            if (squad != null)
            {
                squad.LegacyArmyId = ArmyId;
                _leaderCharacterId = squad.LeaderCharacterId;
            }
        }

        public bool ContainsMember(EntityId characterId)
        {
            if (characterId.IsNone)
                return false;
            return _squad != null && _squad.Contains(characterId);
        }
    }
}
