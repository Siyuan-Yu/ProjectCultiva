using System.Collections.Generic;
using XianXia.Core.Simulation;
using XianXia.Core.World.Hex;

namespace XianXia.Core.World.Strategic
{
    /// <summary>
    /// Control Asset 重建后的有效领地 invariant 校验。WorldSite 名义范围可被更早建立的资产抢先，
    /// 因此不再要求 footprint 全部落入自身有效 Region。
    /// </summary>
    public static class TerritoryInvariantValidator
    {
        public static List<string> Validate(SimulationWorld world)
        {
            var errors = new List<string>();
            if (world?.Strategic?.Sites == null || world?.Strategic?.TerritoryRegions == null)
                return errors;

            var sites = world.Strategic.Sites;
            var regions = world.Strategic.TerritoryRegions;

            // ① Site → Region 绑定
            foreach (var kv in sites.Sites)
            {
                var site = kv.Value;
                if (site == null || string.IsNullOrEmpty(site.SiteId))
                    continue;
                if (string.IsNullOrEmpty(site.TerritoryRegionId))
                    continue;

                if (!regions.TryGet(site.TerritoryRegionId, out var region) || region == null)
                {
                    errors.Add("WorldSite '" + site.SiteId + "' TerritoryRegionId '" +
                               site.TerritoryRegionId + "' missing.");
                    continue;
                }

                if (!string.Equals(region.PrimaryWorldSiteId, site.SiteId, System.StringComparison.Ordinal))
                    errors.Add("Region '" + region.RegionId + "' PrimaryWorldSiteId='" +
                               region.PrimaryWorldSiteId + "' != WorldSite '" + site.SiteId + "'.");

                // ② Owner == Controller
                var siteOwner = site.OwnerFactionId ?? string.Empty;
                var controller = region.ControlFactionId ?? string.Empty;
                if (!string.Equals(siteOwner, controller, System.StringComparison.Ordinal))
                    errors.Add("Owner invariant broken for WorldSite '" + site.SiteId +
                               "': OwnerFactionId='" + siteOwner + "' != Region.ControlFactionId='" +
                               controller + "'.");
            }

            // ③ Region hex 合法 + 无重复 + 无跨 Region overlap
            var hexToRegion = new Dictionary<HexCoord, string>();
            foreach (var regionKv in regions.Regions)
            {
                var region = regionKv.Value;
                if (region == null)
                    continue;
                var seen = new HashSet<HexCoord>();
                for (var i = 0; i < region.Hexes.Count; i++)
                {
                    var hex = region.Hexes[i];
                    if (!world.HexWorld.IsInBounds(hex))
                    {
                        errors.Add("Region '" + region.RegionId + "' hex out of bounds: " + hex + ".");
                        continue;
                    }
                    if (!seen.Add(hex))
                    {
                        errors.Add("Region '" + region.RegionId + "' duplicate hex: " + hex + ".");
                        continue;
                    }
                    if (hexToRegion.TryGetValue(hex, out var other) &&
                        !string.Equals(other, region.RegionId, System.StringComparison.Ordinal))
                        errors.Add("Hex " + hex + " belongs to both Region '" + other +
                                   "' and '" + region.RegionId + "'.");
                    else
                        hexToRegion[hex] = region.RegionId;
                }
            }

            // ⑤ Region 每个 Hex 的最终 ControlFactionId 必须 == Region.Controller（13.6）
            // ⑥ Bandit 不能成为 TerritoryRegion Controller（2J §9.2 / §12）
            foreach (var regionKv in regions.Regions)
            {
                var region = regionKv.Value;
                if (region == null)
                    continue;
                if (!string.IsNullOrEmpty(region.ControlFactionId) &&
                    string.Equals(region.ControlFactionId, StrategicFactionCatalog.BanditId, System.StringComparison.Ordinal))
                {
                    errors.Add("Bandit faction cannot control TerritoryRegion '" + region.RegionId + "'.");
                }

                var controller = region.ControlFactionId ?? string.Empty;
                for (var i = 0; i < region.Hexes.Count; i++)
                {
                    var hex = region.Hexes[i];
                    if (!world.HexWorld.TryGetCell(hex, out var cell) || cell == null)
                        continue;
                    var cellController = cell.ControlFactionId ?? string.Empty;
                    if (!string.Equals(cellController, controller, System.StringComparison.Ordinal))
                        errors.Add("Region '" + region.RegionId + "' hex " + hex +
                                   " ControlFactionId='" + cellController +
                                   "' != Region.ControlFactionId='" + controller + "'.");
                }
            }

            return errors;
        }
    }
}
