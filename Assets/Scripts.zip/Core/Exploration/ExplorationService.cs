using XianXia.Core.World;
using XianXia.Core.Attributes;
using XianXia.Core.Content;
using XianXia.Core.Domain.Ids;
using XianXia.Core.Entities;
using XianXia.Core.Events;
using XianXia.Core.Opportunity;
using XianXia.Core.Results;
using XianXia.Core.Settlement;
using XianXia.Core.Simulation;

namespace XianXia.Core.Exploration
{
    /// <summary>Travel between abstract locations and explore for resources／sites／content.</summary>
    public sealed class ExplorationService
    {
        readonly QuestService _quests = new QuestService();
        readonly ContentEventService _contentEvents = new ContentEventService();

        /// <summary>
        /// 村内地点瞬间换点（非正式宏观旅行）。宏观请用 WorldTravelService／地图面板。
        /// </summary>
        public Result Travel(SimulationWorld world, EntityId subject, string targetLocationId)
        {
            if (world == null)
                return Result.Failure(ErrorCode.InvalidArgument, "SimulationWorld is null.");
            if (string.IsNullOrWhiteSpace(targetLocationId))
                return Result.Failure(ErrorCode.InvalidArgument, "Target location required.");
            if (!world.Entities.TryGet(subject, out var entity))
                return Result.Failure(ErrorCode.EntityNotFound, "Subject missing.", subject.ToString());
            if (!entity.TryGet<EntityLocationComponent>(out var loc) || !loc.HasLocation)
                return Result.Failure(ErrorCode.InvalidOperation, "Subject has no current location.");
            if (!world.LocalPlaces.TryGet(targetLocationId, out var target))
                return Result.Failure(ErrorCode.NotFound, "Target location missing.", targetLocationId);
            if (!world.LocalPlaces.AreAdjacent(loc.LocationId, targetLocationId))
                return Result.Failure(ErrorCode.InvalidOperation, "Target location not adjacent.", targetLocationId);

            if (!ContentConditionEvaluator.AllPass(world, subject, target.EnterConditions))
            {
                return Result.Failure(
                    ErrorCode.InvalidOperation,
                    "Location enter conditions not met.",
                    targetLocationId);
            }

            loc.LocationId = targetLocationId;
            world.Events.Publish(
                EventType.LocationChanged,
                world.Tick,
                target: subject,
                payload: targetLocationId);

            return NotifyArrived(world, subject, targetLocationId, setLocation: false);
        }

        /// <summary>
        /// Host 表现抵达或 Travel 共用：挂地点任务＋onArrive 内容事件。
        /// </summary>
        public Result NotifyArrived(
            SimulationWorld world,
            EntityId subject,
            string locationId,
            bool setLocation = true)
        {
            if (world == null)
                return Result.Failure(ErrorCode.InvalidArgument, "SimulationWorld is null.");
            if (string.IsNullOrWhiteSpace(locationId))
                return Result.Failure(ErrorCode.InvalidArgument, "Location required.");
            if (!world.Entities.TryGet(subject, out var entity))
                return Result.Failure(ErrorCode.EntityNotFound, "Subject missing.", subject.ToString());
            if (!WorldLocationQuery.TryGet(world, locationId, out var location))
                return Result.Failure(ErrorCode.NotFound, "Location missing.", locationId);

            if (setLocation)
            {
                if (!entity.TryGet<EntityLocationComponent>(out var loc))
                    return Result.Failure(ErrorCode.ComponentMissing, "EntityLocationComponent missing.");
                if (!string.Equals(loc.LocationId, locationId, System.StringComparison.Ordinal))
                {
                    loc.LocationId = locationId;
                    world.Events.Publish(
                        EventType.LocationChanged,
                        world.Tick,
                        target: subject,
                        payload: locationId);
                }
            }

            OfferLocationQuests(world, subject, location);
            var evaluated = _quests.Evaluate(world, subject);
            if (evaluated.IsFailure)
                return evaluated;
            _contentEvents.TryTrigger(world, subject, "onArrive", locationId);
            return _quests.Evaluate(world, subject);
        }

        public Result ExploreHere(SimulationWorld world, EntityId subject)
        {
            if (world == null)
                return Result.Failure(ErrorCode.InvalidArgument, "SimulationWorld is null.");
            if (!world.Entities.TryGet(subject, out var entity))
                return Result.Failure(ErrorCode.EntityNotFound, "Subject missing.", subject.ToString());
            if (!entity.TryGet<EntityLocationComponent>(out var loc) || !loc.HasLocation)
                return Result.Failure(ErrorCode.InvalidOperation, "Subject has no current location.");
            if (!world.LocalPlaces.TryGet(loc.LocationId, out var location))
                return Result.Failure(ErrorCode.NotFound, "Current location missing.", loc.LocationId);

            var foundAnything = false;

            if (!string.IsNullOrEmpty(location.ResourceOnExploreId) &&
                location.ResourceOnExploreAmount > 0)
            {
                var added = world.Inventory.TryAdd(
                    location.ResourceOnExploreId,
                    location.ResourceOnExploreAmount);
                if (added > 0)
                {
                    world.Events.Publish(
                        EventType.PartyInventoryChanged,
                        world.Tick,
                        target: subject,
                        payload: "bag:" + location.ResourceOnExploreId + ":+" + added);
                    foundAnything = true;
                }
            }

            if (!string.IsNullOrEmpty(location.OpportunitySiteId) &&
                entity.TryGet<KnownSitesComponent>(out var known) &&
                !OpportunityEntranceRules.IsHiddenEntrance(location))
            {
                var siteParsed = DefinitionId.Parse(location.OpportunitySiteId);
                if (siteParsed.IsSuccess &&
                    world.TryGetOpportunitySite(siteParsed.Value, out _) &&
                    !known.Knows(siteParsed.Value))
                {
                    known.Discover(siteParsed.Value);
                    world.Events.Publish(
                        EventType.OpportunitySiteDiscovered,
                        world.Tick,
                        target: subject,
                        payload: location.OpportunitySiteId);
                    foundAnything = true;
                }
            }

            StoryFlagService.Set(world, ContentConditionEvaluator.ExploredFlag(location.Id), subject);

            world.Events.Publish(
                EventType.LocationExplored,
                world.Tick,
                target: subject,
                payload: location.Id + ";found=" + (foundAnything ? "1" : "0"));

            OfferLocationQuests(world, subject, location);
            var evaluated = _quests.Evaluate(world, subject);
            if (evaluated.IsFailure)
                return evaluated;
            _contentEvents.TryTrigger(world, subject, "onExplore", location.Id);
            return _quests.Evaluate(world, subject);
        }

        /// <summary>
        /// 从洞口等入口进入另一张 LocalMap；需已发现机缘点（若入口绑了 opportunitySiteId）。
        /// </summary>
        public Result EnterLocalMap(SimulationWorld world, EntityId subject, string entranceLocationId = null)
        {
            if (world == null)
                return Result.Failure(ErrorCode.InvalidArgument, "SimulationWorld is null.");
            if (!world.Entities.TryGet(subject, out var entity))
                return Result.Failure(ErrorCode.EntityNotFound, "Subject missing.", subject.ToString());
            if (!entity.TryGet<EntityLocationComponent>(out var loc) || !loc.HasLocation)
                return Result.Failure(ErrorCode.InvalidOperation, "Subject has no current location.");

            var entranceId = string.IsNullOrWhiteSpace(entranceLocationId) ? loc.LocationId : entranceLocationId.Trim();
            var fromContinuousOutdoor = !world.LocalMap.IsInInterior &&
                world.ContinuousOutdoorMaterialization.TryGetAnyPlace(entranceId, out _);
            if (!WorldLocationQuery.TryGet(world, entranceId, out var entrance))
                return Result.Failure(ErrorCode.NotFound, "Entrance location missing.", entranceId);
            if (string.IsNullOrEmpty(entrance.EnterLocalMapId) || string.IsNullOrEmpty(entrance.EnterSpawnLocationId))
                return Result.Failure(ErrorCode.InvalidOperation, "Location is not a LocalMap entrance.", entranceId);
            if (!string.Equals(loc.LocationId, entranceId, System.StringComparison.Ordinal))
                return Result.Failure(ErrorCode.InvalidOperation, "Must stand at entrance to enter.", entranceId);

            if (!ContentConditionEvaluator.AllPass(world, subject, entrance.EnterConditions))
                return Result.Failure(ErrorCode.InvalidOperation, "Entrance conditions not met.", entranceId);

            if (!string.IsNullOrEmpty(entrance.OpportunitySiteId))
            {
                if (!entity.TryGet<KnownSitesComponent>(out var known) ||
                    !DefinitionId.TryParse(entrance.OpportunitySiteId, out var siteId) ||
                    !known.Knows(siteId))
                {
                    return Result.Failure(
                        ErrorCode.InvalidOperation,
                        "Discover the cave first (explore).",
                        entrance.OpportunitySiteId);
                }
            }

            if (!world.LocalPlaces.TryGet(entrance.EnterSpawnLocationId, out var spawn) ||
                !string.Equals(spawn.LocalMapId, entrance.EnterLocalMapId,
                    System.StringComparison.Ordinal))
                return Result.Failure(ErrorCode.NotFound, "Interior spawn location is not active.",
                    entrance.EnterSpawnLocationId);

            var session = world.LocalMap;
            if (fromContinuousOutdoor)
            {
                var party = world.Strategic.PlayerPartyContext;
                var returnSurface = world.SurfaceGround.Active;
                if (!XianXia.Core.World.Strategic.PlayerPartyWorldLocationQuery.TryResolve(
                        world, party, out var resolved) || !resolved.HasValue ||
                    resolved.IsLegacyFallback)
                    return Result.Failure(ErrorCode.InvalidOperation,
                        "Continuous entrance has no exact Surface return position.", entranceId);
                if (returnSurface == null || !returnSurface.Contains(
                        resolved.WorldPosition.X, resolved.WorldPosition.Y))
                    world.SurfaceGround.TryResolveContaining(resolved.WorldPosition,
                        out returnSurface);
                if (returnSurface == null)
                    return Result.Failure(ErrorCode.InvalidOperation,
                        "Continuous entrance has no registered return Surface.", entranceId);
                session.HasContinuousOutdoorReturn = true;
                session.ContinuousOutdoorReturnX = resolved.WorldPosition.X;
                session.ContinuousOutdoorReturnY = resolved.WorldPosition.Y;
                session.ContinuousOutdoorReturnSurfaceId = returnSurface.SurfaceId;
            }
            if (string.IsNullOrEmpty(session.OverworldMapLayoutId))
                session.OverworldMapLayoutId = session.ActiveMapLayoutId;
            session.ReturnLocationId = entranceId;
            session.ActiveMapLayoutId = entrance.EnterLocalMapId;

            // 仅移动已站在洞口的己方（Host 先把选中随行者 Location 设到洞口）。
            // 已在洞内的己方（救人／再进）保留其内室 Location，一并登记为洞内成员。
            MovePartyAtLocationTo(world, entranceId, entrance.EnterSpawnLocationId);
            RefreshInteriorOccupants(world, session, entrance.EnterLocalMapId);

            world.Events.Publish(
                EventType.LocalMapChanged,
                world.Tick,
                target: subject,
                payload: session.ActiveMapLayoutId + ";" + entrance.EnterSpawnLocationId);

            return NotifyArrived(world, subject, entrance.EnterSpawnLocationId, setLocation: false);
        }

        public Result LeaveLocalMap(SimulationWorld world, EntityId subject)
        {
            if (world == null)
                return Result.Failure(ErrorCode.InvalidArgument, "SimulationWorld is null.");
            if (!world.Entities.TryGet(subject, out _))
                return Result.Failure(ErrorCode.EntityNotFound, "Subject missing.", subject.ToString());

            var session = world.LocalMap;
            if (!session.IsInInterior)
                return Result.Failure(ErrorCode.InvalidOperation, "Not inside a LocalMap interior.");
            if (string.IsNullOrEmpty(session.OverworldMapLayoutId) && !session.HasContinuousOutdoorReturn)
                return Result.Failure(ErrorCode.InvalidOperation, "Overworld map missing.");
            if (string.IsNullOrEmpty(session.ReturnLocationId) ||
                (!session.HasContinuousOutdoorReturn &&
                 !world.LocalPlaces.TryGet(session.ReturnLocationId, out _)))
                return Result.Failure(ErrorCode.NotFound, "Return location missing.", session.ReturnLocationId);
            if (session.HasContinuousOutdoorReturn &&
                (string.IsNullOrEmpty(session.ContinuousOutdoorReturnSurfaceId) ||
                 !world.SurfaceGround.TryGet(session.ContinuousOutdoorReturnSurfaceId,
                     out var returnNavigation) ||
                 !returnNavigation.Contains(session.ContinuousOutdoorReturnX,
                     session.ContinuousOutdoorReturnY)))
                return Result.Failure(ErrorCode.InvalidOperation,
                    "Continuous return Surface is unavailable.", session.ContinuousOutdoorReturnSurfaceId);

            var returnId = session.ReturnLocationId;
            var continuousReturn = session.HasContinuousOutdoorReturn;
            var interiorMap = session.ActiveMapLayoutId;
            // 默认全员撤离：登记名单 ∪ 仍挂在内室地点的己方。
            EvacuateInteriorParty(world, session, interiorMap, returnId);
            session.ActiveMapLayoutId = session.HasContinuousOutdoorReturn ? string.Empty : session.OverworldMapLayoutId;
            session.ClearOccupants();
            if (session.HasContinuousOutdoorReturn && world.PlayerPartyTravel != null)
            {
                var position = new XianXia.Core.World.WorldVec2(
                    session.ContinuousOutdoorReturnX, session.ContinuousOutdoorReturnY);
                world.PlayerPartyTravel.SetAtSurfacePosition(position);
                world.PlayerPartyTravel.SetCurrentOutdoorWorldSiteContext(
                    XianXia.Core.World.Strategic.WorldSiteAdministrativeControlResolver
                        .TryResolveOnRegisteredSurface(
                            world, position.X, position.Y, out _, out var returnSite, out _)
                        ? returnSite.SiteId
                        : string.Empty);
                var party = world.Strategic.PlayerPartyContext;
                if (party != null)
                {
                    foreach (var id in party.Members)
                        if (XianXia.Core.World.Strategic.PlayerPartyTransitionMembership
                                .ShouldMemberTransitionWithParty(world, party, id))
                            world.WorldPresence.SetAtWorldPosition(id, position, default,
                                session.ContinuousOutdoorReturnSurfaceId);
                }
                else
                    foreach (var traveler in world.PlayerPartyTravel.TravelingMembers)
                        world.WorldPresence.SetAtWorldPosition(traveler, position, default,
                            session.ContinuousOutdoorReturnSurfaceId);
                world.PartyWorld.LocalMapId = string.Empty;
                world.PartyWorld.SiteId = string.Empty;
                world.PartyWorld.Mode = XianXia.Core.World.PartyWorldPresenceMode.AtWorldPosition;
                session.OverworldMapLayoutId = string.Empty;
                session.HasContinuousOutdoorReturn = false;
                session.ContinuousOutdoorReturnSurfaceId = string.Empty;
            }

            world.Events.Publish(
                EventType.LocalMapChanged,
                world.Tick,
                target: subject,
                payload: session.ActiveMapLayoutId + ";" + returnId);

            // The outdoor entrance registry is transient and may be unloaded while inside.
            // Host reactivates its Surface after this domain transition succeeds.
            return continuousReturn ? Result.Success() :
                NotifyArrived(world, subject, returnId, setLocation: false);
        }

        /// <summary>
        /// 瞬时勘查：圆心＋半径探针扫描未显形洞口。
        /// <paramref name="presentationHint"/>：
        /// <c>x,z</c>／<c>x,z,r</c>；多人用 <c>;</c> 分隔（多选框选时每人一圈）。
        /// 未给 r 时半径＝神识×2。
        /// </summary>
        public Result SurveyEntrance(SimulationWorld world, EntityId subject, string presentationHint = null)
        {
            if (world == null)
                return Result.Failure(ErrorCode.InvalidArgument, "SimulationWorld is null.");
            if (!world.Entities.TryGet(subject, out var entity))
                return Result.Failure(ErrorCode.EntityNotFound, "Subject missing.", subject.ToString());
            if (!entity.TryGet<AttributesComponent>(out var attrs))
                return Result.Failure(ErrorCode.ComponentMissing, "Attributes missing.");
            if (!entity.TryGet<KnownSitesComponent>(out var known))
                return Result.Failure(ErrorCode.ComponentMissing, "KnownSites missing.");

            var defaultRadius = OpportunityEntranceRules.SurveyRadius(attrs.GetFinal(AttributeId.SpiritSense));
            if (!TryBuildSurveyProbes(world, entity, presentationHint, defaultRadius, out var probes) ||
                probes.Count == 0)
                return Result.Failure(ErrorCode.InvalidOperation, "Cannot resolve survey center.");

            var found = 0;
            var blockedBySense = 0;
            var nearButOutOfRange = 0;
            var sense = attrs.GetFinal(AttributeId.SpiritSense);
            var maxR = 0f;
            for (var i = 0; i < probes.Count; i++)
            {
                if (probes[i].Radius > maxR)
                    maxR = probes[i].Radius;
            }

            foreach (var entrance in OpportunityEntranceQuery.EnumerateAvailableEntrances(world))
            {
                if (!OpportunityEntranceRules.IsHiddenEntrance(entrance))
                    continue;
                if (OpportunityEntranceRules.IsKnownToCharacter(world, subject, entrance))
                    continue;

                var inSurvey = false;
                var inHint = false;
                for (var i = 0; i < probes.Count; i++)
                {
                    var p = probes[i];
                    var hintR = System.Math.Max(OpportunityEntranceRules.DefaultHintRadius, p.Radius);
                    if (OpportunityEntranceRules.IsWithinSurveyRange(p.X, p.Z, hintR, entrance))
                        inHint = true;
                    if (OpportunityEntranceRules.IsWithinSurveyRange(p.X, p.Z, p.Radius, entrance))
                        inSurvey = true;
                }

                if (!inSurvey)
                {
                    if (inHint)
                        nearButOutOfRange++;
                    continue;
                }

                if (!OpportunityEntranceRules.MeetsSenseRequirement(entrance, sense))
                {
                    blockedBySense++;
                    continue;
                }

                if (!DefinitionId.TryParse(entrance.OpportunitySiteId, out var siteId))
                    continue;
                if (!world.TryGetOpportunitySite(siteId, out _))
                    continue;

                known.Discover(siteId);
                StoryFlagService.Set(world, ContentConditionEvaluator.ExploredFlag(entrance.Id), subject);
                world.Events.Publish(
                    EventType.OpportunitySiteDiscovered,
                    world.Tick,
                    target: subject,
                    payload: entrance.OpportunitySiteId);
                found++;
            }

            var at = probes[0].X.ToString("0.##") + "," + probes[0].Z.ToString("0.##");
            world.Events.Publish(
                EventType.LocationExplored,
                world.Tick,
                target: subject,
                payload: "survey;r=" + maxR.ToString("0.##") + ";probes=" + probes.Count +
                         ";found=" + found +
                         ";blockedSense=" + blockedBySense +
                         ";nearOut=" + nearButOutOfRange +
                         ";at=" + at);
            return Result.Success();
        }

        struct SurveyProbe
        {
            public float X;
            public float Z;
            public float Radius;
        }

        static bool TryBuildSurveyProbes(
            SimulationWorld world,
            Entity entity,
            string presentationHint,
            float defaultRadius,
            out System.Collections.Generic.List<SurveyProbe> probes)
        {
            probes = new System.Collections.Generic.List<SurveyProbe>(4);
            if (!string.IsNullOrWhiteSpace(presentationHint))
            {
                var chunks = presentationHint.Split(';');
                for (var i = 0; i < chunks.Length; i++)
                {
                    var chunk = chunks[i].Trim();
                    if (chunk.Length == 0)
                        continue;
                    var parts = chunk.Split(',');
                    if (parts.Length < 2)
                        continue;
                    if (!float.TryParse(parts[0].Trim(), System.Globalization.NumberStyles.Float,
                            System.Globalization.CultureInfo.InvariantCulture, out var x) ||
                        !float.TryParse(parts[1].Trim(), System.Globalization.NumberStyles.Float,
                            System.Globalization.CultureInfo.InvariantCulture, out var z))
                        continue;
                    var r = defaultRadius;
                    if (parts.Length >= 3 &&
                        float.TryParse(parts[2].Trim(), System.Globalization.NumberStyles.Float,
                            System.Globalization.CultureInfo.InvariantCulture, out var explicitR))
                        r = System.Math.Max(0f, explicitR);
                    probes.Add(new SurveyProbe { X = x, Z = z, Radius = r });
                }

                if (probes.Count > 0)
                    return true;
            }

            if (!entity.TryGet<EntityLocationComponent>(out var loc) || !loc.HasLocation)
                return false;
            if (!WorldLocationQuery.TryGet(world, loc.LocationId, out var place))
                return false;
            probes.Add(new SurveyProbe
            {
                X = place.PresentationX,
                Z = place.PresentationZ,
                Radius = defaultRadius
            });
            return true;
        }

        static void MovePartyTo(SimulationWorld world, EntityId subject, string locationId)
        {
            foreach (var e in world.Entities.All)
            {
                if (e == null)
                    continue;
                var isParty = (e.Tags & EntityTag.Character) != 0 && (e.Tags & EntityTag.Npc) == 0;
                if (!isParty && e.Id != subject)
                    continue;
                if (!e.TryGet<EntityLocationComponent>(out var lc))
                    continue;
                lc.LocationId = locationId;
                world.Events.Publish(
                    EventType.LocationChanged,
                    world.Tick,
                    target: e.Id,
                    payload: locationId);
            }
        }

        /// <summary>把当前站在 fromLocationId 的己方角色移到 toLocationId。</summary>
        static void MovePartyAtLocationTo(SimulationWorld world, string fromLocationId, string toLocationId)
        {
            if (world == null || string.IsNullOrEmpty(fromLocationId) || string.IsNullOrEmpty(toLocationId))
                return;
            foreach (var e in world.Entities.All)
            {
                if (!IsPlayerPartyCharacter(e))
                    continue;
                if (!e.TryGet<EntityLocationComponent>(out var lc) || !lc.HasLocation)
                    continue;
                if (!string.Equals(lc.LocationId, fromLocationId, System.StringComparison.Ordinal))
                    continue;
                SetEntityLocation(world, e, toLocationId);
            }
        }

        /// <summary>离开＝洞内己方全员撤离（登记名单 ∪ 内室 Location）。</summary>
        static void EvacuateInteriorParty(
            SimulationWorld world,
            LocalMapSession session,
            string interiorMapLayoutId,
            string returnLocationId)
        {
            if (world == null || string.IsNullOrEmpty(returnLocationId))
                return;

            if (session != null)
            {
                for (var i = 0; i < session.OccupantIds.Count; i++)
                {
                    var id = session.OccupantIds[i];
                    if (id.IsNone || !world.Entities.TryGet(id, out var occupant) ||
                        !IsPlayerPartyCharacter(occupant))
                        continue;
                    if (!occupant.TryGet<EntityLocationComponent>(out _))
                        continue;
                    SetEntityLocation(world, occupant, returnLocationId);
                }
            }

            if (string.IsNullOrEmpty(interiorMapLayoutId))
                return;
            foreach (var e in world.Entities.All)
            {
                if (!IsPlayerPartyCharacter(e))
                    continue;
                if (!e.TryGet<EntityLocationComponent>(out var lc) || !lc.HasLocation)
                    continue;
                if (!IsInteriorLocation(world, lc.LocationId, interiorMapLayoutId))
                    continue;
                SetEntityLocation(world, e, returnLocationId);
            }
        }

        static void RefreshInteriorOccupants(
            SimulationWorld world,
            LocalMapSession session,
            string interiorMapLayoutId)
        {
            if (session == null)
                return;
            session.ClearOccupants();
            if (world == null || string.IsNullOrEmpty(interiorMapLayoutId))
                return;
            foreach (var e in world.Entities.All)
            {
                if (!IsPlayerPartyCharacter(e))
                    continue;
                if (!e.TryGet<EntityLocationComponent>(out var lc) || !lc.HasLocation)
                    continue;
                if (!IsInteriorLocation(world, lc.LocationId, interiorMapLayoutId))
                    continue;
                session.AddOccupant(e.Id);
            }
        }

        static bool IsInteriorLocation(SimulationWorld world, string locationId, string interiorMapLayoutId)
        {
            if (world == null || string.IsNullOrEmpty(locationId) || string.IsNullOrEmpty(interiorMapLayoutId))
                return false;
            return world.LocalPlaces.TryGet(locationId, out var place) &&
                   !string.IsNullOrEmpty(place.LocalMapId) &&
                   string.Equals(place.LocalMapId, interiorMapLayoutId, System.StringComparison.Ordinal);
        }

        static bool IsPlayerPartyCharacter(Entity e) =>
            e != null &&
            (e.Tags & EntityTag.Character) != 0 &&
            (e.Tags & EntityTag.Npc) == 0;

        static void SetEntityLocation(SimulationWorld world, Entity e, string locationId)
        {
            if (world == null || e == null || string.IsNullOrEmpty(locationId))
                return;
            if (!e.TryGet<EntityLocationComponent>(out var lc))
            {
                lc = new EntityLocationComponent();
                e.AddComponent(lc);
            }

            if (string.Equals(lc.LocationId, locationId, System.StringComparison.Ordinal))
                return;
            lc.LocationId = locationId;
            // 进出洞府换地点：清掉旧图表现坐标，否则 Rebuild 会用地表／洞内错位瞬移
            lc.HasPresentationOverride = false;
            lc.PresentationOverrideX = 0f;
            lc.PresentationOverrideZ = 0f;
            world.Events.Publish(
                EventType.LocationChanged,
                world.Tick,
                target: e.Id,
                payload: locationId);
        }

        static void OfferLocationQuests(
            SimulationWorld world,
            EntityId subject,
            WorldLocationState location)
        {
            if (location.QuestOfferIds == null || location.QuestOfferIds.Count == 0)
                return;
            var quests = new QuestService();
            for (var i = 0; i < location.QuestOfferIds.Count; i++)
                quests.TryStart(world, location.QuestOfferIds[i], subject);
        }
    }
}
