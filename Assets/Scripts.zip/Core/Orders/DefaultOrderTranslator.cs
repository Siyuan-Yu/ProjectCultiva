using XianXia.Core.Actions;
using XianXia.Core.Attributes;
using XianXia.Core.Domain.Ids;
using XianXia.Core.Results;
using XianXia.Core.Schedule;

namespace XianXia.Core.Orders
{
    public sealed class DefaultOrderTranslator : IOrderTranslator
    {
        ulong _nextActionId = 1;

        public ulong PeekNextActionId => _nextActionId;

        public void RestoreNextActionId(ulong next) => _nextActionId = next == 0 ? 1UL : next;

        public Result<IAction> Translate(Order order)
        {
            if (order == null)
                return Result.Fail<IAction>(ErrorCode.InvalidArgument, "Order is null.");

            var actionId = new ActionId(_nextActionId++);
            switch (order.Type)
            {
                case OrderType.Wait:
                    if (order.WaitTicks == 0)
                        return Result.Fail<IAction>(ErrorCode.InvalidArgument, "WaitTicks must be > 0.");
                    return Result.Ok<IAction>(new WaitAction(actionId, order.Subject, order.Id, order.WaitTicks));

                case OrderType.ApplyModifier:
                    if (!order.ModifierAttribute.HasValue || !order.ModifierOperation.HasValue || !order.ModifierSource.HasValue)
                        return Result.Fail<IAction>(ErrorCode.InvalidArgument, "ApplyModifier fields incomplete.");
                    return Result.Ok<IAction>(new ApplyModifierAction(
                        actionId,
                        order.Subject,
                        order.Id,
                        order.ModifierAttribute.Value,
                        order.ModifierOperation.Value,
                        order.ModifierValue,
                        order.ModifierSource.Value));

                case OrderType.Cultivate:
                    if (order.WaitTicks == 0)
                        return Result.Fail<IAction>(ErrorCode.InvalidArgument, "Cultivate duration must be > 0.");
                    return Result.Ok<IAction>(new CultivateAction(actionId, order.Subject, order.Id, order.WaitTicks));

                case OrderType.Labor:
                    if (order.WaitTicks == 0)
                        return Result.Fail<IAction>(ErrorCode.InvalidArgument, "Labor duration must be > 0.");
                    return Result.Ok<IAction>(new LaborAction(actionId, order.Subject, order.Id, order.WaitTicks));

                case OrderType.Rest:
                    if (order.WaitTicks == 0)
                        return Result.Fail<IAction>(ErrorCode.InvalidArgument, "Rest duration must be > 0.");
                    return Result.Ok<IAction>(new RestAction(actionId, order.Subject, order.Id, order.WaitTicks));

                case OrderType.Observe:
                    if (order.WaitTicks == 0)
                        return Result.Fail<IAction>(ErrorCode.InvalidArgument, "Observe duration must be > 0.");
                    return Result.Ok<IAction>(new ObserveAction(actionId, order.Subject, order.Id, order.WaitTicks));

                case OrderType.Move:
                    if (order.WaitTicks == 0)
                        return Result.Fail<IAction>(ErrorCode.InvalidArgument, "Move duration must be > 0.");
                    if (string.IsNullOrEmpty(order.TargetRef))
                        return Result.Fail<IAction>(ErrorCode.InvalidArgument, "Move TargetRef (WorkArea) required.");
                    return Result.Ok<IAction>(new MoveAction(
                        actionId, order.Subject, order.Id, order.WaitTicks, order.TargetRef, order.SlotIndex));

                case OrderType.Work:
                    if (order.WaitTicks == 0)
                        return Result.Fail<IAction>(ErrorCode.InvalidArgument, "Work duration must be > 0.");
                    var activity = order.Activity ?? ScheduleActivity.Labor;
                    return Result.Ok<IAction>(new WorkAction(
                        actionId, order.Subject, order.Id, order.WaitTicks, activity, order.TargetRef, order.SlotIndex));

                case OrderType.Recover:
                    if (order.WaitTicks == 0 || string.IsNullOrWhiteSpace(order.TargetRef))
                        return Result.Fail<IAction>(ErrorCode.InvalidArgument, "Recovery duration and TargetRef required.");
                    return Result.Ok<IAction>(new RecoveryAction(
                        actionId, order.Subject, order.Id, order.WaitTicks, order.TargetRef));

                default:
                    return Result.Fail<IAction>(ErrorCode.InvalidOperation, "Unsupported order type.");
            }
        }
    }
}
