﻿# 修仙游戏策划案总览

> 状态：概念框架 v0.8｜**Architecture Freeze v0.2** | 最后更新：2026-08-01  
> **本页只放最高层大纲。** 细节进专题页；**怎么读整套文档**见 [通读指南](04-reading-guide.md)。  
> 本地 Markdown 与飞书文档一一对应（真源在本地，飞书为阅读层）。

## 〇、当前项目阶段

**架构冻结 v0.2。** Core／Data／**VS 0.1～0.4 已验收**。  
**进行中：VS 0.5 社会／人格 Alpha**（V5-A 人格档案已完成；下一步 RelationshipLedger）。  
Demo Runtime 停扩。完整进度见 [62 项目现状](../40-process/62-project-status-2026-08-01.md)。

**建议先读：** [通读指南](04-reading-guide.md) → 本页 → [62 现状](../40-process/62-project-status-2026-08-01.md) → [术语表](03-glossary.md) → [33](../30-tech/33-architecture-core-rules-freeze-v0.2.md) → [VS0.5 计划](../40-process/60-vertical-slice-0.5-social-alpha-plan-v0.1.md)。

- 主契约：[33 架构冻结 v0.2](../30-tech/33-architecture-core-rules-freeze-v0.2.md)
- 实体／Order／Mod：[34](../30-tech/34-entity-and-component-model.md)、[35](../30-tech/35-order-and-action-system.md)、[36](../30-tech/36-content-package-and-mod-architecture.md)
- Modifier／事件：[2C](../20-systems/2C-attributes-and-modifier-pipeline.md)、[2E](../20-systems/2E-events-and-world-state.md)
- 桥接／审计：[32](../30-tech/32-prototype-to-product-bridge.md)、[50 审计报告](../40-process/50-architecture-freeze-review-report-v0.1.md)
- Core M1：[实施计划 v0.2（已完成）](../40-process/51-core-milestone-1-implementation-plan-v0.2.md)／[ADR-0022](../40-process/43-decisions/ADR-0022-core-milestone-1-scope.md)
- VS 0.4 Host 验收：[61](../40-process/61-vertical-slice-0.4-acceptance-report.md)（计划 [59](../40-process/59-vertical-slice-0.4-unity-playable-host-plan-v0.1.md)）
- VS 0.5 社会 Alpha：[60](../40-process/60-vertical-slice-0.5-social-alpha-plan-v0.1.md)（**当前开发焦点**）
- VS 0.3 验收：[58](../40-process/58-vertical-slice-0.3-acceptance-report.md)
- 全部决策：[ADR 索引](../40-process/43-decisions/README.md)（UI＝0009 预留）

v0.2 修补要点：RelationshipLedger 权威；WorldTick／ActionClock；Dead≠Removed；FocusCharacterUnavailable；开局宗门劳役 Membership；地图 World／Region／LocalMap。

## 一、一句话定位

一款以**修仙成长**为核心的**实时暂停式战略 RPG**，2D 单机。

它同时融合五条线：个人修仙 RPG、RTS 式的世界与战斗、领地经营、宗门经营、人物关系与江湖系统。玩家从凡人小人物起步，通过探索、关系、修炼与战斗获得会实际改变操作规则的超凡能力，占领并经营村镇，招募核心修士，最终成长为拥有领地与宗门、能影响天下格局的修仙势力。

## 二、玩家身份的五个阶段

| 阶段 | 身份 | 玩家在做什么 |
|---|---|---|
| 1 | 感应境劳役 | 直接控制 3 名感应境角色完成每日配额；开局隶属压迫宗门（杂役／劳役） |
| 2 | 初入仙途 | 偷时间探索，获功法入炼气 |
| 3 | 一地之主 | 取得第一个村落或洞府 |
| 4 | 修仙势力 | 多据点、招募、外交与战争 |
| 5 | 一方道统 | 争夺城镇与高阶洞天 |

## 三、设计支柱

| 支柱 | 一句话 | 详细文档 |
|---|---|---|
| 1. 境界玩法质变 | 大境界解锁操作能力 | `22` |
| 2. 角色与领地供养 | 领地供养修炼，修炼推动扩张 | `26` |
| 3. 江湖关系真后果 | 关系由 Ledger 事件累积 | `28`／`2E` |
| 4. 修炼要准备 | 突破挑时辰地点资源 | `25` |
| 5. 规模不增微操 | 四层模拟 | `27`／`34` |
| 6. 力量越大因果越重 | 非简单正邪二分 | `29` |

## 四、三层玩法结构

| 层 | 内容 | 文档 |
|---|---|---|
| 角色层 | 个人 RPG | `27` |
| 战术层 | 世界地图 RTS+暂停 | `23` |
| 战略层 | 领地／宗门／外交 | `26` |

## 五、世界结构

**World → Region → LocalMap**（Freeze v0.2／ADR-0021）。

- Region：连续城市区域体验（荒村／矿／林／田／城心等）；尺寸可变。  
- LocalMap：洞／秘境／洞府等独立加载。  
- 跨 Region：Route，非整大陆无缝。  

详见 `33` §8、`24`。

## 六、文档索引

| 编号 | 系统 | 优先级 | 状态 |
|---|---|---|---|
| 20 | [开局体验](../20-systems/20-opening-experience.md) | P0 | |
| 21 | [核心循环与时间](../20-systems/21-core-loop-and-time.md) | P0 | WorldTick+ActionClock |
| 22 | [境界与机制能力](../20-systems/22-realms-and-abilities.md) | P0 | |
| 23 | [战斗](../20-systems/23-combat.md) | P0 | M1 不做真战斗 |
| 24 | [世界与据点](../20-systems/24-world-and-settlements.md) | P0 | **三层地图已对齐 v0.2** |
| 25 | [修炼与突破](../20-systems/25-cultivation-and-breakthrough.md) | P0 | |
| 26 | [领地经营](../20-systems/26-territory-management.md) | P0 | |
| 27 | [角色与人口](../20-systems/27-characters-and-population.md) | P0 | |
| 28 | [江湖关系](../20-systems/28-jianghu-relations.md) | P0 | Ledger 真源；VS0.5 落地中 |
| 29 | [天道因果](../20-systems/29-karma-and-consequence.md) | P1 | |
| 2B | [属性与成长](../20-systems/2B-attributes-and-affinity.md) | P0 | |
| 2C | [Modifier 管道](../20-systems/2C-attributes-and-modifier-pipeline.md) | P0 | |
| 2D | [功法斗技装备](../20-systems/2D-manuals-arts-and-equipment.md) | P0 | |
| 2E | [事件与世界账本](../20-systems/2E-events-and-world-state.md) | P0 | |
| 2F | [义务与隐匿](../20-systems/2F-obligation-and-concealment.md) | P0 | |
| 2G | [第一章流程](../20-systems/2G-first-chapter-flow.md) | P0 | 开局 Membership 已冻 |
| 2H | [功法规则](../20-systems/2H-manual-system-rules.md) | P0 | |
| 2I | [荒村杂役阶段叙事（v0.1）](../20-systems/2I-huangcun-labor-phase-narrative-v0.1.md) | P0 | Draft；状态／触发／反馈 |

**项目与过程：**

| 文档 | 说明 |
|---|---|
| [通读指南](04-reading-guide.md) | 阅读顺序与角色最短路径 |
| [愿景](01-vision.md)／[范围](02-scope-and-constraints.md)／[术语表](03-glossary.md) | 总纲三件套 |
| [系统设计索引](../20-systems/README.md) | 系统清单与依赖 |
| [路线图](../40-process/41-roadmap.md)／[开发日志](../40-process/42-devlog.md) | 阶段与记录 |
| [62 项目现状 2026-08-01](../40-process/62-project-status-2026-08-01.md) | **现行进度总表** |
| [Core M1 实施计划 v0.2](../40-process/51-core-milestone-1-implementation-plan-v0.2.md) | **已完成验收** |
| [VS 0.1 验收](../40-process/54-vertical-slice-0.1-acceptance-report.md) | 已通过 |
| [VS 0.2 验收](../40-process/56-vertical-slice-0.2-acceptance-report.md) | 已通过 |
| [VS 0.3 验收](../40-process/58-vertical-slice-0.3-acceptance-report.md) | 已通过 |
| [VS 0.4 Host 验收](../40-process/61-vertical-slice-0.4-acceptance-report.md) | **已通过**（计划 [59](../40-process/59-vertical-slice-0.4-unity-playable-host-plan-v0.1.md)） |
| [VS 0.5 社会 Alpha 计划](../40-process/60-vertical-slice-0.5-social-alpha-plan-v0.1.md) | **当前开发焦点** |
| [Data Pipeline M1 计划 v0.2](../40-process/53-data-pipeline-milestone-1-plan-v0.2.md) | **已实现**（M1-A／M1-B） |
| [ADR 决策索引](../40-process/43-decisions/README.md) | 全部已采纳决策 |

**架构文档：**

| 文档 | 说明 |
|---|---|
| [33 冻结 v0.2](../30-tech/33-architecture-core-rules-freeze-v0.2.md) | **当前主契约** |
| [34 实体](../30-tech/34-entity-and-component-model.md) | 含 PersonalityProfile（VS0.5-A） |
| [35 Order/Action](../30-tech/35-order-and-action-system.md) | |
| [36 ContentPackage](../30-tech/36-content-package-and-mod-architecture.md) | |
| [31 技术架构](../30-tech/31-architecture.md) | 程序集与工程约定 |
| [32 桥接](../30-tech/32-prototype-to-product-bridge.md) | Demo→正式 |
| [50 审计报告](../40-process/50-architecture-freeze-review-report-v0.1.md) | Freeze 一致性审计 |
| [37 飞书同步](../30-tech/37-feishu-sync.md) | 本地↔飞书规则 |

## 七、系统依赖顺序

```
33 v0.2 主契约
 ├── 34 · 35 · 2C · 2E · 36
 └── 21 时间
      ├── 2F → 20 → 2G
      ├── 22 → 23；24
      ├── 2B · 2H · 2D → 25 → 26
      └── 27 → 28 → 29
```

## 八、范围控制

第一阶段玩法仍只验证：感应→炼气质变、角色↔领地闭环、暂停战斗构筑（**实现上 Core M1 先只做骨架，不含真战斗**）。  
**VS0.5 社会 Alpha 已验收**；当前不扩 Demo、不扩战斗／地图。关系／人格／隶属入 Snapshot 前须硬停。

## 九、跨系统未决（摘录）

飞行境界、炼气术法清单、突破事件细则、Focus 失能后继承 UI、TemporaryProtection 事件模板库等——见各系统文档；**不在未冻时自行拍板。**

## 十、下一步

1. 下一切片方向待定；若要关系入档 → **先确认 Snapshot schema**。  
2. Content Authoring Tool：可招 NPC／关系种子不宜继续软编码膨胀。  
3. 不扩展 Demo Runtime；不改 Freeze 正文。
