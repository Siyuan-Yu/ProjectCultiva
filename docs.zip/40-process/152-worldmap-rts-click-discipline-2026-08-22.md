# 152 · 大地图 RTS 左右键纪律收束（2026-08-22）

> **2026-08-25：** FormalArmy 大地图点选纪律仍可参考；**玩家本体**不再以多人 RTS 为长期模型 → [2K](../20-systems/2K-rpg-first-character-control-playerparty-and-continuous-hex-world.md)／[ADR-0026](43-decisions/ADR-0026-rpg-first-playerparty-and-formalarmy-military-layer.md)。
>
> 状态：**已落地（Host；待手操）**｜日期：2026-08-22  
> 上级：[139 大地图 RTS](139-world-map-rts-orders-2026-08-17.md)／[148 弥留交互](148-worldmap-linger-incap-ux-2026-08-21.md)／[150 残留 Offer](150-lingering-battlefield-batch3-offer-2026-08-21.md)  
> 游玩入口：`Assets/Scenes/LevelTester.unity`  
> 附图：`worldmap-rts-interaction-table.png`

---

## 1. 一句话

把大地图点选改回 **标准 RTS**：左键只选中、右键只下令；废除 148 里「右键选敌军／左键弹攻击／弥留不可选／右键探望」等反 RTS 分支。

---

## 2. 产品规则（真源）

**总原则：左键＝选中｜右键＝下令｜右键永不负责选中。**

| 目标 | 无选中 + 左键 | 已选我方活人 + 左键 | 已选我方活人 + 右键 | 说明 |
|------|---------------|---------------------|---------------------|------|
| 我方活人 | 选中 | 改选／加选 | 点单位通常无指令 | 右键永不选中 |
| 敌方栈（含弥留残留） | 只选中 | 只选中（清空我方选中） | 仅「攻击」→ Offer | 不要「详情」；右键不改选中 |
| 我方弥留 | 只选中 | 只选中 | 「进入残留战场」→ Offer | 左键可选；取消探望主交互 |
| 空地／道路／路上点 | 取消选中 | 取消选中 | 移动确认 | 节点或路上任意点保留 |
| 节点（有我方） | 节点菜单可进场景 | 同左 | 点节点＝移动确认 | 「进入场景」留在左键菜单 |

---

## 3. 代码改动

| 项 | 说明 |
|----|------|
| `HostWorldMapPanel.HandleMapInput` | 左键选头像／敌军／节点／空地；右键下令不写 `_selectedStackId` |
| 敌军菜单 | 删除「查看详情」；仅「攻击」 |
| 我方弥留 | 左键可进 `_selected`＋选中框；右键只开进入菜单 |
| 删除 | `TryDispatchSelectedLivingToIncap`／`TryBuildTravelTargetForIncap`（探望主路径） |
| 命中垫 | 敌军栈 pad 16→10／竞态 8→4，减少抢道路右键 |

`PendingLingeringVisit*` 与到站钩子仍保留（无主路径写入时为空操作）。

---

## 4. 手操清单

1. 无选中左键敌军 → 只选中框，无菜单  
2. 左键我方 → 右键敌军 → 仅「攻击」→ 到站 Offer  
3. 左键我方 → 右键节点／道路 → 移动确认仍可用  
4. 左键节点 →「进入场景」仍可用  
5. 左键我方弥留 → 选中框 → 右键该头像 →「进入残留战场」→ Offer  
6. 右键敌军不改变选中高亮（不抢我方选中）

---

## 5. 修订记录

| 日期 | 说明 |
|------|------|
| 2026-08-22 | **审计：** 移动／攻击弥留判断同源（`LifecycleComponent`＋同一 `CollectSelectedMacroParty`）；旧 bug 是 Host 临时 List 别名自清，不是两套弥留表。已加 `_orderFilterScratch` 专用中间表 |
| 2026-08-22 | **补丁：** 移动名单自清别名 bug（`CollectSelectedMacroParty(into:_scratchParty)` 把自己清掉，误报「全是弥留」；攻击因用另一缓冲仍正常） |
| 2026-08-22 | **补丁：** 右键移动失效——活人头像不再拦截节点右键；关菜单不吞右键；道路点选改屏幕 28px 容差 |
| 2026-08-22 | 初版：对齐制作人 RTS 表；废 148 反 RTS 点选 |
