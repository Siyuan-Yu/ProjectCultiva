# 114 · Level Tester（逻辑关卡试玩台）

> 状态：**可用**｜日期：2026-08-27（Cheat Tools 统一整理）  
> 场景：`Assets/Scenes/LevelTester.unity`  
> 入口：`PlayableHostBootstrap` + `LevelTesterHud`  
> 菜单：`XianXia/Level Tester/…`  
> 实现索引：[168-level-tester-cheat-tools-consolidation-2026-08-27.md](168-level-tester-cheat-tools-consolidation-2026-08-27.md)

---

## 完整需求（本场景要覆盖什么）

Level Tester 用来试玩 **某一个大地图节点的 LocalMap**（例如荒村），只测逻辑与灰盒表现，不接最终美术场景。

| # | 需求 | 本版 |
|---|------|------|
| 1 | 独立场景，不污染 DemoParity／美术关 | ✅ `LevelTester.unity` |
| 2 | 加载 Content 包（任务／NPC／课表／region） | ✅ 默认 `Content/BaseGame` |
| 3 | 指定／切换 **mapLayout**（地图建筑／分区／挡路） | ✅ id + 文件路径 + TextAsset |
| 4 | 指定 **openingScenario**（开局任务线／出生） | ✅ Inspector |
| 5 | 刷图：分区／田／树／墙／交互点 | ✅ `HostDemoTileMap` |
| 6 | 寻路 WalkGrid 来自当前 mapLayout | ✅ |
| 7 | RTS：选中、移动、右键劳动／修炼 | ✅ Host 全套 |
| 8 | 时间：暂停／步进／变速、日程 | ✅ |
| 9 | HUD：任务／事件／角色状态 | ✅ Formal + **任务日志 J** + EventFeed |
| 10 | 开发 Cheat：构造验收状态 | ✅ **LevelTester Cheat Tools**（`` ` `` 或顶栏按钮） |
| 11 | 顶栏显示当前包／地图／剧本 | ✅ `LevelTesterHud` |
| 12 | Inspector 浏览磁盘 map JSON（Content 在 Assets 外） | ✅ CustomInspector 按钮 |
| 13 | 编辑模式 Import 预览（prefab 刷图，无需 Play） | ✅ Inspector「Import」 |
| 14 | 地图 JSON 真源 Content/BaseGame/Data | ✅ 与 MapEditor 一致 |
| 15 | World Graph 宏观旅行 UI | ❌ 以后 Phase C |
| 16 | 最终美术场景导入 | ❌ 另场景；本台只测逻辑 |

**流程：** MapEditor 编图 → Level Tester 换地图／剧本 Play → 逻辑过关 → 以后再进美术场景。

---

## 第一次打开

1. Unity 菜单 **`XianXia/Level Tester/Create Or Update Level Tester Scene`**（补齐组件；可重复跑）  
2. 打开 `Assets/Scenes/LevelTester`  
3. 选中 **LevelTester** 物体，看 `Playable Host Bootstrap`：
   - **Preferred Map Layout Id**：`base:map_ch01_reference`
   - **Map Layout File Path**：`Content/BaseGame/Data/Maps/ch01_reference_map.json`
   - **Opening Scenario Id**：`base:scenario_ch01_reference`
4. 点 **Import** 可在 Scene 里预览 prefab 布局；或 Play 测逻辑

---

## 怎么换关

关卡地图 JSON 真源：

`Content/BaseGame/Data/`（各 type 在子目录，见 `Data/README.md`）

1. MapEditor 编好后 **Ctrl+S** 写回 Content，或另存到同目录  
2. 选中 **LevelTester** → Inspector 点 **「选择文件…」** → 选 `Content/BaseGame/Data/*.json`  
3. 点 **Import** 在 Scene 里看 prefab 预览；Play 后如需重建 Session，用 Cheat Tools → **Snapshot / Session → Reset LevelTester Session**  

改 JSON 后再点 **Import** 会先清掉预览根下全部旧物件再刷（不必先切走再重进场景）。若仍叠图，先点 **Clear Preview** 再 Import。

NPC／任务仍来自 Content 包；这里只换「这一张本地图」。

---

## LevelTester Cheat Tools（开发验收）

**打开方式：**

- 键盘 **`` ` ``**（BackQuote）
- 或 `LevelTesterHud` 顶栏 **「Cheat Tools」** 按钮

**顶层页签（Tab）：**

| Tab | 能力 |
|-----|------|
| Time | Step 1 Tick、Advance N Ticks、Advance 1 Day、Speed 1/2/5/20x |
| Background | 选角色、Travel To Site/Hex、Cancel、只读 Travel 状态 |
| FormalArmy | Create（含明确 Leader）、Select Army、Disband、Travel、Incap、Sync Casualties |
| Content | Set/Clear Flag、Force Event、Dump Content State |
| Diplomacy | Declare War、Alliance、Vassalage（选 Faction） |
| Snapshot | Save/Load Snapshot、**Reset LevelTester Session**（二次确认） |
| Battle | DEBUG: Next Solo Auto-Battle Guaranteed Incapacitation |
| Diagnostics | Hex Separation 等纯视觉 Debug（如有） |

打开面板后通过页签切换系统；仅单个页签内容超出高度时使用页内 ScrollView。

Cheat Tools **仅**用于 LevelTester 开发／人工验收，不进入正式 Gameplay UI，不为各系统单独占用 F-Key。

---

## 操作键（正式 Gameplay）

| 键 | 作用 |
|----|------|
| Space | 暂停／继续（FormalHud 时间控制） |
| J | 任务日志（打开时暂停世界；可接／进行中／已完成；追踪显示在右侧任务栏） |
| Q / E / F1 / F6 / F7 / F8 / G 等 | 正式 Gameplay 行动（见 FormalHud） |
| 中键／键盘 | 相机平移缩放（Host 相机） |

> **已移除（勿再使用）：** F3/F4/F8/F11/F12 独立 Debug Panel、F5/F9 Snapshot 快捷键、`.`/`N` Bootstrap Step Tick、`[`/`]` Bootstrap 变速、`R` Runtime Session Rebuild。

---

## 和 DemoParityHost 的区别

| | DemoParityHost | Level Tester |
|--|----------------|--------------|
| 目的 | 样板回归／签收 | 日常换关测逻辑 |
| 换地图 | 不方便 | id／路径／TextAsset |
| HUD | 偏干净 | 逻辑调试 + Cheat Tools |
| 验收场景 | 非主要 | **唯一主要人工验收场景** |

---

## 修订记录

| 日期 | 说明 |
|------|------|
| 2026-08-27 | 统一 `HostLevelTesterCheatPanel`；移除分散 Debug Panel 与旧 Development Hotkey |
| 2026-08-13 | 地图真源改 Content/BaseGame/Data |
| 2026-08-13 | 初版：选图／覆盖 JSON／场景菜单／顶栏 |
