using System.Windows;
namespace WorldComposer;
public partial class App : Application { }
