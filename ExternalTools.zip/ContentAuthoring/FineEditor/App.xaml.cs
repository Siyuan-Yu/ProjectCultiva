using System.Windows;
namespace FineEditor;
public partial class App : Application { }
