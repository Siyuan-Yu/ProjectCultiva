using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace ContentAuthoring.Shared.HexWorld;

public static class HexWorldContentJson
{
    static readonly JsonSerializerOptions WriteOptions = new()
    {
        WriteIndented = true,
        Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
    };

    static readonly JsonSerializerOptions ReadOptions = new()
    {
        PropertyNameCaseInsensitive = true,
    };

    public static HexWorldContentFile LoadFile(string path)
    {
        var json = File.ReadAllText(path);
        return Load(json);
    }

    public static HexWorldContentFile Load(string json)
    {
        var file = JsonSerializer.Deserialize<HexWorldContentFile>(json, ReadOptions)
                   ?? throw new InvalidDataException("Hex world JSON root is null.");
        NormalizeLoadedSites(file);
        return file;
    }

    static void NormalizeLoadedSites(HexWorldContentFile file)
    {
        if (file.Definitions == null)
            return;
        foreach (var definition in file.Definitions)
        {
            if (definition?.Sites == null)
                continue;
            foreach (var site in definition.Sites)
                HexWorldPresenceRules.SyncPresenceToAnchor(site);
        }
    }

    public static HexWorldDefinitionDto LoadDefinition(string path) =>
        LoadDefinition(LoadFile(path));

    public static HexWorldDefinitionDto LoadDefinition(HexWorldContentFile file)
    {
        if (file.Definitions == null || file.Definitions.Count == 0)
            throw new InvalidDataException("Hex world JSON has no definitions.");
        if (file.Definitions.Count > 1)
            throw new InvalidDataException("Hex world JSON must contain exactly one definition per file.");
        return file.Definitions[0];
    }

    public static void SaveFile(string path, HexWorldDefinitionDto definition)
    {
        var dir = Path.GetDirectoryName(path);
        if (!string.IsNullOrEmpty(dir))
            Directory.CreateDirectory(dir);
        File.WriteAllText(path, Serialize(definition));
    }

    public static string Serialize(HexWorldDefinitionDto definition)
    {
        var file = new HexWorldContentFile
        {
            SchemaVersion = HexWorldContentSchema.CurrentVersion,
            Definitions = new List<HexWorldDefinitionDto> { definition },
        };
        return JsonSerializer.Serialize(file, WriteOptions);
    }

    public static void NormalizeForSave(HexWorldDefinitionDto definition)
    {
        definition.Type = HexWorldContentSchema.DefinitionType;
        definition.Cells = definition.Cells
            .OrderBy(c => c.R)
            .ThenBy(c => c.Q)
            .ToList();
        definition.Sites = definition.Sites
            .OrderBy(s => s.SiteId, StringComparer.Ordinal)
            .ToList();
        foreach (var site in definition.Sites)
        {
            HexWorldPresenceRules.SyncPresenceToAnchor(site);
            site.Footprint = site.Footprint
                .Distinct()
                .OrderBy(h => h.R)
                .ThenBy(h => h.Q)
                .ToList();
        }
        definition.FactionFlags = definition.FactionFlags
            .OrderBy(flag => flag.EstablishedOrder)
            .ThenBy(flag => flag.FlagId, StringComparer.Ordinal)
            .ToList();
        definition.TerritoryRegions = definition.TerritoryRegions
            .OrderBy(region => region.RegionId, StringComparer.Ordinal)
            .ToList();
        foreach (var region in definition.TerritoryRegions)
        {
            region.Hexes = region.Hexes
                .Distinct()
                .OrderBy(hex => hex.R)
                .ThenBy(hex => hex.Q)
                .ToList();
        }
        definition.StandaloneTerritoryHexes = definition.StandaloneTerritoryHexes
            .OrderBy(control => control.R).ThenBy(control => control.Q).ToList();
    }
}
